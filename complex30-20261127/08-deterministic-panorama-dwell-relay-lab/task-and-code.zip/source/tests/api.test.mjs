import assert from "node:assert/strict";
import * as THREE from "three";
import "/tmp/relay-core.mjs";
