import * as THREE from "three";
export function createRelayLab() {
const DEG = Math.PI / 180;
const RAD = 180 / Math.PI;
const MARKER_DISTANCE = 40;
const DWELL_LIMIT_MS = 1000;
const EPSILON = 1e-4;
const FOV = 60;

const definitions = {
  A: [
    { id: "alpha", position: [40, 0, 0], color: 0xef6b55 },
    { id: "beta", position: [0, 20, -34.64101615137755], color: 0x64d7c3 },
    { id: "exit", position: [0, 0, -40], color: 0xf1bd62 },
  ],
  B: [
    { id: "return", position: [0, 0, 40], color: 0x9b8bff },
    { id: "target", position: [-40, 0, 0], color: 0xef71b0 },
  ],
};

const roomMarkerIds = Object.fromEntries(
  Object.entries(definitions).map(([room, items]) => [room, new Set(items.map(({ id }) => id))]),
);

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(FOV, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 0, 0);
camera.rotation.order = 'YXZ';
const rooms = { A: new THREE.Group(), B: new THREE.Group() };
const markers = {};
const enclosure = new THREE.Mesh(
  new THREE.SphereGeometry(100, 48, 32),
  new THREE.MeshBasicMaterial({ color: 0x102d35, side: THREE.BackSide }),
);
enclosure.name = "enclosure";
enclosure.userData.pickable = false;
scene.add(enclosure);
for (const [roomId, items] of Object.entries(definitions)) {
  for (const item of items) {
    const marker = new THREE.Mesh(new THREE.SphereGeometry(2, 16, 12));
    marker.position.fromArray(item.position);
    marker.name = item.id; marker.userData.id = item.id; marker.userData.room = roomId; marker.userData.pickable = true;
    rooms[roomId].add(marker); markers[item.id] = marker;
  }
  scene.add(rooms[roomId]);
}


const state = {
  room: "A",
  yaw: 0,
  pitch: 0,
  dwellEnabled: false,
  dwellId: null,
  dwellMs: 0,
  activations: [],
};

const raycaster = new THREE.Raycaster();
const pointerNdc = new THREE.Vector2();
const isFiniteNumber = (value) => typeof value === "number" && Number.isFinite(value);

function normalizeYaw(yaw) {
  let normalized = (((yaw + 180) % 360) + 360) % 360 - 180;
  if (normalized === -180) normalized = 0;
  return normalized;
}

function applyCameraRotation() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  camera.rotation.set(state.pitch * DEG, -state.yaw * DEG, 0, "YXZ");
  camera.updateMatrixWorld();
}

function setRoom(roomId) {
  state.room = roomId;
  rooms.A.visible = roomId === "A";
  rooms.B.visible = roomId === "B";
}

function getVisibleMarkers() {
  return Object.values(markers).filter(
    (marker) =>
      marker.userData.pickable &&
      marker.visible &&
      marker.parent?.visible &&
      marker.userData.room === state.room,
  );
}

function pick(ndcX, ndcY) {
  applyCameraRotation();
  if (!isFiniteNumber(ndcX) || !isFiniteNumber(ndcY)) return null;
  if (ndcX < -1 || ndcX > 1 || ndcY < -1 || ndcY > 1) return null;

  pointerNdc.set(ndcX, ndcY);
  camera.updateMatrixWorld();
  raycaster.setFromCamera(pointerNdc, camera);
  const hits = raycaster.intersectObjects(getVisibleMarkers(), false);
  return hits.length > 0 ? hits[0].object.userData.id : null;
}

function setView(yaw, pitch) {
  if (!isFiniteNumber(yaw) || !isFiniteNumber(pitch)) return false;
  state.yaw = normalizeYaw(yaw);
  state.pitch = Math.max(-80, Math.min(80, pitch));
  applyCameraRotation();
  
  return true;
}

function clearDwellProgress() {
  state.dwellId = null;
  state.dwellMs = 0;
}

function setDwell(enabled) {
  state.dwellEnabled = enabled === true;
  clearDwellProgress();
  
}

function aimAtMarker(marker) {
  const { x, y, z } = marker.position;
  state.yaw = normalizeYaw(Math.atan2(x, -z) * RAD);
  state.pitch = Math.max(-80, Math.min(80, Math.asin(y / MARKER_DISTANCE) * RAD));
  applyCameraRotation();
}

function activate(id) {
  if (typeof id !== "string" || !roomMarkerIds[state.room].has(id)) return false;
  const marker = markers[id];
  if (!marker || marker.userData.room !== state.room) return false;

  state.activations.push(id);
  if (id === "exit" || id === "return") {
    state.room = id === "exit" ? "B" : "A";
    state.yaw = 0;
    state.pitch = 0;
    rooms.A.visible = state.room === "A";
    rooms.B.visible = state.room === "B";
    applyCameraRotation();
  } else {
    aimAtMarker(marker);
  }
  
  return true;
}

function step(ms) {
  if (!state.dwellEnabled || !isFiniteNumber(ms) || ms < 0) return;

  const centeredId = pick(0, 0);
  if (centeredId === null || centeredId !== state.dwellId) {
    state.dwellId = centeredId;
    state.dwellMs = 0;
    
    return;
  }

  state.dwellMs += ms;
  if (state.dwellMs >= DWELL_LIMIT_MS - EPSILON) {
    const id = state.dwellId;
    state.dwellEnabled = false;
    clearDwellProgress();
    activate(id);
  }
  
}

function reset() {
  state.room = "A";
  state.yaw = 0;
  state.pitch = 0;
  state.dwellEnabled = false;
  clearDwellProgress();
  state.activations.length = 0;
  rooms.A.visible = true;
  rooms.B.visible = false;
  applyCameraRotation();
  
}

function getState() {
  return {
    room: state.room,
    yaw: state.yaw,
    pitch: state.pitch,
    dwellEnabled: state.dwellEnabled,
    dwellId: state.dwellId,
    dwellMs: state.dwellMs,
    activations: [...state.activations],
  };
}


return {scene, camera, rooms, markers, pick, setView, setDwell, step, activate, reset, getState};
}
