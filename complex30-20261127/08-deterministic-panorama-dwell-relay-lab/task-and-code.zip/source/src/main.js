import * as THREE from "three";
import "./style.css";

const DEG = Math.PI / 180;
const RAD = 180 / Math.PI;
const MARKER_DISTANCE = 40;
const DWELL_LIMIT_MS = 1000;
const EPSILON = 1e-4;
const FOV = 60;

const definitions = {
  A: [
    { id: "alpha", position: [40, 0, 0], color: 0xef6b55 },
    { id: "beta", position: [0, 20, -34.64101615137755], color: 0x64d7c3 },
    { id: "exit", position: [0, 0, -40], color: 0xf1bd62 },
  ],
  B: [
    { id: "return", position: [0, 0, 40], color: 0x9b8bff },
    { id: "target", position: [-40, 0, 0], color: 0xef71b0 },
  ],
};

const roomMarkerIds = Object.fromEntries(
  Object.entries(definitions).map(([room, items]) => [room, new Set(items.map(({ id }) => id))]),
);

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x071017);

const camera = new THREE.PerspectiveCamera(FOV, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.set(0, 0, 0);
camera.rotation.order = "YXZ";

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
document.querySelector("#viewport").appendChild(renderer.domElement);

const enclosure = new THREE.Mesh(
  new THREE.SphereGeometry(100, 48, 32),
  new THREE.MeshBasicMaterial({ color: 0x102d35, side: THREE.BackSide }),
);
enclosure.name = "enclosure";
enclosure.userData.pickable = false;
scene.add(enclosure);

const markerGeometry = new THREE.SphereGeometry(2, 16, 12);
const rooms = { A: new THREE.Group(), B: new THREE.Group() };
const markers = {};

for (const [roomId, items] of Object.entries(definitions)) {
  rooms[roomId].name = `room-${roomId}`;
  rooms[roomId].userData.room = roomId;
  for (const item of items) {
    const marker = new THREE.Mesh(
      markerGeometry,
      new THREE.MeshStandardMaterial({
        color: item.color,
        emissive: item.color,
        emissiveIntensity: 0.48,
        roughness: 0.36,
        metalness: 0.08,
      }),
    );
    marker.position.fromArray(item.position);
    marker.name = item.id;
    marker.userData.id = item.id;
    marker.userData.room = roomId;
    marker.userData.pickable = true;
    rooms[roomId].add(marker);
    markers[item.id] = marker;
  }
  scene.add(rooms[roomId]);
}

scene.add(new THREE.HemisphereLight(0x9ce9de, 0x182025, 2.2));
const keyLight = new THREE.DirectionalLight(0xffe2b0, 2.5);
keyLight.position.set(12, 25, 8);
scene.add(keyLight);
const rimLight = new THREE.DirectionalLight(0x5f9dff, 1.3);
rimLight.position.set(-20, -4, -12);
scene.add(rimLight);

const state = {
  room: "A",
  yaw: 0,
  pitch: 0,
  dwellEnabled: false,
  dwellId: null,
  dwellMs: 0,
  activations: [],
};

const raycaster = new THREE.Raycaster();
const pointerNdc = new THREE.Vector2();
const ui = {
  room: document.querySelector("#room"),
  yaw: document.querySelector("#yaw"),
  pitch: document.querySelector("#pitch"),
  dwellId: document.querySelector("#dwell-id"),
  dwellMs: document.querySelector("#dwell-ms"),
  dwellBar: document.querySelector("#dwell-bar"),
  activations: document.querySelector("#activations"),
  reset: document.querySelector("#reset"),
  dwell: document.querySelector("#dwell"),
  crosshair: document.querySelector("#crosshair"),
};

const isFiniteNumber = (value) => typeof value === "number" && Number.isFinite(value);

function normalizeYaw(yaw) {
  let normalized = (((yaw + 180) % 360) + 360) % 360 - 180;
  if (normalized === -180) normalized = 0;
  return normalized;
}

function applyCameraRotation() {
  camera.rotation.set(state.pitch * DEG, -state.yaw * DEG, 0, "YXZ");
  camera.updateMatrixWorld();
}

function setRoom(roomId) {
  state.room = roomId;
  rooms.A.visible = roomId === "A";
  rooms.B.visible = roomId === "B";
}

function getVisibleMarkers() {
  return Object.values(markers).filter(
    (marker) =>
      marker.userData.pickable &&
      marker.visible &&
      marker.parent?.visible &&
      marker.userData.room === state.room,
  );
}

function pick(ndcX, ndcY) {
  if (!isFiniteNumber(ndcX) || !isFiniteNumber(ndcY)) return null;
  if (ndcX < -1 || ndcX > 1 || ndcY < -1 || ndcY > 1) return null;

  pointerNdc.set(ndcX, ndcY);
  camera.updateMatrixWorld();
  raycaster.setFromCamera(pointerNdc, camera);
  const hits = raycaster.intersectObjects(getVisibleMarkers(), false);
  return hits.length > 0 ? hits[0].object.userData.id : null;
}

function setView(yaw, pitch) {
  if (!isFiniteNumber(yaw) || !isFiniteNumber(pitch)) return false;
  state.yaw = normalizeYaw(yaw);
  state.pitch = Math.max(-80, Math.min(80, pitch));
  applyCameraRotation();
  refreshUI();
  return true;
}

function clearDwellProgress() {
  state.dwellId = null;
  state.dwellMs = 0;
}

function setDwell(enabled) {
  state.dwellEnabled = enabled === true;
  clearDwellProgress();
  refreshUI();
}

function aimAtMarker(marker) {
  const { x, y, z } = marker.position;
  state.yaw = normalizeYaw(Math.atan2(x, -z) * RAD);
  state.pitch = Math.max(-80, Math.min(80, Math.asin(y / MARKER_DISTANCE) * RAD));
  applyCameraRotation();
}

function activate(id) {
  if (typeof id !== "string" || !roomMarkerIds[state.room].has(id)) return false;
  const marker = markers[id];
  if (!marker || marker.userData.room !== state.room) return false;

  state.activations.push(id);
  if (id === "exit" || id === "return") {
    state.room = id === "exit" ? "B" : "A";
    state.yaw = 0;
    state.pitch = 0;
    rooms.A.visible = state.room === "A";
    rooms.B.visible = state.room === "B";
    applyCameraRotation();
  } else {
    aimAtMarker(marker);
  }
  refreshUI();
  return true;
}

function step(ms) {
  if (!state.dwellEnabled || !isFiniteNumber(ms) || ms < 0) return;

  const centeredId = pick(0, 0);
  if (centeredId === null || centeredId !== state.dwellId) {
    state.dwellId = centeredId;
    state.dwellMs = 0;
    refreshUI();
    return;
  }

  state.dwellMs += ms;
  if (state.dwellMs >= DWELL_LIMIT_MS - EPSILON) {
    const id = state.dwellId;
    state.dwellEnabled = false;
    clearDwellProgress();
    activate(id);
  }
  refreshUI();
}

function reset() {
  state.room = "A";
  state.yaw = 0;
  state.pitch = 0;
  state.dwellEnabled = false;
  clearDwellProgress();
  state.activations.length = 0;
  rooms.A.visible = true;
  rooms.B.visible = false;
  applyCameraRotation();
  refreshUI();
}

function getState() {
  return {
    room: state.room,
    yaw: state.yaw,
    pitch: state.pitch,
    dwellEnabled: state.dwellEnabled,
    dwellId: state.dwellId,
    dwellMs: state.dwellMs,
    activations: [...state.activations],
  };
}

function refreshUI() {
  ui.room.textContent = state.room;
  ui.yaw.textContent = `${state.yaw.toFixed(2)}°`;
  ui.pitch.textContent = `${state.pitch.toFixed(2)}°`;
  ui.dwellId.textContent = state.dwellId ?? "—";
  ui.dwellMs.textContent = `${Math.round(state.dwellMs)} / ${DWELL_LIMIT_MS} ms`;
  ui.dwellBar.style.width = `${Math.min(100, (state.dwellMs / DWELL_LIMIT_MS) * 100)}%`;
  ui.activations.textContent = state.activations.length ? state.activations.join(" → ") : "None";
  ui.dwell.textContent = `Dwell: ${state.dwellEnabled ? "On" : "Off"}`;
  ui.dwell.setAttribute("aria-pressed", String(state.dwellEnabled));
  ui.crosshair.classList.toggle("active", state.dwellId !== null);
}

ui.reset.addEventListener("click", reset);
ui.dwell.addEventListener("click", () => setDwell(!state.dwellEnabled));
renderer.domElement.addEventListener("pointerdown", (event) => {
  if (event.button !== 0) return;
  const rect = renderer.domElement.getBoundingClientRect();
  const x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  const y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
  const id = pick(x, y);
  if (id !== null) activate(id);
});

window.addEventListener("resize", () => {
  const width = window.innerWidth;
  const height = window.innerHeight;
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(width, height);
});

setRoom("A");
applyCameraRotation();
refreshUI();

window.relayLab = {
  scene,
  camera,
  renderer,
  rooms,
  markers,
  pick,
  setView,
  setDwell,
  step,
  activate,
  reset,
  getState,
};

function animate() {
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
}
animate();
