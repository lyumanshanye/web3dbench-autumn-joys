import { JSDOM } from 'jsdom';

const dom = new JSDOM(`<!doctype html><html><body>
  <div id="viewport"></div>
  <span id="frame-readout"></span><dd id="time-readout"></dd>
  <dd id="paused-readout"></dd><dd id="selected-readout"></dd>
  <button id="pause-button"><span id="pause-icon"></span><span id="pause-label"></span></button>
  <button id="save-button"></button><button id="load-button"></button><button id="reset-button"></button>
  <p id="notice"></p><div id="legend-list"></div>
</body></html>`, { url: 'http://localhost:4173/' });

Object.assign(globalThis, {
  window: dom.window,
  document: dom.window.document,
  localStorage: dom.window.localStorage,
  HTMLElement: dom.window.HTMLElement,
  requestAnimationFrame: () => 0,
});

const context = {};
const gl = new Proxy({}, {
  get(target, key) {
    if (key === 'getParameter') return (parameter) => {
      if (parameter === 7938) return 'WebGL 2.0';
      if (parameter === 35724) return 'WebGL GLSL ES 3.00';
      return 0;
    };
    if (key === 'getExtension') return () => null;
    if (key === 'getContextAttributes') return () => ({ alpha: true, antialias: true });
    if (key === 'getShaderPrecisionFormat') return () => ({ precision: 23, rangeMin: 127, rangeMax: 127 });
    if (key === 'getProgramParameter' || key === 'getShaderParameter') return () => true;
    if (key === 'getProgramInfoLog' || key === 'getShaderInfoLog') return () => '';
    if (key === 'checkFramebufferStatus') return () => 36053;
    if (key === 'getSupportedExtensions') return () => [];
    if (key === 'createTexture' || key === 'createBuffer' || key === 'createFramebuffer') return () => ({});
    if (key === 'getUniformLocation') return () => ({});
    if (key === 'getAttribLocation') return () => 0;
    if (key === 'getActiveAttrib' || key === 'getActiveUniform') return () => null;
    if (key === 'getError') return () => 0;
    if (!(key in target)) target[key] = () => {};
    return target[key];
  },
});

dom.window.HTMLCanvasElement.prototype.getContext = () => gl;
dom.window.HTMLCanvasElement.prototype.getBoundingClientRect = () => ({ left: 0, top: 0, width: 800, height: 600, right: 800, bottom: 600 });
dom.window.Element.prototype.setPointerCapture = () => {};
dom.window.Element.prototype.releasePointerCapture = () => {};
globalThis.WebGLRenderingContext = dom.window.WebGLRenderingContext;
globalThis.WebGL2RenderingContext = dom.window.WebGL2RenderingContext;

await import('../src/main.js');
export const api = window.orbitFeedback;
export { dom, context };
