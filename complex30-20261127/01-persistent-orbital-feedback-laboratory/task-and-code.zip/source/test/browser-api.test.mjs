import assert from 'node:assert/strict';
import test from 'node:test';
import { api, dom } from './browser-entry.mjs';

const close = (actual, expected, tolerance = 1e-5) => assert.ok(Math.abs(actual - expected) <= tolerance, `${actual} is not within ${tolerance} of ${expected}`);
const probe = (id) => api.getState().probes.find((item) => item.id === id);

test('exposes the complete API and initial scene contract', () => {
  for (const key of ['scene', 'camera', 'renderer', 'controls', 'probes', 'getState', 'step', 'setPaused', 'setSpeed', 'setRadius', 'selectAt', 'save', 'load', 'reset']) {
    assert.ok(key in api, `missing ${key}`);
  }
  assert.equal(api.renderer.domElement.width, 800);
  assert.equal(api.renderer.domElement.height, 600);
  api.reset();
  close(api.camera.position.x, 0); close(api.camera.position.y, 8); close(api.camera.position.z, 12);
  const state = api.getState();
  assert.equal(state.version, 1); assert.equal(state.paused, false); assert.equal(state.selectedId, null);
  for (const item of state.probes) assert.equal(item.trail.length, 1);
});

test('fixed stepping rejects invalid values without mutation and keeps trails bounded', () => {
  api.reset();
  const before = api.getState();
  for (const bad of [-1, 1.5, NaN, '2', Infinity]) assert.equal(api.step(bad), false);
  assert.deepEqual(api.getState(), before);
  api.setPaused(true);
  assert.equal(api.step(120), true);
  const state = api.getState();
  assert.equal(state.frame, 120);
  close(state.time, 2);
  close(state.probes[0].angle, 2);
  close(state.probes[0].position.x, 2 * Math.cos(2));
  close(state.probes[0].position.z, 2 * Math.sin(2));
  assert.equal(state.probes[0].trail.length, 120);
  close(state.probes[0].trail.at(-1)[0], state.probes[0].position.x);
  assert.equal(api.step(0), true);
  assert.equal(api.getState().frame, 120);
});

test('speed and radius setters validate atomically and affect next frame', () => {
  api.reset();
  const before = api.getState();
  for (const bad of [NaN, Infinity, -4.1, 4.1, '2', true]) {
    assert.equal(api.setSpeed('p0', bad), false);
    assert.equal(api.setRadius('p0', bad), false);
  }
  assert.equal(api.setSpeed('p9', 1), false);
  assert.equal(api.setRadius('p9', 2), false);
  assert.deepEqual(api.getState(), before);
  assert.equal(api.setSpeed('p0', -4), true);
  assert.equal(api.setRadius('p0', 4), true);
  assert.equal(probe('p0').trail.length, 1);
  api.step(1);
  close(probe('p0').angle, -4 / 60);
  close(probe('p0').radius, 4);
  assert.equal(probe('p0').trail.length, 2);
});

test('selection raycast sets only selected emissive intensity; miss clears', () => {
  api.reset(); api.setPaused(true);
  const point = probe('p0').position;
  const world = api.camera.position.clone().set(...point).project(api.camera);
  const hit = api.selectAt((world.x + 1) * 400, (1 - world.y) * 300);
  assert.equal(hit, 'p0');
  assert.equal(api.getState().selectedId, 'p0');
  const intensities = api.probes.map((p) => p.id === 'p0');
  const meshes = api.scene.children.filter((o) => o.userData.probeId);
  for (const mesh of meshes) assert.equal(mesh.material.emissiveIntensity, mesh.userData.probeId === 'p0' ? 0.8 : 0);
  assert.equal(api.selectAt(1, 1), null);
  assert.ok(meshes.every((mesh) => mesh.material.emissiveIntensity === 0));
});

test('save, load, malformed rejection and startup-compatible snapshots', () => {
  api.reset();
  api.setSpeed('p1', 3);
  api.setRadius('p2', 1.5);
  api.setPaused(true);
  api.step(7);
  const world = probe('p2').position;
  const projected = api.camera.position.clone().set(...world).project(api.camera);
  assert.equal(api.selectAt((projected.x + 1) * 400, (1 - projected.y) * 300), 'p2');
  const saved = api.save();
  assert.deepEqual(JSON.parse(dom.window.localStorage.getItem('orbitFeedback.v1')), saved);
  assert.notEqual(saved, api.getState());
  api.step(2);
  assert.notDeepEqual(api.getState(), saved);
  assert.equal(api.load(), true);
  assert.deepEqual(api.getState(), saved);
  const live = api.getState();
  dom.window.localStorage.setItem('orbitFeedback.v1', '{bad json');
  assert.equal(api.load(), false);
  assert.deepEqual(api.getState(), live);
  dom.window.localStorage.setItem('orbitFeedback.v1', JSON.stringify({ ...live, version: 2 }));
  assert.equal(api.load(), false);
  assert.deepEqual(api.getState(), live);
  const missing = structuredClone(live); delete missing.probes;
  dom.window.localStorage.setItem('orbitFeedback.v1', JSON.stringify(missing));
  assert.equal(api.load(), false);
  const invalid = structuredClone(live); invalid.probes[0].angle = 'bad';
  dom.window.localStorage.setItem('orbitFeedback.v1', JSON.stringify(invalid));
  assert.equal(api.load(), false);
  assert.deepEqual(api.getState(), live);
});

test('reset restores all initial state, clears storage and camera', () => {
  api.reset();
  api.setPaused(false);
  api.setSpeed('p2', -4); api.step(8);
  api.camera.position.set(2, 2, 2); api.controls.target.set(1, 1, 1); api.controls.update();
  api.save();
  api.reset();
  assert.equal(dom.window.localStorage.getItem('orbitFeedback.v1'), null);
  const state = api.getState();
  assert.equal(state.time, 0); assert.equal(state.frame, 0); assert.equal(state.paused, false); assert.equal(state.selectedId, null);
  for (const item of state.probes) assert.equal(item.trail.length, 1);
  close(api.camera.position.x, 0); close(api.camera.position.y, 8); close(api.camera.position.z, 12);
  close(api.controls.target.x, 0); close(api.controls.target.y, 0); close(api.controls.target.z, 0);
});
