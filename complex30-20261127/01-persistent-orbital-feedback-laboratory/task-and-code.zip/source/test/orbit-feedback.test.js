import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';

const source = await readFile(new URL('../src/main.js', import.meta.url), 'utf8');
assert.match(source, /window\.orbitFeedback\s*=/);
assert.doesNotMatch(source, /fetch\(|XMLHttpRequest|https?:\/\//);
assert.match(source, /new THREE\.PerspectiveCamera\(42, 800 \/ 600, 0\.1, 100\)/);
assert.match(source, /new THREE\.CylinderGeometry\(0\.6, 0\.6, 1, 64\)/);
assert.match(source, /new THREE\.SphereGeometry\(0\.22, 32, 24\)/);
assert.match(source, /const DT = 1 \/ 60/);
assert.match(source, /const MAX_TRAIL_POINTS = 120/);
assert.match(source, /const STORAGE_KEY = 'orbitFeedback\.v1'/);
