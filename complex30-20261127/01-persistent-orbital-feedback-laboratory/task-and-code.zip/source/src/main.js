import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import './style.css';

const DT = 1 / 60;
const MAX_TRAIL_POINTS = 120;
const STORAGE_KEY = 'orbitFeedback.v1';
const PROBE_DEFINITIONS = [
  { id: 'p0', angle: 0, radius: 2, height: 0.5, speed: 1, color: 0x68e0b1 },
  { id: 'p1', angle: (2 * Math.PI) / 3, radius: 2.8, height: 1, speed: -1.5, color: 0x6ab8ff },
  { id: 'p2', angle: (4 * Math.PI) / 3, radius: 3.6, height: 1.5, speed: 2, color: 0xf4ad66 },
];
const CAMERA_POSITION = new THREE.Vector3(0, 8, 12);
const CAMERA_TARGET = new THREE.Vector3(0, 0, 0);
const PROBE_IDS = new Set(PROBE_DEFINITIONS.map(({ id }) => id));
const NUMBER_TOLERANCE = 1e-5;

const viewport = document.querySelector('#viewport');
const ui = {
  frame: document.querySelector('#frame-readout'),
  time: document.querySelector('#time-readout'),
  paused: document.querySelector('#paused-readout'),
  selected: document.querySelector('#selected-readout'),
  pauseButton: document.querySelector('#pause-button'),
  pauseLabel: document.querySelector('#pause-label'),
  pauseIcon: document.querySelector('#pause-icon'),
  saveButton: document.querySelector('#save-button'),
  loadButton: document.querySelector('#load-button'),
  resetButton: document.querySelector('#reset-button'),
  notice: document.querySelector('#notice'),
  legend: document.querySelector('#legend-list'),
};

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x071216);
scene.fog = new THREE.FogExp2(0x071216, 0.018);

const camera = new THREE.PerspectiveCamera(42, 800 / 600, 0.1, 100);
camera.position.copy(CAMERA_POSITION);
camera.lookAt(CAMERA_TARGET);

const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setSize(800, 600, false);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
viewport.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.copy(CAMERA_TARGET);
controls.enableDamping = true;
controls.dampingFactor = 0.07;
controls.minDistance = 4;
controls.maxDistance = 30;
controls.maxPolarAngle = Math.PI * 0.88;
controls.update();

const ambient = new THREE.HemisphereLight(0x9fd9cf, 0x14252a, 1.85);
scene.add(ambient);
const keyLight = new THREE.DirectionalLight(0xfff1d7, 3.2);
keyLight.position.set(7, 11, 6);
keyLight.castShadow = true;
keyLight.shadow.mapSize.set(1024, 1024);
keyLight.shadow.camera.left = -8;
keyLight.shadow.camera.right = 8;
keyLight.shadow.camera.top = 8;
keyLight.shadow.camera.bottom = -8;
scene.add(keyLight);
const rimLight = new THREE.PointLight(0x46d8c1, 20, 18, 2);
rimLight.position.set(-6, 5, -5);
scene.add(rimLight);

const stage = new THREE.Group();
scene.add(stage);

const floor = new THREE.Mesh(
  new THREE.CircleGeometry(9.5, 96),
  new THREE.MeshStandardMaterial({ color: 0x10272a, roughness: 0.88, metalness: 0.2 }),
);
floor.rotation.x = -Math.PI / 2;
floor.position.y = -0.53;
floor.receiveShadow = true;
stage.add(floor);

const grid = new THREE.GridHelper(18, 36, 0x2d625b, 0x183a3a);
grid.position.y = -0.515;
grid.material.opacity = 0.52;
grid.material.transparent = true;
stage.add(grid);

for (const radius of [2, 2.8, 3.6]) {
  const ringPoints = [];
  for (let i = 0; i <= 128; i += 1) {
    const angle = (i / 128) * Math.PI * 2;
    ringPoints.push(new THREE.Vector3(radius * Math.cos(angle), -0.505, radius * Math.sin(angle)));
  }
  const ring = new THREE.Line(
    new THREE.BufferGeometry().setFromPoints(ringPoints),
    new THREE.LineDashedMaterial({ color: 0x3e6b65, dashSize: 0.1, gapSize: 0.11, transparent: true, opacity: 0.55 }),
  );
  ring.computeLineDistances();
  stage.add(ring);
}

const core = new THREE.Mesh(
  new THREE.CylinderGeometry(0.6, 0.6, 1, 64),
  new THREE.MeshStandardMaterial({ color: 0x94d8c1, roughness: 0.3, metalness: 0.65, emissive: 0x17493f, emissiveIntensity: 0.3 }),
);
core.castShadow = true;
core.receiveShadow = true;
stage.add(core);
const coreCap = new THREE.Mesh(
  new THREE.TorusGeometry(0.61, 0.025, 12, 72),
  new THREE.MeshStandardMaterial({ color: 0xd1fff0, roughness: 0.25, metalness: 0.5, emissive: 0x55e5b0, emissiveIntensity: 0.25 }),
);
coreCap.rotation.x = Math.PI / 2;
coreCap.position.y = 0.51;
stage.add(coreCap);

const sphereGeometry = new THREE.SphereGeometry(0.22, 32, 24);
const probeVisuals = new Map();
for (const definition of PROBE_DEFINITIONS) {
  const material = new THREE.MeshStandardMaterial({
    color: definition.color,
    roughness: 0.24,
    metalness: 0.36,
    emissive: definition.color,
    emissiveIntensity: 0,
  });
  const mesh = new THREE.Mesh(sphereGeometry, material);
  mesh.name = `probe-${definition.id}`;
  mesh.userData.probeId = definition.id;
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  scene.add(mesh);

  const halo = new THREE.Mesh(
    new THREE.RingGeometry(0.28, 0.33, 32),
    new THREE.MeshBasicMaterial({ color: definition.color, transparent: true, opacity: 0.38, side: THREE.DoubleSide, depthWrite: false }),
  );
  halo.rotation.x = -Math.PI / 2;
  scene.add(halo);

  const trail = new THREE.Line(
    new THREE.BufferGeometry(),
    new THREE.LineBasicMaterial({ color: definition.color, transparent: true, opacity: 0.68 }),
  );
  trail.frustumCulled = false;
  scene.add(trail);

  probeVisuals.set(definition.id, { mesh, halo, trail });
}

const probes = PROBE_DEFINITIONS.map((definition) => ({
  ...definition,
  position: new THREE.Vector3(),
  trail: [],
}));

let time = 0;
let frame = 0;
let paused = false;
let selectedId = null;
let accumulator = 0;
let lastTimestamp = null;

function computePosition(probe) {
  return new THREE.Vector3(
    probe.radius * Math.cos(probe.angle),
    probe.height,
    probe.radius * Math.sin(probe.angle),
  );
}

function positionToArray(point) {
  return [point.x, point.y, point.z];
}

function syncTrail(probe) {
  const visual = probeVisuals.get(probe.id);
  const positions = new Float32Array(probe.trail.length * 3);
  probe.trail.forEach((point, index) => positions.set(positionToArray(point), index * 3));
  visual.trail.geometry.dispose();
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  visual.trail.geometry = geometry;
}

function syncProbeMeshes() {
  for (const probe of probes) {
    const visual = probeVisuals.get(probe.id);
    visual.mesh.position.copy(probe.position);
    visual.halo.position.set(probe.position.x, -0.49, probe.position.z);
  }
}

function updateSelectionAppearance() {
  for (const probe of probes) {
    const visual = probeVisuals.get(probe.id);
    visual.mesh.material.emissiveIntensity = probe.id === selectedId ? 0.8 : 0;
    visual.halo.material.opacity = probe.id === selectedId ? 0.9 : 0.38;
  }
}

function updateUI() {
  ui.frame.textContent = String(frame).padStart(6, '0');
  ui.time.textContent = `${time.toFixed(4)} `;
  const suffix = document.createElement('small');
  suffix.textContent = 's';
  ui.time.appendChild(suffix);
  ui.paused.textContent = paused ? 'Paused' : 'Running';
  ui.selected.textContent = selectedId ?? 'None';
  ui.pauseLabel.textContent = paused ? 'Resume' : 'Pause';
  ui.pauseIcon.textContent = paused ? '▶' : 'Ⅱ';
  ui.pauseButton.setAttribute('aria-pressed', String(paused));
  for (const probe of probes) {
    const item = ui.legend.querySelector(`[data-probe="${probe.id}"] .legend-detail`);
    if (item) item.textContent = `${probe.radius.toFixed(1)}r / ${probe.speed > 0 ? '+' : ''}${probe.speed.toFixed(1)}`;
  }
}

function setNotice(message, tone = '') {
  ui.notice.textContent = message;
  ui.notice.className = `notice ${tone}`.trim();
}

function advanceFrame() {
  for (const probe of probes) {
    probe.angle += probe.speed * DT;
    probe.position.copy(computePosition(probe));
    probe.trail.push(probe.position.clone());
    if (probe.trail.length > MAX_TRAIL_POINTS) probe.trail.shift();
    syncTrail(probe);
  }
  time += DT;
  frame += 1;
  syncProbeMeshes();
}

function step(count) {
  if (!Number.isInteger(count) || count < 0) return false;
  for (let i = 0; i < count; i += 1) advanceFrame();
  updateUI();
  return true;
}

function setPaused(value) {
  paused = Boolean(value);
  accumulator = 0;
  updateUI();
}

function validProbeId(id) {
  return typeof id === 'string' && PROBE_IDS.has(id);
}

function setSpeed(id, value) {
  if (!validProbeId(id) || typeof value !== 'number' || !Number.isFinite(value) || value < -4 || value > 4) return false;
  probes.find((probe) => probe.id === id).speed = value;
  updateUI();
  return true;
}

function setRadius(id, value) {
  if (!validProbeId(id) || typeof value !== 'number' || !Number.isFinite(value) || value < 1.5 || value > 4) return false;
  probes.find((probe) => probe.id === id).radius = value;
  updateUI();
  return true;
}

function selectAt(clientX, clientY) {
  const rect = renderer.domElement.getBoundingClientRect();
  if (rect.width <= 0 || rect.height <= 0) return null;
  const pointer = new THREE.Vector2(
    ((clientX - rect.left) / rect.width) * 2 - 1,
    -((clientY - rect.top) / rect.height) * 2 + 1,
  );
  const raycaster = new THREE.Raycaster();
  raycaster.setFromCamera(pointer, camera);
  const intersections = raycaster.intersectObjects(probes.map((probe) => probeVisuals.get(probe.id).mesh), false);
  selectedId = intersections.length > 0 ? intersections[0].object.userData.probeId : null;
  updateSelectionAppearance();
  updateUI();
  setNotice(selectedId ? `Probe ${selectedId} acquired.` : 'No probe under cursor.', selectedId ? 'success' : '');
  return selectedId;
}

function getState() {
  return {
    version: 1,
    time,
    frame,
    paused,
    selectedId,
    probes: probes.map((probe) => ({
      id: probe.id,
      angle: probe.angle,
      radius: probe.radius,
      height: probe.height,
      speed: probe.speed,
      position: positionToArray(probe.position),
      trail: probe.trail.map(positionToArray),
    })),
  };
}

function save() {
  const state = getState();
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  return state;
}

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function isFiniteNumber(value) {
  return typeof value === 'number' && Number.isFinite(value);
}

function isPosition(value) {
  return Array.isArray(value)
    && value.length === 3
    && value.every((coordinate) => isFiniteNumber(coordinate));
}

function parseSnapshot(value) {
  if (!isPlainObject(value) || value.version !== 1) return null;
  if (!isFiniteNumber(value.time) || value.time < 0) return null;
  if (!Number.isInteger(value.frame) || value.frame < 0) return null;
  if (typeof value.paused !== 'boolean') return null;
  if (value.selectedId !== null && !validProbeId(value.selectedId)) return null;
  if (!Array.isArray(value.probes) || value.probes.length !== probes.length) return null;

  const byId = new Map();
  for (const item of value.probes) {
    if (!isPlainObject(item) || !validProbeId(item.id) || byId.has(item.id)) return null;
    if (!isFiniteNumber(item.angle) || !isFiniteNumber(item.radius) || item.radius < 1.5 || item.radius > 4) return null;
    if (!isFiniteNumber(item.height) || !isFiniteNumber(item.speed) || item.speed < -4 || item.speed > 4) return null;
    if (!isPosition(item.position) || !Array.isArray(item.trail) || item.trail.length === 0 || item.trail.length > MAX_TRAIL_POINTS) return null;
    if (!item.trail.every(isPosition)) return null;
    byId.set(item.id, {
      id: item.id,
      angle: item.angle,
      radius: item.radius,
      height: item.height,
      speed: item.speed,
      position: [...item.position],
      trail: item.trail.map((point) => [...point]),
    });
  }
  if (!probes.every((probe) => byId.has(probe.id))) return null;
  return {
    version: 1,
    time: value.time,
    frame: value.frame,
    paused: value.paused,
    selectedId: value.selectedId,
    probes: byId,
  };
}

function load() {
  let parsed;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw === null) return false;
    parsed = parseSnapshot(JSON.parse(raw));
  } catch {
    return false;
  }
  if (!parsed) return false;

  time = parsed.time;
  frame = parsed.frame;
  paused = parsed.paused;
  selectedId = parsed.selectedId;
  accumulator = 0;
  lastTimestamp = null;
  for (const probe of probes) {
    const saved = parsed.probes.get(probe.id);
    probe.angle = saved.angle;
    probe.radius = saved.radius;
    probe.height = saved.height;
    probe.speed = saved.speed;
    probe.position.set(...saved.position);
    probe.trail = saved.trail.map((point) => new THREE.Vector3(...point));
    syncTrail(probe);
  }
  syncProbeMeshes();
  updateSelectionAppearance();
  updateUI();
  return true;
}

function createInitialProbes() {
  for (const probe of probes) {
    const definition = PROBE_DEFINITIONS.find(({ id }) => id === probe.id);
    Object.assign(probe, definition);
    probe.position.copy(computePosition(probe));
    probe.trail = [probe.position.clone()];
    syncTrail(probe);
  }
}

function reset() {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // Storage may be disabled by browser privacy settings.
  }
  createInitialProbes();
  time = 0;
  frame = 0;
  paused = false;
  selectedId = null;
  accumulator = 0;
  lastTimestamp = null;
  camera.position.copy(CAMERA_POSITION);
  camera.up.set(0, 1, 0);
  controls.target.copy(CAMERA_TARGET);
  controls.update();
  syncProbeMeshes();
  updateSelectionAppearance();
  updateUI();
  setNotice('Laboratory restored to initial conditions.', 'success');
}

function setupInterface() {
for (const definition of PROBE_DEFINITIONS) {
  const item = document.createElement('div');
  item.className = 'legend-item';
  item.dataset.probe = definition.id;
  const swatch = document.createElement('span');
  swatch.className = 'legend-swatch';
  swatch.style.color = `#${definition.color.toString(16).padStart(6, '0')}`;
  swatch.style.background = swatch.style.color;
  const name = document.createElement('span');
  name.className = 'legend-name';
  name.textContent = definition.id.toUpperCase();
  const detail = document.createElement('span');
  detail.className = 'legend-detail';
  item.append(swatch, name, detail);
  ui.legend.appendChild(item);
}

ui.pauseButton.addEventListener('click', () => {
  setPaused(!paused);
  setNotice(paused ? 'Simulation paused.' : 'Simulation running.');
});
ui.saveButton.addEventListener('click', () => {
  try {
    save();
    setNotice('Snapshot saved locally.', 'success');
  } catch {
    setNotice('Snapshot could not be saved.', 'error');
  }
});
ui.loadButton.addEventListener('click', () => {
  const restored = load();
  setNotice(restored ? 'Snapshot restored.' : 'No valid snapshot found.', restored ? 'success' : 'error');
});
ui.resetButton.addEventListener('click', reset);
}

function render(timestamp) {
  requestAnimationFrame(render);
  if (lastTimestamp === null) lastTimestamp = timestamp;
  const elapsed = Math.min((timestamp - lastTimestamp) / 1000, 0.25);
  lastTimestamp = timestamp;
  if (!paused) {
    accumulator += elapsed;
    const framesToAdvance = Math.floor((accumulator + NUMBER_TOLERANCE) / DT);
    if (framesToAdvance > 0) {
      accumulator -= framesToAdvance * DT;
      step(framesToAdvance);
    }
  } else {
    accumulator = 0;
  }
  controls.update();
  renderer.render(scene, camera);
}

setupInterface();
createInitialProbes();
syncProbeMeshes();
updateSelectionAppearance();
updateUI();
let loadedAtStartup = false;
try {
  loadedAtStartup = load();
} catch {
  loadedAtStartup = false;
}
if (!loadedAtStartup) setNotice('Click a probe to select it.');
else setNotice('Saved snapshot restored.');

window.orbitFeedback = {
  scene,
  camera,
  renderer,
  controls,
  probes,
  getState,
  step,
  setPaused,
  setSpeed,
  setRadius,
  selectAt,
  save,
  load,
  reset,
};

requestAnimationFrame(render);
