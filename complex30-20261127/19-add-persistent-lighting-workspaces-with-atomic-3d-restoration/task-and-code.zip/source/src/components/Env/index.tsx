import { lightAtomsAtom, lightsAtom } from "../../store";
import { useAtomValue } from "jotai";
import { LightRenderer } from "./LightRenderer";

export function Env({ enableEvents = false }: { enableEvents?: boolean }) {
  const lightAtoms = useAtomValue(lightAtomsAtom);
  const lightIds = useAtomValue(lightsAtom).map((light) => light.id);

  return (
    <>
      <color attach="background" args={["black"]} />
      {lightAtoms.map((lightAtom, i) => (
        <LightRenderer
          key={lightIds[i]}
          index={i}
          lightAtom={lightAtom}
          enableEvents={enableEvents}
        />
      ))}
    </>
  );
}
