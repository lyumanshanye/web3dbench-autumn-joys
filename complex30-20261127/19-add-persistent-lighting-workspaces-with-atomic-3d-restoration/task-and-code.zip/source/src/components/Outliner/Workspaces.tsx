import { useState } from "react";
import { useAtomValue, useSetAtom } from "jotai";
import { toast } from "sonner";
import {
  deleteWorkspaceAtom,
  loadWorkspaceAtom,
  saveWorkspaceAtom,
  workspacesAtom,
} from "../../store";
import { MAX_WORKSPACE_NAME_LENGTH } from "../../utils/workspaces";

export function Workspaces() {
  const workspaces = useAtomValue(workspacesAtom);
  const saveWorkspace = useSetAtom(saveWorkspaceAtom);
  const loadWorkspace = useSetAtom(loadWorkspaceAtom);
  const deleteWorkspace = useSetAtom(deleteWorkspaceAtom);
  const [name, setName] = useState("");

  function handleSave() {
    const result = saveWorkspace(name);
    if (!result.ok) {
      toast.error(result.error);
      return;
    }

    setName("");
    toast.success(`Saved workspace “${result.workspace.name}”.`);
  }

  return (
    <section className="border-t border-white/10">
      <div className="flex justify-between items-center p-4 border-b border-white/10">
        <h2 className="uppercase font-light text-xs tracking-widest text-gray-300">
          Workspaces
        </h2>
      </div>

      <form
        className="flex flex-col gap-2 p-2"
        onSubmit={(event) => {
          event.preventDefault();
          handleSave();
        }}
      >
        <input
          aria-label="Workspace name"
          type="text"
          value={name}
          maxLength={MAX_WORKSPACE_NAME_LENGTH}
          onChange={(event) => setName(event.target.value)}
          placeholder="Workspace name"
          className="min-w-0 w-full rounded-md bg-white/5 border border-white/10 px-2 py-1.5 text-xs font-mono text-neutral-100 placeholder:text-neutral-500 outline-none focus:border-white/40"
        />
        <button
          type="submit"
          className="rounded-md bg-white/10 border border-white/10 px-2 py-1.5 text-xs hover:bg-white/20 transition-colors"
        >
          Save workspace
        </button>
      </form>

      {workspaces.length > 0 && (
        <ul className="m-0 px-2 pb-2 flex flex-col gap-1">
          {workspaces.map((workspace) => (
            <li
              key={workspace.id}
              className="flex items-center gap-1 p-1.5 rounded-md bg-white/5"
            >
              <span
                title={workspace.name}
                className="flex-1 min-w-0 text-xs font-mono text-neutral-300 text-ellipsis overflow-hidden whitespace-nowrap"
              >
                {workspace.name}
              </span>
              <button
                type="button"
                aria-label={`Load ${workspace.name}`}
                onClick={() => {
                  if (loadWorkspace(workspace.id)) {
                    toast.success(`Loaded workspace “${workspace.name}”.`);
                  }
                }}
                className="rounded px-1.5 py-1 text-xs bg-white/10 hover:bg-white/20 transition-colors"
              >
                Load
              </button>
              <button
                type="button"
                aria-label={`Delete ${workspace.name}`}
                onClick={() => deleteWorkspace(workspace.id)}
                className="rounded px-1.5 py-1 text-xs text-red-200 hover:bg-red-500/30 transition-colors"
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
