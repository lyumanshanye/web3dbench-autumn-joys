import * as THREE from "three";
import type { Camera, Light } from "../store";

export const WORKSPACES_STORAGE_KEY = "env.workspaces.v1";
export const MAX_WORKSPACE_NAME_LENGTH = 40;

export type Workspace = {
  version: 1;
  id: string;
  name: string;
  createdAt: number;
  lights: Light[];
  cameras: Camera[];
};

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export function isWorkspace(value: unknown): value is Workspace {
  return (
    isObject(value) &&
    value.version === 1 &&
    typeof value.id === "string" &&
    value.id.length > 0 &&
    typeof value.name === "string" &&
    typeof value.createdAt === "number" &&
    Number.isFinite(value.createdAt) &&
    Array.isArray(value.lights) &&
    Array.isArray(value.cameras)
  );
}

export function readWorkspaces(): Workspace[] {
  try {
    const raw = window.localStorage.getItem(WORKSPACES_STORAGE_KEY);
    if (raw === null) {
      return [];
    }

    const parsed: unknown = JSON.parse(raw);
    if (!Array.isArray(parsed)) {
      return [];
    }

    return parsed.filter(isWorkspace);
  } catch {
    return [];
  }
}

export function persistWorkspaces(workspaces: Workspace[]): void {
  try {
    window.localStorage.setItem(
      WORKSPACES_STORAGE_KEY,
      JSON.stringify(workspaces)
    );
  } catch {
    // Storage can be unavailable or full; the in-memory workspace list still works.
  }
}

export function validateWorkspaceName(
  name: string,
  workspaces: Workspace[]
): { name: string; error?: string } {
  const trimmedName = name.trim();

  if (trimmedName.length === 0) {
    return { name: trimmedName, error: "Enter a workspace name." };
  }

  if (trimmedName.length > MAX_WORKSPACE_NAME_LENGTH) {
    return {
      name: trimmedName,
      error: `Workspace names must be 1–${MAX_WORKSPACE_NAME_LENGTH} characters.`,
    };
  }

  const normalizedName = trimmedName.toLocaleLowerCase();
  if (
    workspaces.some(
      (workspace) =>
        workspace.name.trim().toLocaleLowerCase() === normalizedName
    )
  ) {
    return {
      name: trimmedName,
      error: `A workspace named “${trimmedName}” already exists.`,
    };
  }

  return { name: trimmedName };
}

export function createWorkspace(
  name: string,
  lights: Light[],
  cameras: Camera[]
): Workspace {
  return {
    version: 1,
    id: THREE.MathUtils.generateUUID(),
    name,
    createdAt: Date.now(),
    lights: structuredClone(lights),
    cameras: structuredClone(cameras),
  };
}
