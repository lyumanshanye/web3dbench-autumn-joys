import THREE from "../three";

const FIXTURE_FRAMES = [
  [0, 0.25, 0.5],
  [0.5, 0.75, 1],
  [1, 0.5, 0],
  [0.2, 0.4, 0.6],
];

export const FIXTURE_DURATION = FIXTURE_FRAMES.length - 1;

export default class FixtureViz {
  constructor(container) {
    this.container = container;
    this.time = 0;
    this.playing = false;
    this.playStartTime = null;
    this.playStartFixtureTime = 0;
    this.animationFrame = null;
    this.cells = [];
    this.geometries = [];
    this.materials = [];

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(45, 1, 0.1, 1000);
    this.camera.position.set(8, 8, 8);
    this.camera.lookAt(0, 0, 0);

    this.renderer = new THREE.WebGLRenderer({antialias: true});
    this.renderer.setPixelRatio(window.devicePixelRatio);
    this.renderer.setClearColor(0x18232b, 1);
    this.container.appendChild(this.renderer.domElement);

    this.root = new THREE.Group();
    this.root.name = "fixture-root";
    this.scene.add(this.root);

    this.geometries.push(new THREE.BoxGeometry(1, 1, 1));
    this.createCells();
    this.resize();
    this.setTime(0);
  }

  createCells() {
    const colors = [0xffc857, 0x5fd4c4, 0xff6b6b];

    for (let row = 0; row < 3; row++) {
      for (let col = 0; col < 3; col++) {
        const feature = (row * 3 + col) % 3;
        const material = new THREE.MeshPhongMaterial({
          color: colors[feature],
          shininess: 30,
        });
        const cell = new THREE.Mesh(this.geometries[0], material);
        cell.name = `cell-${row}-${col}`;
        cell.position.x = (col - 1) * 2;
        cell.position.z = (row - 1) * 2;
        cell.userData.feature = feature;
        this.materials.push(material);
        this.cells.push(cell);
        this.root.add(cell);
      }
    }

    this.scene.add(new THREE.AmbientLight(0xffffff, 0.65));
    const light = new THREE.DirectionalLight(0xffffff, 0.8);
    light.position.set(6, 10, 8);
    this.scene.add(light);
  }

  sampleFeatures(time) {
    if (time >= FIXTURE_DURATION) {
      return FIXTURE_FRAMES[FIXTURE_DURATION].slice();
    }

    const frame = Math.floor(time);
    const mix = time - frame;
    const from = FIXTURE_FRAMES[frame];
    const to = FIXTURE_FRAMES[frame + 1];
    return from.map((value, index) => value + (to[index] - value) * mix);
  }

  renderTime(time) {
    const features = this.sampleFeatures(time);

    this.cells.forEach(cell => {
      const height = 0.5 + 2 * features[cell.userData.feature];
      cell.scale.set(1, height, 1);
      cell.position.y = height / 2;
    });

    this.root.rotation.y = time * Math.PI / 4;
    this.renderer.render(this.scene, this.camera);
  }

  resize() {
    const width = this.container.clientWidth || 1;
    const height = this.container.clientHeight || 1;
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
  }

  start() {
    this.pause();
    this.time = 0;
    this.resize();
    this.renderTime(this.time);
  }

  setTime(time) {
    if (typeof time !== "number" || !Number.isFinite(time)) {
      throw new TypeError("Fixture time must be a finite number");
    }

    this.time = Math.min(FIXTURE_DURATION, Math.max(0, time));
    this.renderTime(this.time);
    return this.time;
  }

  play() {
    if (this.playing) return;

    this.playing = true;
    this.playStartFixtureTime = this.time;
    this.playStartTime = this.monotonicNow();
    this.animationFrame = requestAnimationFrame(() => this.tick());
  }

  tick() {
    this.animationFrame = null;
    if (!this.playing) return;

    const elapsed = (this.monotonicNow() - this.playStartTime) / 1000;
    const nextTime = Math.min(FIXTURE_DURATION, this.playStartFixtureTime + elapsed);
    this.time = nextTime;
    this.renderTime(this.time);

    if (nextTime >= FIXTURE_DURATION) {
      this.pause();
      return;
    }
    this.animationFrame = requestAnimationFrame(() => this.tick());
  }

  pause() {
    this.playing = false;
    if (this.animationFrame !== null) {
      cancelAnimationFrame(this.animationFrame);
      this.animationFrame = null;
    }
    this.playStartTime = null;
  }

  monotonicNow() {
    return window.performance && typeof window.performance.now === "function"
      ? window.performance.now()
      : Date.now();
  }

  getState() {
    return {
      time: this.time,
      heights: this.cells.map(cell => cell.scale.y),
      rotationY: this.root.rotation.y,
    };
  }

  destroy() {
    this.pause();
    this.scene.remove(this.root);

    this.geometries.forEach(geometry => geometry.dispose());
    this.materials.forEach(material => material.dispose());
    this.geometries = [];
    this.materials = [];
    this.cells = [];

    if (this.renderer.domElement.parentNode === this.container) {
      this.container.removeChild(this.renderer.domElement);
    }
    this.renderer.dispose();

    if (window.fixtureViz === this) {
      window.fixtureViz = null;
    }
  }
}
