import * as THREE from "three";
import {OrbitControls} from "three/examples/jsm/controls/OrbitControls";
import { SuperFlow } from "./objects/SuperFlow";
import * as Tone from "tone";
import { Ambient } from "./sound/ambient";

const MARKER_COUNT = 8;
const DEFAULT_MARKER_COLOR = 0x40c0c0;
const SELECTED_MARKER_COLOR = 0xff8000;
const STEP_SECONDS = 0.25;

const startButton = document.getElementById('startButton');
startButton.addEventListener('click', async () => {
    await Tone.start();
    console.log("audio is ready");
    new Ambient();
    init();
});

//init();
function init(){
    const overlay = document.getElementById('overlay');
    if (overlay) overlay.remove();
    const tf = document.getElementById("TetraFlow");
    tf.style.display = "block";

    let scene = new THREE.Scene();
    let camera = new THREE.PerspectiveCamera(45, innerWidth / innerHeight, 1, 5000);
    camera.position.set(0, 2.5, 12).setLength(17);
    let renderer = new THREE.WebGLRenderer({antialias: true});
    renderer.setSize(innerWidth, innerHeight);
    //renderer.setClearColor(0x003040);
    document.body.appendChild(renderer.domElement);
    window.addEventListener("resize", event => {
        camera.aspect = innerWidth / innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(innerWidth, innerHeight);
    })

    let controls = new OrbitControls(camera, renderer.domElement);
    controls.enablePan = false;
    controls.enableDamping = true;
    controls.minPolarAngle = Math.PI * 0.25;
    controls.maxPolarAngle = Math.PI * 0.75;
    controls.minDistance = 10;
    controls.maxDistance = 20;

    let light = new THREE.PointLight(0x7fffff, 1.0);
    scene.add(light, new THREE.AmbientLight(0xffffff, 0.375));

    let superFlow = new SuperFlow(camera);
    scene.add(superFlow);

    const inspectionRig = new THREE.Group();
    inspectionRig.name = "inspectionRig";
    inspectionRig.position.set(0, 0, 0);
    scene.add(inspectionRig);

    const inspectionRing = new THREE.Mesh(
        new THREE.TorusGeometry(4, 0.02, 8, 96),
        new THREE.MeshBasicMaterial({ color: DEFAULT_MARKER_COLOR })
    );
    inspectionRing.name = "inspectionRing";
    inspectionRing.rotation.x = Math.PI / 2;
    inspectionRig.add(inspectionRing);

    const markers = [];
    for (let i = 0; i < MARKER_COUNT; i++) {
        const a = 2 * Math.PI * i / MARKER_COUNT;
        const marker = new THREE.Mesh(
            new THREE.TetrahedronGeometry(0.3, 0),
            new THREE.MeshBasicMaterial({ color: DEFAULT_MARKER_COLOR })
        );
        marker.name = `marker-${i}`;
        marker.position.set(4 * Math.cos(a), 0, 4 * Math.sin(a));
        marker.userData.markerIndex = i;
        markers.push(marker);
        inspectionRig.add(marker);
    }

    let simulationTime = 0;
    let paused = false;
    let selectedIndex = -1;

    const flowStatus = document.createElement("div");
    flowStatus.id = "flowStatus";
    flowStatus.className = "info";
    flowStatus.textContent = "Selected marker: none";
    document.body.appendChild(flowStatus);

    const help = document.createElement("div");
    help.id = "flowHelp";
    help.className = "info";
    help.textContent = "Space: play/pause | ArrowRight: step 0.25s (paused) | R: reset | Click a marker to inspect";
    document.body.appendChild(help);

    const raycaster = new THREE.Raycaster();
    const pointer = new THREE.Vector2();

    function applyRigTransforms() {
        inspectionRig.rotation.y = 0.25 * simulationTime;
        markers.forEach((marker, i) => {
            marker.rotation.x = 0.5 * simulationTime + i * Math.PI / 4;
            marker.rotation.z = -0.2 * simulationTime;
        });
    }

    function updateStatus() {
        flowStatus.textContent = selectedIndex < 0
            ? "Selected marker: none"
            : `Selected marker: ${selectedIndex}`;
    }

    function selectMarker(index) {
        selectedIndex = index;
        markers.forEach((marker, i) => {
            marker.material.color.setHex(i === index ? SELECTED_MARKER_COLOR : DEFAULT_MARKER_COLOR);
        });
        updateStatus();
    }

    function clearSelection() {
        selectMarker(-1);
    }

    function step() {
        if (!paused) return;
        simulationTime += STEP_SECONDS;
        applyRigTransforms();
        superFlow.update(simulationTime);
        renderer.render(scene, camera);
    }

    function reset() {
        simulationTime = 0;
        paused = true;
        clearSelection();
        camera.position.set(0, 2.5, 12).setLength(17);
        controls.target.set(0, 0, 0);
        controls.update();
        applyRigTransforms();
        superFlow.update(simulationTime);
        renderer.render(scene, camera);
    }

    function isModifiedKey(event) {
        return event.ctrlKey || event.metaKey || event.altKey || event.shiftKey;
    }

    window.addEventListener("keydown", event => {
        if (event.repeat || isModifiedKey(event)) return;
        if (event.code === "Space") {
            event.preventDefault();
            paused = !paused;
        } else if (event.code === "ArrowRight") {
            event.preventDefault();
            if (paused) step();
        } else if (event.code === "KeyR") {
            event.preventDefault();
            reset();
        }
    });

    function pickMarker(event) {
        if (event.button !== 0) return;
        const rect = renderer.domElement.getBoundingClientRect();
        if (rect.width === 0 || rect.height === 0) return;
        pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
        pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
        raycaster.setFromCamera(pointer, camera);
        const hits = raycaster.intersectObjects(markers, false);
        if (hits.length > 0) {
            let lowest = Infinity;
            for (const hit of hits) {
                const index = hit.object.userData.markerIndex;
                if (index < lowest) lowest = index;
            }
            selectMarker(lowest);
        } else {
            clearSelection();
        }
    }

    renderer.domElement.addEventListener("click", pickMarker);

    applyRigTransforms();

    window.tetraFlowDiagnostics = {
        scene,
        camera,
        controls,
        superFlow,
        rig: inspectionRig,
        markers,
        getSimulationTime: () => simulationTime,
        isPaused: () => paused,
        step,
        reset
    };

    let clock = new THREE.Clock();

    renderer.setAnimationLoop(() => {
        const delta = clock.getDelta();
        if (!paused) {
            simulationTime += delta;
            applyRigTransforms();
            superFlow.update(simulationTime);
        }
        controls.update();
        renderer.render(scene, camera);
    });
}
