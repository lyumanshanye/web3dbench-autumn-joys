import * as THREE from 'three';
import './style.css';

const STEPS_PER_FRAME = 0.0015;
const TUNNEL_STEP = 0.00025;
const SELECTED_EMISSIVE = 0x552200;
const OFF_EMISSIVE = 0x000000;

const COIN_FIXTURE = [
  [0, 0, 0.10],
  [Math.PI / 4, 0.25, 0.25],
  [Math.PI / 2, 0.5, 0.40],
  [3 * Math.PI / 4, 0.75, 0.55],
  [Math.PI, 1, 0.70],
  [5 * Math.PI / 4, 0.125, 0.85],
  [3 * Math.PI / 2, 0.375, 0],
  [7 * Math.PI / 4, 0.625, 0.95],
];

const canvas = document.querySelector('#scene');
const stepsReadout = document.querySelector('#readout-steps');
const rotationReadout = document.querySelector('#readout-rotation');
const selectedReadout = document.querySelector('#readout-selected');

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x08080c);

const camera = new THREE.PerspectiveCamera(35, window.innerWidth / window.innerHeight, 0.1, 2000);

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.15;

const lightLeft = new THREE.DirectionalLight(0xffffff, 1.5);
lightLeft.position.set(-1, 0, 0);
const lightRight = new THREE.DirectionalLight(0xffffff, 1.5);
lightRight.position.set(1, 0, 0);
// Keep the specified wide scene lights while illuminating faces along the tunnel axis.
scene.add(lightLeft, lightLeft.target, lightRight, lightRight.target);

const tunnel = new THREE.Group();
tunnel.name = 'tunnel';
scene.add(tunnel);

const shellGeometry = new THREE.CylinderGeometry(60, 60, 400, 32, 1, true);
const shellMaterial = new THREE.MeshBasicMaterial({
  color: 0x4b3d25,
  wireframe: true,
  transparent: true,
  opacity: 0.18,
  side: THREE.DoubleSide,
});
const tunnelShell = new THREE.Mesh(shellGeometry, shellMaterial);
tunnelShell.name = 'tunnel-shell';
tunnelShell.rotation.x = Math.PI / 2;
tunnelShell.raycast = () => {};
tunnel.add(tunnelShell);

const goldMaterial = new THREE.MeshStandardMaterial({
  color: 0xe4b64a,
  emissive: OFF_EMISSIVE,
  metalness: 0.42,
  roughness: 0.3,
});
const coinGeometry = new THREE.CylinderGeometry(3, 3, 0.54, 16);
const rimGeometry = new THREE.TorusGeometry(3, 0.3, 8, 64);
rimGeometry.scale(1, 1, 5.2);
const pickMeshes = [];

const coins = COIN_FIXTURE.map(([angle, q, initialProgress], index) => {
  const coin = new THREE.Group();
  coin.name = `coin-${index}`;
  coin.userData.index = index;
  coin.userData.angle = angle;
  coin.userData.q = q;
  coin.userData.initialProgress = initialProgress;
  coin.userData.p = initialProgress;

  const face = new THREE.Mesh(coinGeometry, goldMaterial.clone());
  face.name = `coin-${index}-face`;
  face.rotation.x = Math.PI / 2;
  face.userData.coin = coin;

  const rim = new THREE.Mesh(rimGeometry, goldMaterial.clone());
  const faceGlow = new THREE.PointLight(0xffd27a, 110, 22, 2);
  faceGlow.position.set(0, 0, 4);
  rim.name = `coin-${index}-rim`;
  rim.userData.coin = coin;

  coin.add(face, rim, faceGlow);
  tunnel.add(coin);
  pickMeshes.push(face, rim);
  return coin;
});

let steps = 0;
let selected = null;

const cos = Math.cos;
const sin = Math.sin;
const sqrt = Math.sqrt;

function updateCoinTransform(coin) {
  const p = coin.userData.p;
  const radius = 12 + 48 * sqrt(coin.userData.q);
  coin.position.set(
    radius * cos(coin.userData.angle),
    200 - 400 * p,
    radius * sin(coin.userData.angle),
  );
  coin.scale.setScalar(Math.min(1, p / 0.05));
}

function refreshCoins() {
  for (const coin of coins) updateCoinTransform(coin);
}

function setCoinMaterials(coin, emissive) {
  for (const child of coin.children) {
    if (child.isMesh) child.material.emissive.setHex(emissive);
  }
}

function clearSelection() {
  selected = null;
  for (const coin of coins) setCoinMaterials(coin, OFF_EMISSIVE);
}

function updateReadouts() {
  stepsReadout.textContent = String(steps);
  rotationReadout.textContent = `${tunnel.rotation.y.toFixed(6)} rad`;
  selectedReadout.textContent = selected ? selected.name : 'None';
}

function step(count) {
  if (!Number.isInteger(count) || count < 0 || count > 10000) {
    throw new RangeError('step(n) requires an integer from 0 to 10000');
  }

  for (let i = 0; i < count; i += 1) {
    for (const coin of coins) {
      coin.userData.p += STEPS_PER_FRAME;
      coin.rotation.x += 0.06;
      coin.rotation.z += 0.03;
      if (coin.userData.p > 1) {
        coin.userData.p -= 1;
        coin.rotation.x = 0;
        coin.rotation.z = 0;
      }
    }
    tunnel.rotation.y += TUNNEL_STEP;
  }

  steps += count;
  refreshCoins();
  updateReadouts();
}

function setProgress(index, p) {
  if (!Number.isInteger(index) || index < 0 || index >= coins.length) {
    throw new RangeError('setProgress(i, p) requires a coin index from 0 to 7');
  }
  if (typeof p !== 'number' || !Number.isFinite(p) || p < 0 || p > 1) {
    throw new RangeError('setProgress(i, p) requires a finite p from 0 to 1');
  }

  coins[index].userData.p = p;
  updateCoinTransform(coins[index]);
  updateReadouts();
}

function setView(name) {
  if (name === 'inside') {
    camera.up.set(0, 0, -1);
    camera.position.set(0, -200, 0);
  } else if (name === 'overview') {
    camera.up.set(0, 1, 0);
    camera.position.set(0, 0, 650);
  } else {
    throw new RangeError('setView(name) requires "inside" or "overview"');
  }
  camera.lookAt(0, 0, 0);
  camera.updateMatrixWorld();
}

function projectCoin(index) {
  if (!Number.isInteger(index) || index < 0 || index >= coins.length) {
    throw new RangeError('projectCoin(i) requires a coin index from 0 to 7');
  }
  camera.updateMatrixWorld();
  const point = coins[index].getWorldPosition(new THREE.Vector3()).project(camera);
  return { x: point.x, y: point.y, z: point.z };
}

const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();

function selectCoin(coin) {
  selected = coin;
  for (const candidate of coins) {
    setCoinMaterials(candidate, candidate === coin ? SELECTED_EMISSIVE : OFF_EMISSIVE);
  }
  updateReadouts();
}

function pick(ndcX, ndcY) {
  if (typeof ndcX !== 'number' || typeof ndcY !== 'number' ||
      !Number.isFinite(ndcX) || !Number.isFinite(ndcY)) {
    throw new RangeError('pick(ndcX, ndcY) requires finite coordinates');
  }

  scene.updateMatrixWorld(true);
  camera.updateMatrixWorld();
  pointer.set(ndcX, ndcY);
  raycaster.setFromCamera(pointer, camera);
  const hit = raycaster.intersectObjects(pickMeshes, false)[0];
  if (!hit) {
    clearSelection();
    updateReadouts();
    return null;
  }

  selectCoin(hit.object.userData.coin);
  return selected.name;
}

function reset() {
  steps = 0;
  tunnel.rotation.y = 0;
  for (const coin of coins) {
    coin.userData.p = coin.userData.initialProgress;
    coin.rotation.set(0, 0, 0);
    updateCoinTransform(coin);
  }
  clearSelection();
  setView('inside');
  updateReadouts();
}

function state() {
  return {
    steps,
    tunnelRotation: tunnel.rotation.y,
    selected: selected ? selected.name : null,
    coins: coins.map((coin) => ({
      name: coin.name,
      p: coin.userData.p,
      position: coin.position.toArray(),
      scale: coin.scale.toArray(),
      rotation: [coin.rotation.x, coin.rotation.y, coin.rotation.z],
    })),
  };
}

window.coinLab = {
  scene,
  camera,
  renderer,
  tunnel,
  coins,
  reset,
  step,
  setProgress,
  setView,
  projectCoin,
  pick,
  state,
};

document.querySelector('#step-button').addEventListener('click', () => step(1));
document.querySelector('#reset-button').addEventListener('click', reset);
canvas.addEventListener('click', (event) => {
  const rect = canvas.getBoundingClientRect();
  const ndcX = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  const ndcY = -((event.clientY - rect.top) / rect.height) * 2 + 1;
  pick(ndcX, ndcY);
});

window.addEventListener('resize', () => {
  const width = window.innerWidth;
  const height = window.innerHeight;
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(width, height);
});

reset();
renderer.setAnimationLoop(() => {
  renderer.render(scene, camera);
});
