import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';

const STORAGE_KEY = 'plaqueStudio.v1';
const VERSION = 1;
const EPSILON = 1e-5;
const SIDES = ['front', 'back'];
const SIDE_KEYS = ['text', 'color', 'x', 'y', 'rotation', 'scale', 'visible'];
const COLOR_PATTERN = /^#[0-9a-fA-F]{6}$/;
const INITIAL_CAMERA_POSITION = Object.freeze({ x: 6, y: 4, z: 8 });
const INITIAL_TARGET = Object.freeze({ x: 0, y: 1.2, z: 0 });

const COLOR_NAMES = {
  '#4477aa': 'Steel blue',
  '#ffffff': 'White',
  '#ffcc00': 'Signal yellow',
  '#ff9b80': 'Coral',
  '#d8ff6e': 'Chartreuse',
  '#1f2933': 'Charcoal',
  '#111827': 'Midnight',
  '#e5e7eb': 'Mist',
  '#ef4444': 'Red',
  '#22c55e': 'Green',
};

function createDefaultState() {
  return {
    version: VERSION,
    baseColor: '#4477aa',
    selected: 'front',
    front: {
      text: 'HELLO',
      color: '#ffffff',
      x: 0,
      y: 0,
      rotation: 0,
      scale: 1,
      visible: true,
    },
    back: {
      text: 'BACK',
      color: '#ffcc00',
      x: 0,
      y: 0,
      rotation: 0,
      scale: 1,
      visible: false,
    },
  };
}

function cloneState(source) {
  return {
    version: source.version,
    baseColor: source.baseColor,
    selected: source.selected,
    front: { ...source.front },
    back: { ...source.back },
  };
}

function isPlainObject(value) {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}

function isWithin(value, min, max) {
  return typeof value === 'number'
    && Number.isFinite(value)
    && value >= min - EPSILON
    && value <= max + EPSILON;
}

function isValidColor(value) {
  return typeof value === 'string' && COLOR_PATTERN.test(value);
}

function isValidText(value) {
  return typeof value === 'string' && Array.from(value).length <= 24;
}

function validateSideConfig(config, { requireAll = true } = {}) {
  if (!isPlainObject(config)) {
    return false;
  }

  const keys = Object.keys(config);
  if (keys.some((key) => !SIDE_KEYS.includes(key))) {
    return false;
  }
  if (requireAll && keys.length !== SIDE_KEYS.length) {
    return false;
  }

  for (const key of keys) {
    const value = config[key];
    switch (key) {
      case 'text':
        if (!isValidText(value)) return false;
        break;
      case 'color':
        if (!isValidColor(value)) return false;
        break;
      case 'x':
        if (!isWithin(value, -1, 1)) return false;
        break;
      case 'y':
        if (!isWithin(value, -0.7, 0.7)) return false;
        break;
      case 'rotation':
        if (!isWithin(value, -180, 180)) return false;
        break;
      case 'scale':
        if (!isWithin(value, 0.5, 2)) return false;
        break;
      case 'visible':
        if (typeof value !== 'boolean') return false;
        break;
      default:
        return false;
    }
  }

  if (requireAll) {
    for (const key of SIDE_KEYS) {
      if (!Object.prototype.hasOwnProperty.call(config, key)) return false;
    }
  }

  return true;
}

function validateState(candidate) {
  if (!isPlainObject(candidate)) {
    return false;
  }

  const topLevelKeys = Object.keys(candidate);
  const requiredTopLevel = ['version', 'baseColor', 'selected', 'front', 'back'];
  if (topLevelKeys.length !== requiredTopLevel.length) {
    return false;
  }
  if (requiredTopLevel.some((key) => !Object.prototype.hasOwnProperty.call(candidate, key))) {
    return false;
  }
  if (topLevelKeys.some((key) => !requiredTopLevel.includes(key))) {
    return false;
  }
  if (candidate.version !== VERSION) {
    return false;
  }
  if (!isValidColor(candidate.baseColor)) {
    return false;
  }
  if (!SIDES.includes(candidate.selected)) {
    return false;
  }
  if (!validateSideConfig(candidate.front) || !validateSideConfig(candidate.back)) {
    return false;
  }

  return true;
}

function validatePatch(patch) {
  if (!isPlainObject(patch)) {
    return null;
  }
  if (!validateSideConfig(patch, { requireAll: false })) {
    return null;
  }
  return { ...patch };
}

const viewport = document.querySelector('#viewport');
const panelElement = document.querySelector('#controlPanel');
const textInput = document.querySelector('#textInput');
const textCount = document.querySelector('#textCount');
const labelColor = document.querySelector('#labelColor');
const labelColorHex = document.querySelector('#labelColorHex');
const labelColorChip = document.querySelector('#labelColorChip');
const labelColorName = document.querySelector('#labelColorName');
const baseColor = document.querySelector('#baseColor');
const baseColorHex = document.querySelector('#baseColorHex');
const baseColorChip = document.querySelector('#baseColorChip');
const baseColorName = document.querySelector('#baseColorName');
const xInput = document.querySelector('#xInput');
const yInput = document.querySelector('#yInput');
const rotationInput = document.querySelector('#rotationInput');
const scaleInput = document.querySelector('#scaleInput');
const xOutput = document.querySelector('#xOutput');
const yOutput = document.querySelector('#yOutput');
const rotationOutput = document.querySelector('#rotationOutput');
const scaleOutput = document.querySelector('#scaleOutput');
const visibleInput = document.querySelector('#visibleInput');
const selectionPill = document.querySelector('#selectionPill');
const faceTabs = [...document.querySelectorAll('.face-tab')];
const centerButton = document.querySelector('#centerButton');
const saveButton = document.querySelector('#saveButton');
const loadButton = document.querySelector('#loadButton');
const resetButton = document.querySelector('#resetButton');
const toast = document.querySelector('#toast');

let state = createDefaultState();
let toastTimer = 0;

const scene = new THREE.Scene();
scene.background = new THREE.Color('#090d12');
scene.fog = new THREE.Fog('#090d12', 13, 28);

const camera = new THREE.PerspectiveCamera(
  45,
  window.innerWidth / window.innerHeight,
  0.1,
  100,
);
camera.position.set(
  INITIAL_CAMERA_POSITION.x,
  INITIAL_CAMERA_POSITION.y,
  INITIAL_CAMERA_POSITION.z,
);
camera.lookAt(INITIAL_TARGET.x, INITIAL_TARGET.y, INITIAL_TARGET.z);

const renderer = new THREE.WebGLRenderer({
  antialias: true,
  alpha: false,
  powerPreference: 'high-performance',
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.NoToneMapping;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.domElement.setAttribute('aria-label', 'Orbitable 3D plaque with editable front and back labels');
viewport.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(INITIAL_TARGET.x, INITIAL_TARGET.y, INITIAL_TARGET.z);
controls.enableDamping = true;
controls.dampingFactor = 0.075;
controls.rotateSpeed = 0.62;
controls.zoomSpeed = 0.85;
controls.panSpeed = 0.65;
controls.minDistance = 3.1;
controls.maxDistance = 18;
controls.maxPolarAngle = Math.PI * 0.495;
controls.update();
controls.saveState();

const ambientLight = new THREE.AmbientLight(0xffffff, 1.12);
scene.add(ambientLight);

const directionalLight = new THREE.DirectionalLight(0xfff6e6, 2.35);
directionalLight.position.set(5.5, 8, 6.5);
directionalLight.castShadow = true;
directionalLight.shadow.mapSize.set(2048, 2048);
directionalLight.shadow.camera.left = -7;
directionalLight.shadow.camera.right = 7;
directionalLight.shadow.camera.top = 7;
directionalLight.shadow.camera.bottom = -7;
directionalLight.shadow.camera.near = 0.5;
directionalLight.shadow.camera.far = 24;
directionalLight.shadow.bias = -0.00015;
directionalLight.shadow.normalBias = 0.025;
directionalLight.target.position.set(0, 1.2, 0);
scene.add(directionalLight);
scene.add(directionalLight.target);

const floorMaterial = new THREE.MeshStandardMaterial({
  color: '#111920',
  roughness: 0.92,
  metalness: 0.04,
});
const floor = new THREE.Mesh(new THREE.PlaneGeometry(12, 12), floorMaterial);
floor.name = 'floor';
floor.rotation.x = -Math.PI / 2;
floor.position.y = 0;
floor.receiveShadow = true;
scene.add(floor);

const grid = new THREE.GridHelper(12, 24, '#31414a', '#1d2a32');
grid.position.y = 0.002;
grid.material.transparent = true;
grid.material.opacity = 0.32;
grid.material.depthWrite = false;
scene.add(grid);

const panelMaterial = new THREE.MeshStandardMaterial({
  color: state.baseColor,
  roughness: 0.48,
  metalness: 0.14,
});
const panel = new THREE.Mesh(new THREE.BoxGeometry(4, 2.4, 0.3), panelMaterial);
panel.name = 'panel';
panel.position.set(0, 1.4, 0);
panel.castShadow = true;
panel.receiveShadow = true;
scene.add(panel);

const panelEdges = new THREE.LineSegments(
  new THREE.EdgesGeometry(panel.geometry),
  new THREE.LineBasicMaterial({
    color: '#ffffff',
    transparent: true,
    opacity: 0.09,
    depthWrite: false,
  }),
);
panelEdges.renderOrder = 3;
panel.add(panelEdges);

function getColorName(hex) {
  return COLOR_NAMES[hex.toLowerCase()] || 'Custom color';
}

function createLabelTexture(text, color) {
  const canvas = document.createElement('canvas');
  canvas.width = 1024;
  canvas.height = 342;
  const context = canvas.getContext('2d');
  context.clearRect(0, 0, canvas.width, canvas.height);

  if (text.length > 0) {
    const fontFamily = '"Arial Black", "Helvetica Neue", Arial, sans-serif';
    let fontSize = 220;
    const maxTextWidth = canvas.width * 0.87;

    do {
      context.font = `900 ${fontSize}px ${fontFamily}`;
      if (context.measureText(text).width <= maxTextWidth) break;
      fontSize -= 3;
    } while (fontSize > 72);

    context.textAlign = 'center';
    context.textBaseline = 'middle';
    context.fillStyle = color;
    context.font = `900 ${fontSize}px ${fontFamily}`;
    context.shadowColor = 'rgba(0, 0, 0, 0.34)';
    context.shadowBlur = 13;
    context.shadowOffsetY = 5;
    context.fillText(text, canvas.width / 2, canvas.height / 2 + fontSize * 0.035, maxTextWidth);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
  texture.needsUpdate = true;
  return texture;
}

function createLabel(side) {
  const group = new THREE.Group();
  group.name = side === 'front' ? 'frontLabel' : 'backLabel';
  group.position.set(
    0,
    0,
    side === 'front' ? 0.151 : -0.151,
  );
  group.rotation.set(0, side === 'back' ? Math.PI : 0, 0, 'YXZ');

  const material = new THREE.MeshBasicMaterial({
    transparent: true,
    depthWrite: false,
    toneMapped: false,
    side: THREE.FrontSide,
  });
  const mesh = new THREE.Mesh(new THREE.PlaneGeometry(1.8, 0.6), material);
  mesh.name = `${group.name}Plane`;
  mesh.renderOrder = 2;
  mesh.userData.side = side;
  group.add(mesh);
  panel.add(group);

  return { group, mesh, material, texture: null };
}

const labelParts = {
  front: createLabel('front'),
  back: createLabel('back'),
};

const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();

function rebuildLabelTexture(side) {
  const parts = labelParts[side];
  const config = state[side];
  if (parts.texture) {
    parts.texture.dispose();
  }
  const texture = createLabelTexture(config.text, config.color);
  parts.texture = texture;
  parts.material.map = texture;
  parts.material.needsUpdate = true;
}

function applyLabel(side, { rebuildTexture = false } = {}) {
  const parts = labelParts[side];
  const config = state[side];
  parts.group.position.set(
    config.x,
    config.y,
    side === 'front' ? 0.151 : -0.151,
  );
  parts.group.rotation.set(
    0,
    side === 'back' ? Math.PI : 0,
    THREE.MathUtils.degToRad(config.rotation),
    'YXZ',
  );
  parts.group.scale.setScalar(config.scale);
  parts.group.visible = config.visible;
  if (rebuildTexture || !parts.material.map) {
    rebuildLabelTexture(side);
  }
}

function applyPanelColor() {
  panelMaterial.color.set(state.baseColor);
}

function applyAllState({ rebuildTextures = true } = {}) {
  applyPanelColor();
  applyLabel('front', { rebuildTexture: rebuildTextures });
  applyLabel('back', { rebuildTexture: rebuildTextures });
}

function setLabelColorUI(side) {
  const color = state[side].color;
  labelColor.value = color.toLowerCase();
  labelColorHex.value = color.toUpperCase();
  labelColorHex.textContent = color.toUpperCase();
  labelColorChip.style.background = color;
  labelColorName.textContent = getColorName(color);
}

function setBaseColorUI() {
  const color = state.baseColor;
  baseColor.value = color.toLowerCase();
  baseColorHex.value = color.toUpperCase();
  baseColorHex.textContent = color.toUpperCase();
  baseColorChip.style.background = color;
  baseColorName.textContent = getColorName(color);
}

function setOutputValues() {
  const config = state[state.selected];
  xOutput.value = config.x.toFixed(2);
  xOutput.textContent = config.x.toFixed(2);
  yOutput.value = config.y.toFixed(2);
  yOutput.textContent = config.y.toFixed(2);
  rotationOutput.value = `${Math.round(config.rotation)}°`;
  rotationOutput.textContent = `${Math.round(config.rotation)}°`;
  scaleOutput.value = `${config.scale.toFixed(2)}×`;
  scaleOutput.textContent = `${config.scale.toFixed(2)}×`;
}

function syncControls() {
  const side = state.selected;
  const config = state[side];

  for (const tab of faceTabs) {
    const active = tab.dataset.side === side;
    tab.classList.toggle('is-active', active);
    tab.setAttribute('aria-pressed', String(active));
  }
  selectionPill.textContent = side === 'front' ? 'Front' : 'Back';

  if (textInput.value !== config.text) textInput.value = config.text;
  textCount.textContent = `${Array.from(config.text).length} / 24`;

  setLabelColorUI(side);
  setBaseColorUI();

  if (Number(xInput.value) !== config.x) xInput.value = String(config.x);
  if (Number(yInput.value) !== config.y) yInput.value = String(config.y);
  if (Number(rotationInput.value) !== config.rotation) rotationInput.value = String(config.rotation);
  if (Number(scaleInput.value) !== config.scale) scaleInput.value = String(config.scale);
  visibleInput.checked = config.visible;
  setOutputValues();
}

function syncSelectedSideOnly() {
  const side = state.selected;
  const config = state[side];

  for (const tab of faceTabs) {
    const active = tab.dataset.side === side;
    tab.classList.toggle('is-active', active);
    tab.setAttribute('aria-pressed', String(active));
  }
  selectionPill.textContent = side === 'front' ? 'Front' : 'Back';

  if (textInput.value !== config.text) textInput.value = config.text;
  textCount.textContent = `${Array.from(config.text).length} / 24`;
  setLabelColorUI(side);
  if (Number(xInput.value) !== config.x) xInput.value = String(config.x);
  if (Number(yInput.value) !== config.y) yInput.value = String(config.y);
  if (Number(rotationInput.value) !== config.rotation) rotationInput.value = String(config.rotation);
  if (Number(scaleInput.value) !== config.scale) scaleInput.value = String(config.scale);
  visibleInput.checked = config.visible;
  setOutputValues();
}

function getState() {
  return cloneState(state);
}

function setSide(side, patch) {
  if (!SIDES.includes(side)) {
    return false;
  }
  const validPatch = validatePatch(patch);
  if (!validPatch) {
    return false;
  }

  Object.assign(state[side], validPatch);
  const rebuildTexture = Object.prototype.hasOwnProperty.call(validPatch, 'text')
    || Object.prototype.hasOwnProperty.call(validPatch, 'color');
  applyLabel(side, { rebuildTexture });

  if (side === state.selected) {
    syncSelectedSideOnly();
  }
  return true;
}

function setBaseColor(hex) {
  if (!isValidColor(hex)) {
    return false;
  }
  state.baseColor = hex;
  applyPanelColor();
  setBaseColorUI();
  return true;
}

function selectSide(side) {
  if (!SIDES.includes(side)) {
    return false;
  }
  state.selected = side;
  syncSelectedSideOnly();
  return true;
}

function pickAt(clientX, clientY) {
  const rect = renderer.domElement.getBoundingClientRect();
  if (rect.width === 0 || rect.height === 0) {
    return null;
  }

  pointer.x = ((clientX - rect.left) / rect.width) * 2 - 1;
  pointer.y = -((clientY - rect.top) / rect.height) * 2 + 1;

  camera.updateMatrixWorld();
  scene.updateMatrixWorld(true);
  raycaster.setFromCamera(pointer, camera);

  const candidates = [];
  for (const side of SIDES) {
    const parts = labelParts[side];
    if (state[side].visible && parts.group.visible && parts.mesh.visible) {
      candidates.push(parts.mesh);
    }
  }

  const hits = raycaster.intersectObjects(candidates, false);
  if (hits.length === 0) {
    return null;
  }

  const side = hits[0].object.userData.side;
  if (!SIDES.includes(side)) {
    return null;
  }
  selectSide(side);
  return side;
}

function save() {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    return true;
  } catch {
    return false;
  }
}

function load() {
  let raw;
  try {
    raw = window.localStorage.getItem(STORAGE_KEY);
  } catch {
    return false;
  }
  if (raw === null) {
    return false;
  }

  let candidate;
  try {
    candidate = JSON.parse(raw);
  } catch {
    return false;
  }

  if (!validateState(candidate)) {
    return false;
  }

  state = cloneState(candidate);
  applyAllState({ rebuildTextures: true });
  syncControls();
  return true;
}

function reset() {
  state = createDefaultState();
  applyAllState({ rebuildTextures: true });
  controls.enableDamping = false;
  controls.update();
  controls.enableDamping = true;
  camera.position.set(
    INITIAL_CAMERA_POSITION.x,
    INITIAL_CAMERA_POSITION.y,
    INITIAL_CAMERA_POSITION.z,
  );
  controls.target.set(INITIAL_TARGET.x, INITIAL_TARGET.y, INITIAL_TARGET.z);
  controls.update();
  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    // Storage can be unavailable in strict privacy contexts; the scene still resets.
  }
  syncControls();
  return getState();
}

function showToast(message, isError = false) {
  window.clearTimeout(toastTimer);
  toast.textContent = message;
  toast.classList.toggle('is-error', isError);
  toast.classList.add('is-visible');
  toastTimer = window.setTimeout(() => {
    toast.classList.remove('is-visible');
  }, 1800);
}

function commitSelected(patch) {
  return setSide(state.selected, patch);
}

textInput.addEventListener('input', () => {
  if (!commitSelected({ text: textInput.value })) {
    syncSelectedSideOnly();
  }
});

labelColor.addEventListener('input', () => {
  if (!commitSelected({ color: labelColor.value })) {
    syncSelectedSideOnly();
  }
});

baseColor.addEventListener('input', () => {
  setBaseColor(baseColor.value);
});

xInput.addEventListener('input', () => {
  commitSelected({ x: Number(xInput.value) });
});

yInput.addEventListener('input', () => {
  commitSelected({ y: Number(yInput.value) });
});

rotationInput.addEventListener('input', () => {
  commitSelected({ rotation: Number(rotationInput.value) });
});

scaleInput.addEventListener('input', () => {
  commitSelected({ scale: Number(scaleInput.value) });
});

visibleInput.addEventListener('change', () => {
  commitSelected({ visible: visibleInput.checked });
});

centerButton.addEventListener('click', () => {
  const ok = commitSelected({ x: 0, y: 0 });
  if (!ok) syncSelectedSideOnly();
});

for (const tab of faceTabs) {
  tab.addEventListener('click', () => {
    selectSide(tab.dataset.side);
  });
}

saveButton.addEventListener('click', () => {
  if (save()) {
    showToast('Design saved locally');
  } else {
    showToast('Could not save design', true);
  }
});

loadButton.addEventListener('click', () => {
  if (load()) {
    showToast('Saved design loaded');
  } else {
    showToast('No valid saved design found', true);
  }
});

resetButton.addEventListener('click', () => {
  reset();
  showToast('Studio reset to defaults');
});

let pointerStart = null;
renderer.domElement.addEventListener('pointerdown', (event) => {
  if (event.button === 0) {
    pointerStart = { x: event.clientX, y: event.clientY };
  }
});

renderer.domElement.addEventListener('pointerup', (event) => {
  if (!pointerStart) return;
  const moved = Math.hypot(event.clientX - pointerStart.x, event.clientY - pointerStart.y);
  pointerStart = null;
  if (moved < 5) {
    const pickedSide = pickAt(event.clientX, event.clientY);
    if (pickedSide) {
      showToast(`${pickedSide === 'front' ? 'Front' : 'Back'} label selected`);
    }
  }
});

function handleResize() {
  const width = window.innerWidth;
  const height = window.innerHeight;
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(width, height);
}
window.addEventListener('resize', handleResize);

applyAllState({ rebuildTextures: true });
syncControls();

const restoredOnStartup = load();
if (!restoredOnStartup) {
  state = createDefaultState();
  applyAllState({ rebuildTextures: true });
  syncControls();
  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    // Ignore storage access failures during startup.
  }
}

window.plaqueStudio = {
  scene,
  camera,
  controls,
  panel,
  frontLabel: labelParts.front.group,
  backLabel: labelParts.back.group,
  getState,
  setSide,
  setBaseColor,
  selectSide,
  pickAt,
  save,
  load,
  reset,
};

renderer.setAnimationLoop(() => {
  controls.update();
  renderer.render(scene, camera);
});

window.addEventListener('beforeunload', () => {
  renderer.setAnimationLoop(null);
});

// Keep this reference live for tooling that inspects the DOM panel.
void panelElement;
