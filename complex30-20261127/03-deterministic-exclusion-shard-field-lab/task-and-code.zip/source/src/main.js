import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const CUBE_COUNT = 125;
const MIN_ORIGIN_DISTANCE = 2;
const MIN_PAIR_DISTANCE = 0.35;
const MAX_ATTEMPTS = 4000;
const MAX_TRANSITION_TIME = 1.2;
const TRANSITION_DURATION = 1;
const DELAY_STEP = 0.05;

const app = document.querySelector('#app');
const seedInput = document.querySelector('#seed');
const scatterButton = document.querySelector('#scatter');
const resetButton = document.querySelector('#reset');
const elapsedLabel = document.querySelector('#elapsed');
const activeSeedLabel = document.querySelector('#active-seed');
const phaseLabel = document.querySelector('#phase');
const errorLabel = document.querySelector('#error');

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x090d16);

const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 100);
camera.position.set(0, 0, 8);
camera.lookAt(0, 0, 0);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
app.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.autoRotate = false;
controls.target.set(0, 0, 0);
controls.update();

scene.add(new THREE.AmbientLight(0xa9c4e4, 0.65));

const directionalLight = new THREE.DirectionalLight(0xffffff, 2.2);
directionalLight.position.set(4, 6, 5);
scene.add(directionalLight);

const coreGeometry = new THREE.IcosahedronGeometry(1, 1);
const coreMaterial = new THREE.MeshStandardMaterial({
  color: 0x3f80c9,
  flatShading: true,
});
const core = new THREE.Mesh(coreGeometry, coreMaterial);
core.name = 'core';
scene.add(core);

const cubeGeometry = new THREE.BoxGeometry(0.1, 0.1, 0.1);
const cubeMaterial = new THREE.MeshStandardMaterial({
  color: 0xdfe9f6,
  roughness: 0.75,
  metalness: 0.05,
});

const group = new THREE.Group();
group.name = 'group';
scene.add(group);

const cubes = [];
for (let x = -2; x <= 2; x += 1) {
  for (let y = -2; y <= 2; y += 1) {
    for (let z = -2; z <= 2; z += 1) {
      const cube = new THREE.Mesh(cubeGeometry, cubeMaterial);
      cube.name = `cube_${x}_${y}_${z}`;
      cube.position.set(x, y, z);
      cube.rotation.order = 'XYZ';
      cube.rotation.set(0.1 * x, 0.1 * y, 0.1 * z);
      cube.userData.scatterStart = null;
      cube.userData.scatterTarget = null;
      group.add(cube);
      cubes.push(cube);
    }
  }
}

if (cubes.length !== CUBE_COUNT) {
  throw new Error(`Expected ${CUBE_COUNT} cubes, created ${cubes.length}.`);
}

let seed = 0;
let elapsed = 0;
let scattering = false;
let transitionStarts = [];
let transitionTargets = [];

function createRandom(initialSeed) {
  let state = initialSeed >>> 0;
  return () => {
    state = (Math.imul(1664525, state) + 1013904223) >>> 0;
    return state / 4294967296;
  };
}

function makeLayout(initialSeed) {
  const random = createRandom(initialSeed);
  const starts = [];
  const targets = [];

  for (let i = 0; i < cubes.length; i += 1) {
    const startX = cubes[i].position.x;
    const startY = cubes[i].position.y;
    const startZ = cubes[i].position.z;
    let accepted = null;

    for (let attempt = 0; attempt < MAX_ATTEMPTS; attempt += 1) {
      const u1 = random();
      const u2 = random();
      const u3 = random();
      const x = 5 * (u1 - 0.5);
      const y = 5 * (u2 - 0.5);
      const z = 5 * (u3 - 0.5);
      const originDistance = Math.hypot(x, y, z);

      if (originDistance < MIN_ORIGIN_DISTANCE) {
        continue;
      }

      let separated = true;
      for (const target of targets) {
        const dx = x - target.x;
        const dy = y - target.y;
        const dz = z - target.z;
        if (Math.hypot(dx, dy, dz) < MIN_PAIR_DISTANCE) {
          separated = false;
          break;
        }
      }

      if (separated) {
        accepted = { x, y, z };
        break;
      }
    }

    if (accepted === null) {
      throw new Error(
        `Could not place cube ${cubes[i].name} after ${MAX_ATTEMPTS} attempts (seed ${initialSeed >>> 0}).`,
      );
    }

    starts.push({ x: startX, y: startY, z: startZ });
    targets.push(accepted);
  }

  return { starts, targets };
}

function scatter(newSeed) {
  const normalizedSeed = newSeed >>> 0;
  const { starts, targets } = makeLayout(normalizedSeed);

  transitionStarts = starts;
  transitionTargets = targets;

  for (let i = 0; i < cubes.length; i += 1) {
    cubes[i].userData.scatterStart = { ...starts[i] };
    cubes[i].userData.scatterTarget = { ...targets[i] };
  }

  seed = normalizedSeed;
  elapsed = 0;
  scattering = true;
}

function smoothstep(t) {
  return t * t * (3 - 2 * t);
}

function updateCubePositions() {
  for (let i = 0; i < cubes.length; i += 1) {
    const cube = cubes[i];
    const start = transitionStarts[i];
    const target = transitionTargets[i];
    const delay = DELAY_STEP * (i % 5);
    const localTime = Math.min(Math.max((elapsed - delay) / TRANSITION_DURATION, 0), 1);

    if (localTime >= 1) {
      cube.position.set(target.x, target.y, target.z);
    } else {
      const q = smoothstep(localTime);
      cube.position.set(
        start.x + (target.x - start.x) * q,
        start.y + (target.y - start.y) * q,
        start.z + (target.z - start.z) * q,
      );
    }
  }
}

function step(dt) {
  if (typeof dt !== 'number' || !Number.isFinite(dt) || dt < 0) {
    return;
  }

  elapsed += dt;
  core.rotation.set(0.2 * elapsed, 0.3 * elapsed, 0, 'XYZ');

  if (!scattering) {
    return;
  }

  updateCubePositions();

  if (elapsed >= MAX_TRANSITION_TIME) {
    scattering = false;
  }
}

function reset() {
  for (let i = 0; i < cubes.length; i += 1) {
    const xIndex = Math.floor(i / 25) - 2;
    const yIndex = Math.floor(i / 5) % 5 - 2;
    const zIndex = (i % 5) - 2;
    const cube = cubes[i];
    cube.position.set(xIndex, yIndex, zIndex);
    cube.rotation.set(0.1 * xIndex, 0.1 * yIndex, 0.1 * zIndex, 'XYZ');
    cube.userData.scatterStart = null;
    cube.userData.scatterTarget = null;
  }

  core.rotation.set(0, 0, 0, 'XYZ');
  seed = 0;
  elapsed = 0;
  scattering = false;
  transitionStarts = [];
  transitionTargets = [];
  errorLabel.textContent = '';
  updateReadout();
}

function vectorSnapshot(vector) {
  return { x: vector.x, y: vector.y, z: vector.z };
}

function getState() {
  return {
    seed,
    elapsed,
    scattering,
    positions: cubes.map((cube) => vectorSnapshot(cube.position)),
    starts: transitionStarts.map((start) => ({ ...start })),
    targets: transitionTargets.map((target) => ({ ...target })),
  };
}

function updateReadout() {
  elapsedLabel.textContent = elapsed.toFixed(2);
  activeSeedLabel.textContent = String(seed);
  phaseLabel.textContent = scattering ? 'scattering' : 'settled';
}

scatterButton.addEventListener('click', () => {
  const rawSeed = Number(seedInput.value);
  if (!Number.isInteger(rawSeed)) {
    errorLabel.textContent = 'Seed must be an integer.';
    return;
  }

  try {
    scatter(rawSeed);
    errorLabel.textContent = '';
  } catch (error) {
    errorLabel.textContent = error instanceof Error ? error.message : String(error);
  }
});

resetButton.addEventListener('click', () => {
  reset();
  seedInput.value = '12345';
});

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

window.shardFieldLab = {
  scene,
  camera,
  renderer,
  controls,
  core,
  group,
  scatter,
  step,
  reset,
  getState,
};

function animate() {
  requestAnimationFrame(animate);
  controls.update();
  updateReadout();
  renderer.render(scene, camera);
}

animate();
