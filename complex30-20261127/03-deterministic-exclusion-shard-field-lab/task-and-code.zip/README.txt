Preserved rollout text source. Large/binary assets and installed dependencies are excluded. This is not a complete runtime environment.
