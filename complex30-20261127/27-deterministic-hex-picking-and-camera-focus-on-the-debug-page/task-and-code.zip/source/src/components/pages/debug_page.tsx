import React from 'react'
import { RouteComponentProps } from 'react-router'
import {
  CylinderBufferGeometry,
  InstancedMesh,
  Matrix4,
  MeshLambertMaterial,
  Quaternion,
  Raycaster,
  TorusBufferGeometry,
  MeshBasicMaterial,
  Mesh,
  Vector2,
  Vector3,
  Color,
  WebGLRenderer
} from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'

import Menu from 'components/canvas_menu'
import BasicCanvas from 'components/canvas/basic_canvas'
import Canvas, { ICanvas } from 'models/canvas'
import styles from 'styles/pages/world_page.module.scss'
import debugStyles from 'styles/pages/debug_page.module.scss'

type DebugTile = {
  id: string
  x: number
  z: number
  height: number
  terrain: 'dirt' | 'stone' | 'sand' | 'forest' | 'water'
  worldX: number
  worldZ: number
  positionY: number
  scaleY: number
  topY: number
}

type PointerStart = {
  x: number
  y: number
  button: number
  pointerId: number
}

type FocusAnimation = {
  selectedId: string
  startTime: number | null
  fromPosition: Vector3
  fromTarget: Vector3
  toPosition: Vector3
  toTarget: Vector3
  frame: number
}

type DebugState = {
  selectedId: string | null
  focusedId: string | null
  cameraPosition: { x: number, y: number, z: number }
  cameraTarget: { x: number, y: number, z: number }
  markerPosition: { x: number, y: number, z: number } | null
  statusText: string
}

const TERRAINS: Record<DebugTile['terrain'], number> = {
  dirt: 0x007b0c,
  stone: 0x666666,
  sand: 0xc2b280,
  water: 0x40a4df,
  forest: 0x004b0c
}

const FIXTURE = ([
  { id: 'A', x: 0, z: 0, height: 1, terrain: 'dirt' },
  { id: 'B', x: 1, z: 0, height: 2, terrain: 'stone' },
  { id: 'C', x: 0, z: 1, height: 3, terrain: 'sand' },
  { id: 'D', x: -1, z: 1, height: 4, terrain: 'forest' },
  { id: 'E', x: 1, z: 1, height: 2, terrain: 'water' }
] as Omit<DebugTile, 'worldX' | 'worldZ' | 'positionY' | 'scaleY' | 'topY'>[]).map((tile): DebugTile => {
  const positionY = Math.max(tile.height / 2, 1)
  const scaleY = Math.max(tile.height, 1)
  return {
    ...tile,
    worldX: ((2 * tile.x + tile.z) * Math.sqrt(3)) / 2,
    worldZ: (3 * tile.z) / 2,
    positionY,
    scaleY,
    topY: positionY + scaleY / 2
  }
})

const TILE_IDS = FIXTURE.map((tile) => tile.id)
const FOCUS_DURATION = 300
const MAX_CLICK_DISTANCE = 5
const DEBUG_GLOBAL = '__hexDebug'

const vectorState = (vector: Vector3 | null) =>
  vector ? { x: vector.x, y: vector.y, z: vector.z } : null

type PathParamsType = {
  id: string | undefined,
}

type PropTypes = RouteComponentProps<PathParamsType>

class DebugPage extends React.Component<PropTypes> {
  canvas: ICanvas | null = null
  controlsRef: React.MutableRefObject<OrbitControls | null> = React.createRef()
  tiles: InstancedMesh | null = null
  marker: Mesh | null = null
  pointerStart: PointerStart | null = null
  focusAnimation: FocusAnimation | null = null
  focusedId: string | null = null
  selectedId: string | null = null
  buttonState = { selected: false }
  statusEl: HTMLElement | null = null

  constructor(props: PropTypes) {
    super(props)
    this.canvas = Canvas.create({}, {
      renderer: new WebGLRenderer({ preserveDrawingBuffer: true })
    })
    this.canvas.camera.position.set(-5, 5, 0)
    this.canvas.camera.lookAt(0, 0, 0)
    this.addFixture(this.canvas)
    const element = this.canvas.renderer.domElement
    element.addEventListener('pointerdown', this.onPointerDown)
    element.addEventListener('pointerup', this.onPointerUp)
    element.addEventListener('pointercancel', this.onPointerCancel)
  }

  componentDidMount() {
    this.attachCanvas()
  }

  componentDidUpdate() {
    this.attachCanvas()
  }

  componentWillUnmount() {
    this.cancelFocus()
    if (window.onresize === this.onResize) window.onresize = null
    if (this.canvas) this.canvas.renderer.dispose()
    if (window[DEBUG_GLOBAL]) window[DEBUG_GLOBAL] = undefined
  }

  attachCanvas() {
    if (!this.canvas || !this.canvas.renderer.domElement) return
    if (window.onresize !== this.onResize) window.onresize = this.onResize
    window[DEBUG_GLOBAL] = {
      getState: this.getState.bind(this),
      projectTile: this.projectTile.bind(this),
      reset: this.reset.bind(this)
    }
    this.renderStatus()
  }

  addFixture(canvas: ICanvas) {
    this.canvas = canvas
    const mesh = new InstancedMesh(
      new CylinderBufferGeometry(1, 1, 1, 6),
      new MeshLambertMaterial({ flatShading: true }),
      FIXTURE.length
    )
    mesh.name = 'debug-tiles'
    mesh.userData.tileIds = [...TILE_IDS]
    const matrix = new Matrix4()
    const quaternion = new Quaternion()
    FIXTURE.forEach((tile, index) => {
      matrix.compose(
        new Vector3(tile.worldX, tile.positionY, tile.worldZ),
        quaternion,
        new Vector3(1, tile.scaleY, 1)
      )
      mesh.setMatrixAt(index, matrix)
      mesh.setColorAt(index, new Color(TERRAINS[tile.terrain]))
    })
    mesh.instanceMatrix.needsUpdate = true
    const instanceColor = (mesh as any).instanceColor
    if (instanceColor) instanceColor.needsUpdate = true
    canvas.scene.add(mesh)
    this.tiles = mesh
    canvas.animate()
  }

  onControlStart = () => {
    this.focusedId = null
    this.cancelFocus()
    this.requestRender()
  }
  onPointerDown = (event: PointerEvent) => {
    this.pointerStart = event.button === 0
      ? { x: event.clientX, y: event.clientY, button: event.button, pointerId: event.pointerId }
      : null
  }

  onPointerUp = (event: PointerEvent) => {
    const start = this.pointerStart
    this.pointerStart = null
    if (!start || start.pointerId !== event.pointerId || event.button !== 0) return
    if (Math.hypot(event.clientX - start.x, event.clientY - start.y) > MAX_CLICK_DISTANCE) return
    this.selectTile(this.pick(event))
  }

  onPointerCancel = () => {
    this.pointerStart = null
  }

  onResize = () => {
    if (!this.canvas) return
    this.canvas.renderer.setSize(window.innerWidth, window.innerHeight)
    this.canvas.camera.aspect = window.innerWidth / window.innerHeight
    this.canvas.camera.updateProjectionMatrix()
    this.requestRender()
  }

  pick(event: PointerEvent): string | null {
    if (!this.canvas || !this.tiles || !this.canvas.renderer.domElement) return null
    const rect = this.canvas.renderer.domElement.getBoundingClientRect()
    if (!rect.width || !rect.height) return null
    const pointer = new Vector2(
      ((event.clientX - rect.left) / rect.width) * 2 - 1,
      -((event.clientY - rect.top) / rect.height) * 2 + 1
    )
    const raycaster = new Raycaster()
    raycaster.setFromCamera(pointer, this.canvas.camera)
    const hit = raycaster.intersectObject(this.tiles, false)[0]
    if (!hit || hit.instanceId === undefined) return null
    return this.tiles.userData.tileIds[hit.instanceId] || null
  }

  selectTile(id: string | null) {
    if (this.selectedId !== id) {
      this.cancelFocus()
      this.focusedId = null
    }
    this.selectedId = id
    this.buttonState.selected = !!id
    this.syncSelection()
    this.renderStatus()
  }

  get selectedTile(): DebugTile | null {
    return FIXTURE.find((tile) => tile.id === this.selectedId) || null
  }

  syncSelection() {
    if (this.marker) {
      if (this.canvas) this.canvas.scene.remove(this.marker)
      this.marker.geometry.dispose()
      ;(this.marker.material as MeshBasicMaterial).dispose()
      this.marker = null
    }
    const tile = this.selectedTile
    if (tile && this.canvas) {
      const marker = new Mesh(
        new TorusBufferGeometry(1.15, 0.05, 8, 32),
        new MeshBasicMaterial({ color: 0xffff00, depthTest: false })
      )
      marker.name = 'selection-marker'
      marker.rotation.x = Math.PI / 2
      marker.position.set(tile.worldX, tile.topY + 0.05, tile.worldZ)
      marker.renderOrder = 10
      this.canvas.scene.add(marker)
      this.marker = marker
    }
    this.requestRender()
  }

  cancelFocus() {
    if (!this.focusAnimation) return
    window.cancelAnimationFrame(this.focusAnimation.frame)
    this.focusAnimation = null
  }

  focusSelected = () => {
    const tile = this.selectedTile
    if (!tile || !this.canvas || !this.controlsRef.current) return
    this.cancelFocus()
    this.focusedId = null
    const toTarget = new Vector3(tile.worldX, tile.topY, tile.worldZ)
    const animation: FocusAnimation = {
      selectedId: tile.id,
      startTime: null,
      fromPosition: this.canvas.camera.position.clone(),
      fromTarget: this.controlsRef.current.target.clone(),
      toPosition: toTarget.clone().add(new Vector3(-5, 5, 0)),
      toTarget,
      frame: 0
    }
    this.focusAnimation = animation
    animation.frame = window.requestAnimationFrame((now) => this.animateFocus(now))
  }

  animateFocus(now: number) {
    const animation = this.focusAnimation
    if (!animation || !this.canvas || !this.controlsRef.current) return
    if (animation.startTime === null) animation.startTime = now
    const progress = Math.min(1, Math.max(0, (now - animation.startTime) / FOCUS_DURATION))
    this.canvas.camera.position.lerpVectors(animation.fromPosition, animation.toPosition, progress)
    this.controlsRef.current.target.lerpVectors(animation.fromTarget, animation.toTarget, progress)
    this.canvas.camera.updateMatrixWorld()
    this.canvas.scheduleRender()
    if (progress < 1) {
      animation.frame = window.requestAnimationFrame((time) => this.animateFocus(time))
    } else {
      this.focusAnimation = null
      this.focusedId = animation.selectedId
    }
  }

  reset = () => {
    this.cancelFocus()
    this.focusedId = null
    this.selectedId = null
    this.buttonState.selected = false
    if (this.controlsRef.current) this.controlsRef.current.target.set(0, 0, 0)
    if (this.canvas) {
      this.canvas.camera.position.set(-5, 5, 0)
      this.canvas.camera.updateMatrixWorld()
      this.syncSelection()
    }
    this.renderStatus()
    this.requestRender()
  }

  projectTile(id: string) {
    const tile = FIXTURE.find((item) => item.id === id)
    console.log('PROJECT ENTER', id, !!tile, !!this.canvas)
    if (!tile || !this.canvas || !this.canvas.renderer.domElement) return null
    const rect = this.canvas.renderer.domElement.getBoundingClientRect()
    console.log('PROJECT TRACE', id, rect.width, rect.height, !!this.canvas, !!this.canvas.renderer.domElement)
    this.canvas.camera.updateMatrixWorld()
    const point = new Vector3(tile.worldX, tile.topY, tile.worldZ).project(this.canvas.camera)
    return {
      x: rect.left + ((point.x + 1) / 2) * rect.width,
      y: rect.top + ((1 - point.y) / 2) * rect.height
    }
  }

  getState = (): DebugState => ({
    selectedId: this.selectedId,
    focusedId: this.focusedId,
    cameraPosition: vectorState(this.canvas ? this.canvas.camera.position : null) as DebugState['cameraPosition'],
    cameraTarget: vectorState(this.controlsRef.current ? this.controlsRef.current.target : null) as DebugState['cameraTarget'],
    markerPosition: vectorState(this.marker ? this.marker.position : null),
    statusText: `Selected: ${this.selectedId || 'none'}`
  })

  renderStatus() {
    if (this.statusEl) this.statusEl.textContent = `Selected: ${this.selectedId || 'none'}`
  }

  requestRender() {
    if (this.canvas) this.canvas.scheduleRender()
  }

  handleStatusRef = (element: HTMLDivElement | null) => {
    this.statusEl = element
    this.renderStatus()
  }

  render() {
    if (!this.canvas) return null
    return (
      <div className={debugStyles.wrapper}>
        <Menu />
        <div className={styles.container}>
          <BasicCanvas
            canvas={this.canvas}
            controlsRef={this.controlsRef}
            onControlsStart={this.onControlStart}
          />
        </div>
        <div className={debugStyles.panel}>
          <div data-testid="selection-status" ref={this.handleStatusRef}>Selected: none</div>
          <button
            type="button"
            data-testid="focus-selected"
            disabled={!this.buttonState.selected}
            onClick={this.focusSelected}
          >
            Focus selected
          </button>
          <button type="button" data-testid="reset-debug" onClick={this.reset}>
            Reset
          </button>
        </div>
      </div>
    )
  }
}

export { DebugPage }
export default DebugPage
