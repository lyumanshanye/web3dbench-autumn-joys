import React, { useEffect, useRef } from 'react'
import { observer } from 'mobx-react'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls'

import { ICanvas } from 'models/canvas'

interface PropTypes {
  canvas: ICanvas
  controlsRef?: React.MutableRefObject<OrbitControls | null>
  onControlsStart?: () => void
}

const BasicCanvas : React.FunctionComponent<PropTypes> = ({ canvas, controlsRef, onControlsStart }) => {
  const root = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (root.current) {
      const controls = new OrbitControls(canvas.camera, root.current)
      controls.maxPolarAngle = (2 * Math.PI) / 5
      controls.minPolarAngle = Math.PI / 8
      controls.target.set(0, 0, 0)
      controls.addEventListener('change', canvas.animate)
      if (onControlsStart) controls.addEventListener('start', onControlsStart)
      if (controlsRef) controlsRef.current = controls

      root.current.appendChild(canvas.renderer.domElement)

      return () => {
        if (onControlsStart) controls.removeEventListener('start', onControlsStart)
        controls.dispose()
        if (controlsRef) controlsRef.current = null
      }
    }
    return undefined
  }, [canvas, controlsRef, onControlsStart])

  return <div ref={root} />
}

export { BasicCanvas }
export default observer(BasicCanvas)
