import { IWorldStore } from 'stores/world_store'

export interface PushEvent {
  receive(message: string, callback: any): void
}

export interface StoreProps {
  store: {
    worldStore: IWorldStore
  }
}

export interface CubeVector {
  x: number
  z: number
}

export interface Vector {
  x: number
  y: number
  z: number
}

export interface HexDebug {
  getState(): {
    selectedId: string | null
    focusedId: string | null
    cameraPosition: { x: number, y: number, z: number }
    cameraTarget: { x: number, y: number, z: number }
    markerPosition: { x: number, y: number, z: number } | null
    statusText: string
  }
  projectTile(id: string): { x: number, y: number } | null
  reset(): void
}

declare global {
  interface Window {
    __hexDebug?: HexDebug
  }
}
