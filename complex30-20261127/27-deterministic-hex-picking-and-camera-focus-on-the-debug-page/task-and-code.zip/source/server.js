const http = require('http')
const fs = require('fs')
const path = require('path')

const root = path.join(__dirname, 'build')
const port = Number(process.env.PORT) || 3000
const types = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.ico': 'image/x-icon',
  '.png': 'image/png',
  '.svg': 'image/svg+xml'
}

http.createServer((request, response) => {
  const pathname = decodeURIComponent((request.url || '/').split('?')[0])
  let file = path.join(root, pathname)
  if (!file.startsWith(root)) {
    response.writeHead(403)
    response.end()
    return
  }
  try {
    if (fs.statSync(file).isDirectory()) file = path.join(file, 'index.html')
  } catch (error) {
    file = path.join(root, 'index.html')
  }
  fs.readFile(file, (error, content) => {
    if (error) {
      response.writeHead(404)
      response.end('Not found')
      return
    }
    response.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream' })
    response.end(content)
  })
}).listen(port, () => console.log(`Hex debug app listening on http://localhost:${port}/debug`))
