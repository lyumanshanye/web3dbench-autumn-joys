# Flipbook Lab

A standalone Three.js flipbook built with procedural geometry and materials. All
assets are generated at runtime; the app loads no external textures, models,
fonts, or animation libraries.

## Run

```bash
npm install
npm run build
npm run preview -- --host 127.0.0.1 --port 4173
```

Open `http://127.0.0.1:4173/`.

## Controls

- Drag the timeline slider to set progress directly.
- Use **Next**, **Previous**, and **Reset** for goal-based movement.
- Click a page in the 3D scene to flip from that page.

The page exposes its scene and controls through `window.flipbookLab`, including
`setProgress`, `flipTo`, `advance`, `reset`, `flipSheet`, and `pick`.
