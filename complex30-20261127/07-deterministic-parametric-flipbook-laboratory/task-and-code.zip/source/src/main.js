import * as THREE from "three";
import "./style.css";

const N = 4;
const SPACING = 0.01;
const SHEET_WIDTH = 1.2;
const SHEET_HEIGHT = 0.8;
const WIDTH_SEGMENTS = 24;
const HEIGHT_SEGMENTS = 16;
const FLIP_SPEED = 2;
const MAX_PROGRESS = N;
const SHEET_COLORS = [0xe96b51, 0xf0b13e, 0x58b9a7, 0x6f89df];

const app = document.querySelector("#app");
const progressSlider = document.querySelector("#progressSlider");
const progressValue = document.querySelector("#progressValue");
const goalValue = document.querySelector("#goalValue");
const nextButton = document.querySelector("#nextButton");
const previousButton = document.querySelector("#previousButton");
const resetButton = document.querySelector("#resetButton");

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0d141a);
scene.fog = new THREE.Fog(0x0d141a, 6.4, 14.5);

const camera = new THREE.PerspectiveCamera(
  45,
  window.innerWidth / window.innerHeight,
  0.1,
  100,
);
camera.position.set(0, 2.6, 2.8);
camera.lookAt(0, 0, 0);

const renderer = new THREE.WebGLRenderer({
  antialias: true,
  alpha: false,
  powerPreference: "high-performance",
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.domElement.className = "webgl-canvas";
renderer.domElement.setAttribute("aria-label", "Interactive 3D flipbook");
app.prepend(renderer.domElement);

const ambientLight = new THREE.AmbientLight(0xcbd8d7, 1.65);
scene.add(ambientLight);

const keyLight = new THREE.DirectionalLight(0xffdfb9, 3.8);
keyLight.position.set(2.2, 9.5, 4.4);
keyLight.castShadow = true;
keyLight.shadow.intensity = 0.38;
keyLight.shadow.mapSize.set(2048, 2048);
keyLight.shadow.camera.left = -4;
keyLight.shadow.camera.right = 4;
keyLight.shadow.camera.top = 4;
keyLight.shadow.camera.bottom = -4;
keyLight.shadow.camera.near = 0.1;
keyLight.shadow.camera.far = 18;
keyLight.shadow.bias = -0.00015;
scene.add(keyLight);

const fillLight = new THREE.DirectionalLight(0x76a8bc, 1.15);
fillLight.position.set(-4, 2.5, -3);
scene.add(fillLight);

const floor = new THREE.Mesh(
  new THREE.CircleGeometry(5.5, 96),
  new THREE.MeshStandardMaterial({
    color: 0x172229,
    roughness: 0.88,
    metalness: 0.08,
  }),
);
floor.rotation.x = -Math.PI / 2;
floor.position.y = -0.145;
floor.receiveShadow = true;
scene.add(floor);

const guideGrid = new THREE.GridHelper(9, 18, 0x688087, 0x26383d);
guideGrid.position.y = -0.138;
guideGrid.material.transparent = true;
guideGrid.material.opacity = 0.2;
guideGrid.material.depthWrite = false;
scene.add(guideGrid);

const benchRing = new THREE.Mesh(
  new THREE.RingGeometry(2.18, 2.19, 128),
  new THREE.MeshBasicMaterial({
    color: 0x67858a,
    transparent: true,
    opacity: 0.32,
    side: THREE.DoubleSide,
    depthWrite: false,
  }),
);
benchRing.rotation.x = -Math.PI / 2;
benchRing.position.y = -0.137;
scene.add(benchRing);

const book = new THREE.Group();
book.name = "book";
scene.add(book);

const sheets = [];
const sheetMeshes = [];
const originalPositions = [];
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();

for (let index = 0; index < N; index += 1) {
  const sheet = new THREE.Group();
  sheet.name = `sheet-${index}`;
  sheet.userData.sheetIndex = index;

  const geometry = new THREE.PlaneGeometry(
    SHEET_WIDTH,
    SHEET_HEIGHT,
    WIDTH_SEGMENTS,
    HEIGHT_SEGMENTS,
  );
  geometry.rotateX(-Math.PI / 2);
  geometry.translate(SHEET_WIDTH / 2, 0, 0);

  const material = new THREE.MeshStandardMaterial({
    color: SHEET_COLORS[index],
    side: THREE.DoubleSide,
    roughness: 0.54,
    metalness: 0.025,
  });

  const mesh = new THREE.Mesh(geometry, material);
  mesh.name = `sheet-${index}-mesh`;
  mesh.castShadow = true;
  mesh.receiveShadow = false;
  sheet.add(mesh);
  book.add(sheet);

  sheets.push(sheet);
  sheetMeshes.push(mesh);
  originalPositions.push(
    new Float32Array(geometry.attributes.position.array),
  );
}

let progress = 0;
let goal = 0;

function clampProgress(value) {
  return Math.min(MAX_PROGRESS, Math.max(0, value));
}

function deformSheet(index, q) {
  const geometry = sheetMeshes[index].geometry;
  const positions = geometry.attributes.position;
  const destination = positions.array;
  const original = originalPositions[index];
  const wave = 0.08 * Math.sin(Math.PI * q);

  for (let offset = 0; offset < original.length; offset += 3) {
    const x = original[offset];
    const z = original[offset + 2];
    destination[offset] = x;
    destination[offset + 1] =
      wave * Math.sin((Math.PI * x) / SHEET_WIDTH);
    destination[offset + 2] = z;
  }

  positions.needsUpdate = true;
  geometry.computeVertexNormals();
  geometry.computeBoundingBox();
  geometry.computeBoundingSphere();
}

function syncControls() {
  const progressText = progress.toFixed(3);
  progressValue.textContent = progressText;
  progressValue.value = progressText;

  const goalText = goal === null ? "—" : goal.toFixed(3);
  goalValue.textContent = goalText;
  goalValue.value = goalText;
  goalValue.dataset.value = goal === null ? "" : String(goal);

  progressSlider.value = String(progress);
  progressSlider.style.setProperty(
    "--fill",
    `${(progress / MAX_PROGRESS) * 100}%`,
  );
  progressSlider.setAttribute("aria-valuetext", progressText);
}

function rebuild() {
  const page = Math.floor(progress);
  const fraction = progress - page;

  for (let index = 0; index < N; index += 1) {
    let q;

    if (index > page) {
      q = 0;
    } else if (index < page) {
      q = 1;
    } else {
      q = fraction;
    }

    const rightY = -SPACING * index;
    const leftY = -SPACING * (N - index);
    const blend = Math.max(0, 2 * q - 1);
    const sheet = sheets[index];

    sheet.rotation.z = Math.PI * q;
    sheet.position.y = rightY + blend * (leftY - rightY);
    deformSheet(index, q);
  }

  if (progress >= MAX_PROGRESS) {
    book.position.x = 0.3;
  } else if (page === 0) {
    book.position.x = -0.3 + 0.3 * fraction;
  } else if (page === N - 1) {
    book.position.x = 0.3 * fraction;
  } else {
    book.position.x = 0;
  }

  syncControls();
}

function setProgress(value) {
  if (!Number.isFinite(value)) {
    return progress;
  }

  progress = clampProgress(value);
  goal = null;
  rebuild();
  return progress;
}

function getProgress() {
  return progress;
}

function getGoal() {
  return goal;
}

function flipTo(target) {
  if (!Number.isFinite(target)) {
    return goal;
  }

  goal = clampProgress(target);
  syncControls();
  return goal;
}

function advance(dt) {
  if (!Number.isFinite(dt) || dt < 0 || goal === null) {
    return progress;
  }

  const previousProgress = progress;
  const distance = goal - progress;

  if (distance > 0) {
    progress = Math.min(goal, progress + FLIP_SPEED * dt);
  } else if (distance < 0) {
    progress = Math.max(goal, progress - FLIP_SPEED * dt);
  }

  if (progress !== previousProgress) {
    rebuild();
  }

  return progress;
}

function nextSheet() {
  return flipTo(Math.min(MAX_PROGRESS, Math.floor(progress + 1e-9) + 1));
}

function previousSheet() {
  return flipTo(Math.max(0, Math.ceil(progress - 1e-9) - 1));
}

function reset() {
  progress = 0;
  goal = 0;
  rebuild();
  return progress;
}

function flipSheet(index) {
  if (!Number.isInteger(index) || index < 0 || index >= N) {
    return null;
  }

  if (progress > index) {
    return flipTo(index);
  }

  return flipTo(index + 1);
}

function pick(ndcX, ndcY) {
  if (!Number.isFinite(ndcX) || !Number.isFinite(ndcY)) {
    return null;
  }

  camera.updateMatrixWorld(true);
  book.updateMatrixWorld(true);
  pointer.set(ndcX, ndcY);
  raycaster.setFromCamera(pointer, camera);

  const hits = raycaster.intersectObjects(book.children, true);
  if (hits.length === 0) {
    return null;
  }

  let ancestor = hits[0].object;
  while (ancestor && ancestor !== book) {
    const index = ancestor.userData.sheetIndex;
    if (Number.isInteger(index) && sheets[index] === ancestor) {
      flipSheet(index);
      return index;
    }
    ancestor = ancestor.parent;
  }

  return null;
}

progressSlider.addEventListener("input", (event) => {
  setProgress(Number(event.currentTarget.value));
});

nextButton.addEventListener("click", () => {
  nextSheet();
});

previousButton.addEventListener("click", () => {
  previousSheet();
});

resetButton.addEventListener("click", () => {
  reset();
});

renderer.domElement.addEventListener("click", (event) => {
  const bounds = renderer.domElement.getBoundingClientRect();
  if (bounds.width === 0 || bounds.height === 0) {
    return;
  }

  const ndcX = ((event.clientX - bounds.left) / bounds.width) * 2 - 1;
  const ndcY = -((event.clientY - bounds.top) / bounds.height) * 2 + 1;
  pick(ndcX, ndcY);
});

function updateCameraProjection() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.zoom = Math.min(1, camera.aspect / 0.9);
  camera.updateProjectionMatrix();
}

window.addEventListener("resize", () => {
  updateCameraProjection();
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
});

window.flipbookLab = {
  scene,
  camera,
  renderer,
  book,
  sheets,
  setProgress,
  getProgress,
  getGoal,
  flipTo,
  nextSheet,
  previousSheet,
  advance,
  reset,
  flipSheet,
  pick,
};

updateCameraProjection();
rebuild();

let previousTime = performance.now();
renderer.setAnimationLoop(() => {
  const now = performance.now();
  const dt = (now - previousTime) / 1000;
  previousTime = now;
  advance(dt);
  renderer.render(scene, camera);
});
