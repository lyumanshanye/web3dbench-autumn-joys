import type { Intersection, Object3D } from 'three';
import {
  BoxGeometry,
  Group,
  Mesh,
  MeshStandardMaterial,
  Raycaster,
  Vector2,
  Vector3,
} from 'three';
import type { SceneManager } from '../scene/sceneManager';

export interface PickingProbeState {
  selectedId: string | null;
  lastError: 'invalid-ndc' | null;
  pickCount: number;
}

export interface PickingProbeHit {
  id: string;
  point: [number, number, number];
  distance: number;
  objectName: string;
}

export interface PickingProbe {
  pick(ndcX: number, ndcY: number): PickingProbeHit | null;
  project(id: string): { x: number; y: number; z: number } | null;
  state(): PickingProbeState;
  reset(): void;
}

interface FixturePickGroup {
  id: string;
  size: number;
  position: [number, number, number];
  childName: string;
}

const fixturePickGroups: FixturePickGroup[] = [
  { id: 'rear', size: 2, position: [0, 0, -2], childName: 'rear-surface' },
  { id: 'front', size: 1, position: [0, 0, 1], childName: 'front-surface' },
  { id: 'offset', size: 1, position: [3, 0, 0], childName: 'offset-surface' },
];

const createPickGroup = (pickGroup: FixturePickGroup): Group => {
  const group = new Group();
  group.name = pickGroup.id;
  group.userData.pickId = pickGroup.id;
  group.position.set(...pickGroup.position);
  const mesh = new Mesh(
    new BoxGeometry(pickGroup.size, pickGroup.size, pickGroup.size),
    new MeshStandardMaterial()
  );
  mesh.name = pickGroup.childName;
  group.add(mesh);
  return group;
};

export const createPickingFixture = (): Group => {
  const fixture = new Group();
  fixture.name = 'picking-fixture';
  fixturePickGroups.forEach((pickGroup) =>
    fixture.add(createPickGroup(pickGroup))
  );
  return fixture;
};

const getPickId = (object: Object3D): string | null => {
  let current: Object3D | null = object;
  while (current) {
    if (typeof current.userData.pickId === 'string') {
      return current.userData.pickId;
    }
    current = current.parent;
  }
  return null;
};

export const installPickingProbe = (
  sceneManager: SceneManager,
  fixture: Group
): PickingProbe => {
  const camera = sceneManager.getCamera();
  const sceneRenderer = sceneManager.sceneRenderer;
  const rayCaster = new Raycaster();
  const setCameraPose = () => {
    camera.fov = 60;
    camera.aspect = 4 / 3;
    camera.near = 0.1;
    camera.far = 100;
    camera.position.set(0, 0, 12);
    camera.up.set(0, 1, 0);
    camera.lookAt(0, 0, 0);
    camera.updateProjectionMatrix();
    camera.updateMatrixWorld();
  };
  setCameraPose();
  const cameraPose = camera.clone();
  let selectedId: string | null = null;
  let lastError: 'invalid-ndc' | null = null;
  let pickCount = 0;

  const clearSelection = () => {
    selectedId = null;
    sceneRenderer.selectedObjects = [];
  };

  const performPick = (ndcX: number, ndcY: number): PickingProbeHit | null => {
    if (!sceneRenderer.enableObjectSelection) {
      return null;
    }
    pickCount += 1;
    lastError = null;
    camera.updateMatrixWorld();
    rayCaster.setFromCamera(new Vector2(ndcX, ndcY), camera);
    const intersections: Intersection[] = rayCaster.intersectObject(
      fixture,
      true
    );
    const intersection = intersections[0];
    const id = intersection ? getPickId(intersection.object) : null;
    if (!intersection || !id) {
      clearSelection();
      return null;
    }
    selectedId = id;
    sceneRenderer.selectedObjects = [intersection.object];
    return {
      id,
      point: [intersection.point.x, intersection.point.y, intersection.point.z],
      distance: intersection.distance,
      objectName: intersection.object.name,
    };
  };

  const pick = (ndcX: number, ndcY: number): PickingProbeHit | null => {
    if (
      !Number.isFinite(ndcX) ||
      !Number.isFinite(ndcY) ||
      ndcX < -1 ||
      ndcX > 1 ||
      ndcY < -1 ||
      ndcY > 1
    ) {
      lastError = 'invalid-ndc';
      return null;
    }
    return performPick(ndcX, ndcY);
  };

  const project = (id: string) => {
    const pickGroup = fixturePickGroups.find((group) => group.id === id);
    if (!pickGroup) {
      return null;
    }
    const position = fixture.getObjectByName(pickGroup.id);
    if (!position) {
      return null;
    }
    camera.updateMatrixWorld();
    const projected = new Vector3();
    position.getWorldPosition(projected);
    projected.project(camera);
    return { x: projected.x, y: projected.y, z: projected.z };
  };

  const state = (): PickingProbeState => ({
    selectedId,
    lastError,
    pickCount,
  });

  const reset = () => {
    clearSelection();
    lastError = null;
    pickCount = 0;
    camera.position.copy(cameraPose.position);
    camera.quaternion.copy(cameraPose.quaternion);
    camera.up.copy(cameraPose.up);
    camera.fov = cameraPose.fov;
    camera.aspect = cameraPose.aspect;
    camera.near = cameraPose.near;
    camera.far = cameraPose.far;
    camera.updateProjectionMatrix();
    camera.updateMatrixWorld();
    sceneManager.setOrbitTargetToOrigin();
  };

  const canvas = sceneRenderer.renderer.domElement;
  canvas.addEventListener('pointerdown', (event: PointerEvent) => {
    if (event.button !== 0 || event.isPrimary === false) {
      return;
    }
    const rect = canvas.getBoundingClientRect();
    if (
      event.clientX < rect.left ||
      event.clientX > rect.right ||
      event.clientY < rect.top ||
      event.clientY > rect.bottom
    ) {
      return;
    }
    const x = (2 * (event.clientX - rect.left)) / rect.width - 1;
    const y = (-2 * (event.clientY - rect.top)) / rect.height + 1;
    pick(x, y);
  });

  return { pick, project, state, reset };
};
