import * as THREE from "three";
import "./style.css";

const FPS = 30;
const FINAL_FRAME = 120;
const BEACON_IDS = ["left", "core", "right"];
const CAMERA_OFFSET = new THREE.Vector3(0, 3, 5);

const app = document.querySelector("#app");
const frameReadout = document.querySelector("#frame-readout");
const modeReadout = document.querySelector("#mode-readout");
const selectedReadout = document.querySelector("#selected-readout");
const timelineFill = document.querySelector("#timeline-fill");
const stepButton = document.querySelector("#step-button");
const resetButton = document.querySelector("#reset-button");

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x101018);

const camera = new THREE.PerspectiveCamera(
  50,
  window.innerWidth / window.innerHeight,
  0.1,
  200,
);
camera.position.set(0, 6, 14);

const cameraTarget = new THREE.Vector3(0, 0, 0);
camera.lookAt(cameraTarget);

const renderer = new THREE.WebGLRenderer({
  antialias: true,
  powerPreference: "high-performance",
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.domElement.id = "stage-canvas";
renderer.domElement.setAttribute("aria-label", "Intro Stage Lab viewport");
app.appendChild(renderer.domElement);

const ambientLight = new THREE.AmbientLight(0xcbd8ff, 1.1);
scene.add(ambientLight);

const keyLight = new THREE.DirectionalLight(0xffeedd, 2.7);
keyLight.position.set(5, 13, 9);
keyLight.castShadow = true;
keyLight.shadow.mapSize.set(1024, 1024);
keyLight.shadow.camera.left = -14;
keyLight.shadow.camera.right = 14;
keyLight.shadow.camera.top = 14;
keyLight.shadow.camera.bottom = -14;
keyLight.shadow.camera.near = 1;
keyLight.shadow.camera.far = 40;
scene.add(keyLight);

const rimLight = new THREE.DirectionalLight(0x5b8fff, 0.9);
rimLight.position.set(-8, 5, -10);
scene.add(rimLight);

const stageRoot = new THREE.Group();
stageRoot.name = "StageRoot";
scene.add(stageRoot);

const ground = new THREE.Mesh(
  new THREE.BoxGeometry(20, 0.2, 16),
  new THREE.MeshStandardMaterial({
    color: 0x191a27,
    roughness: 0.74,
    metalness: 0.28,
  }),
);
ground.name = "Ground";
ground.position.set(0, -0.1, 0);
ground.receiveShadow = true;
stageRoot.add(ground);

const floorGrid = new THREE.GridHelper(20, 20, 0x35405c, 0x23283a);
floorGrid.name = "ProceduralFloorGrid";
floorGrid.position.y = 0.003;
floorGrid.scale.z = 0.8;
floorGrid.material.transparent = true;
floorGrid.material.opacity = 0.42;
floorGrid.material.depthWrite = false;
stageRoot.add(floorGrid);

const emblem = new THREE.Group();
emblem.name = "Emblem";
emblem.position.set(-3, -4, -20);

const emblemTorus = new THREE.Mesh(
  new THREE.TorusGeometry(1, 0.25, 32, 64),
  new THREE.MeshStandardMaterial({
    color: 0xffb26e,
    emissive: 0x4a1e08,
    emissiveIntensity: 0.45,
    roughness: 0.26,
    metalness: 0.52,
  }),
);
emblemTorus.name = "EmblemTorus";
emblemTorus.castShadow = true;
emblem.add(emblemTorus);
stageRoot.add(emblem);

const titleBars = new THREE.Group();
titleBars.name = "TitleBars";
titleBars.position.set(3, 0, 0);

const titleColors = [0x5eead4, 0x91a7ff, 0xffc07a];
const titleYs = [0, 0.7, 1.4];
titleYs.forEach((y, index) => {
  const bar = new THREE.Mesh(
    new THREE.BoxGeometry(3, 0.35, 0.5),
    new THREE.MeshStandardMaterial({
      color: titleColors[index],
      roughness: 0.24,
      metalness: 0.36,
    }),
  );
  bar.name = `TitleBar${index + 1}`;
  bar.position.set(0, y, 0);
  bar.castShadow = true;
  titleBars.add(bar);
});
stageRoot.add(titleBars);

const beacons = [];
const beaconConfiguration = [
  { id: "left", position: [-6, 0.75, 2], color: 0x5eead4 },
  { id: "core", position: [0, 0.75, -4], color: 0xffa45e },
  { id: "right", position: [6, 0.75, 2], color: 0xa78bfa },
];

beaconConfiguration.forEach(({ id, position, color }) => {
  const material = new THREE.MeshStandardMaterial({
    color,
    emissive: 0x000000,
    emissiveIntensity: 0,
    roughness: 0.3,
    metalness: 0.44,
  });
  const beacon = new THREE.Mesh(
    new THREE.CylinderGeometry(0.8, 0.8, 1.5, 32),
    material,
  );

  beacon.name = `Beacon_${id}`;
  beacon.position.set(...position);
  beacon.userData.id = id;
  beacon.userData.beacon = true;
  beacon.castShadow = true;
  beacon.receiveShadow = true;
  stageRoot.add(beacon);
  beacons.push(beacon);
});

// Keep the array iterable while also making IDs convenient to inspect.
BEACON_IDS.forEach((id) => {
  Object.defineProperty(beacons, id, {
    value: beacons.find((beacon) => beacon.userData.id === id),
    enumerable: false,
  });
});

let currentFrame = 0;
let mode = "tour";
let selectedId = null;

const raycaster = new THREE.Raycaster();
const pointerNdc = new THREE.Vector2();
const worldPosition = new THREE.Vector3();

function getBeacon(id) {
  if (!BEACON_IDS.includes(id)) {
    return null;
  }
  return beacons.find((beacon) => beacon.userData.id === id) ?? null;
}

function clearHighlights() {
  beacons.forEach((beacon) => {
    beacon.material.emissive.setHex(0x000000);
    beacon.material.emissiveIntensity = 0;
    beacon.material.needsUpdate = true;
  });
}

function applySelection(id) {
  selectedId = id;
  beacons.forEach((beacon) => {
    const isSelected = beacon.userData.id === id;
    beacon.material.emissive.setHex(isSelected ? 0xffffff : 0x000000);
    beacon.material.emissiveIntensity = isSelected ? 0.35 : 0;
    beacon.material.needsUpdate = true;
  });
}

function updateReadouts() {
  frameReadout.innerHTML = `Frame: <strong>${currentFrame}</strong>`;
  modeReadout.innerHTML = `Mode: <strong>${mode}</strong>`;
  selectedReadout.innerHTML = `Selected: <strong>${selectedId ?? "none"}</strong>`;
  timelineFill.style.width = `${(currentFrame / FINAL_FRAME) * 100}%`;
}

function updateTimelineTransforms(frame) {
  const a = Math.min(frame / 15, 1);
  const b = Math.min(frame / 30, 1);

  emblem.position.set(-3, -4 + 4 * a, -20 + 20 * b);
  const titleScale = 1 + 0.25 * a;
  titleBars.scale.setScalar(titleScale);
}

function applyTourCamera(frame) {
  const cameraZ = 14 - 7 * Math.min(frame / 60, 1);
  camera.position.set(0, 6, cameraZ);
  cameraTarget.set(0, 0, 0);
  camera.lookAt(cameraTarget);
  camera.updateMatrixWorld(true);
}

function applyFrame(frame) {
  updateTimelineTransforms(frame);
  if (mode === "tour") {
    applyTourCamera(frame);
  }
}

function setFrame(value) {
  if (typeof value !== "number" || !Number.isFinite(value)) {
    return currentFrame;
  }

  currentFrame = Math.min(FINAL_FRAME, Math.max(0, Math.round(value)));
  applyFrame(currentFrame);
  updateReadouts();
  return currentFrame;
}

function focusSelected(id) {
  const beacon = getBeacon(id);
  if (!beacon) {
    return false;
  }

  scene.updateMatrixWorld(true);
  beacon.getWorldPosition(worldPosition);

  applySelection(id);
  mode = "focus";
  selectedId = id;
  camera.position.copy(worldPosition).add(CAMERA_OFFSET);
  cameraTarget.copy(worldPosition);
  camera.lookAt(cameraTarget);
  camera.updateMatrixWorld(true);
  updateReadouts();
  return true;
}

function projectBeacon(id) {
  const beacon = getBeacon(id);
  if (!beacon) {
    return null;
  }

  scene.updateMatrixWorld(true);
  camera.updateMatrixWorld(true);
  beacon.getWorldPosition(worldPosition).project(camera);

  return {
    x: worldPosition.x,
    y: worldPosition.y,
    z: worldPosition.z,
  };
}

function pickAt(clientX, clientY) {
  const rect = renderer.domElement.getBoundingClientRect();
  if (rect.width <= 0 || rect.height <= 0) {
    return null;
  }

  pointerNdc.set(
    ((clientX - rect.left) / rect.width) * 2 - 1,
    -((clientY - rect.top) / rect.height) * 2 + 1,
  );

  camera.updateMatrixWorld(true);
  raycaster.setFromCamera(pointerNdc, camera);
  const intersections = raycaster.intersectObjects(beacons, false);

  if (intersections.length === 0) {
    return null;
  }

  const id = intersections[0].object.userData.id;
  focusSelected(id);
  return id;
}

function reset() {
  mode = "tour";
  selectedId = null;
  currentFrame = 0;
  clearHighlights();
  updateTimelineTransforms(0);
  camera.position.set(0, 6, 14);
  cameraTarget.set(0, 0, 0);
  camera.lookAt(cameraTarget);
  camera.updateMatrixWorld(true);
  updateReadouts();
}

function getState() {
  return {
    frame: currentFrame,
    mode,
    selectedId,
    cameraPosition: camera.position.toArray(),
    cameraTarget: cameraTarget.toArray(),
    emblemPosition: emblem.position.toArray(),
    titleScale: titleBars.scale.x,
  };
}

function resize() {
  const width = window.innerWidth;
  const height = window.innerHeight;
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setSize(width, height);
}

renderer.domElement.addEventListener("click", (event) => {
  pickAt(event.clientX, event.clientY);
});

stepButton.addEventListener("click", () => {
  setFrame(currentFrame + 1);
});

resetButton.addEventListener("click", reset);
window.addEventListener("resize", resize);

applyFrame(0);
clearHighlights();
updateReadouts();

window.introLab = {
  scene,
  camera,
  renderer,
  stageRoot,
  emblem,
  titleBars,
  beacons,
  setFrame,
  focusSelected,
  projectBeacon,
  pickAt,
  reset,
  getState,
};

function render() {
  renderer.render(scene, camera);
  requestAnimationFrame(render);
}

render();
