import { readFileSync } from 'node:fs';
import { defineConfig } from 'vite';

const inlineStylesPlugin = {
  name: 'inline-entry-styles',
  transformIndexHtml: {
    order: 'pre',
    handler(html) {
      const styles = readFileSync(new URL('./styles.source.css', import.meta.url), 'utf8');
      return html.replace('INLINE_STYLES', () => styles);
    },
  },
};

export default defineConfig({
  plugins: [inlineStylesPlugin],
  build: {
    cssCodeSplit: false,
    chunkSizeWarningLimit: 600,
  },
});
