import * as THREE from 'three';

const CLIPS = {
  idle: {
    duration: 2,
    loop: true,
    rootY: { times: [0, 1, 2], values: [0, 0.1, 0] },
    armZ: { times: [0, 1, 2], values: [0, 0, 0] },
  },
  walk: {
    duration: 1,
    loop: true,
    rootY: { times: [0, 0.5, 1], values: [0, 0.08, 0] },
    armZ: { times: [0, 0.5, 1], values: [0, 0.6, 0] },
  },
  wave: {
    duration: 1.5,
    loop: false,
    rootY: { times: [0, 0.75, 1.5], values: [0, 0, 0] },
    armZ: { times: [0, 0.75, 1.5], values: [0, 2.4, 2.4] },
  },
};

const STEP = 1 / 60;
const PEAK_TIME = 0.75;

const canvas = document.querySelector('#viewport');
const ui = {
  canvas,
  clip: document.querySelector('#clip-value'),
  clipMeta: document.querySelector('#clip-meta'),
  time: document.querySelector('#time-value'),
  timeFill: document.querySelector('#time-fill'),
  playing: document.querySelector('#playing-value'),
  finished: document.querySelector('#finished-value'),
  fade: document.querySelector('#fade-value'),
  fadeMeta: document.querySelector('#fade-meta'),
  events: document.querySelector('#events-value'),
  eventList: document.querySelector('#event-list'),
  playButton: document.querySelector('#play-button'),
  playIcon: document.querySelector('#play-icon'),
  playLabel: document.querySelector('#play-label'),
  stepButton: document.querySelector('#step-button'),
  resetButton: document.querySelector('#reset-button'),
  pose: document.querySelector('#pose-value'),
  clipButtons: [...document.querySelectorAll('.clip-button')],
};

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;

const scene = new THREE.Scene();
scene.fog = new THREE.Fog(0x0b0e0d, 10, 18);

const CAMERA_HOME = new THREE.Vector3(4, 3, 6);
const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 100);
camera.position.copy(CAMERA_HOME);
camera.zoom = 1.38;
camera.updateProjectionMatrix();
camera.lookAt(0, 1.2, 0);

const rig = new THREE.Group();
rig.name = 'rig';
scene.add(rig);

const torso = new THREE.Mesh(
  new THREE.BoxGeometry(1, 1.4, 0.6),
  new THREE.MeshStandardMaterial({ color: 0x8c7a55, roughness: 0.72, metalness: 0.02 }),
);
torso.name = 'torso';
torso.position.set(0, 1.4, 0);
torso.castShadow = true;
torso.receiveShadow = true;
rig.add(torso);

const shoulder = new THREE.Group();
shoulder.name = 'shoulder';
shoulder.position.set(0.75, 1.9, 0);
rig.add(shoulder);

const upperArm = new THREE.Mesh(
  new THREE.BoxGeometry(0.3, 1, 0.3),
  new THREE.MeshStandardMaterial({ color: 0x79ab96, roughness: 0.62, metalness: 0.02 }),
);
upperArm.name = 'upperArm';
upperArm.position.set(0, -0.5, 0);
upperArm.castShadow = true;
upperArm.receiveShadow = true;
shoulder.add(upperArm);

const floor = new THREE.Mesh(
  new THREE.PlaneGeometry(40, 40),
  new THREE.MeshLambertMaterial({ color: 0x1b241f }),
);
floor.rotation.x = -Math.PI / 2;
floor.position.y = -0.002;
floor.receiveShadow = true;
scene.add(floor);

const stage = new THREE.Mesh(
  new THREE.CylinderGeometry(2.15, 2.3, 0.12, 64),
  new THREE.MeshLambertMaterial({ color: 0x202b24 }),
);
stage.position.set(0, -0.045, 0);
stage.receiveShadow = true;
scene.add(stage);

const grid = new THREE.GridHelper(20, 40, 0x4d5b50, 0x263029);
grid.material.transparent = true;
grid.material.opacity = 0.72;
scene.add(grid);

const ring = new THREE.Mesh(
  new THREE.RingGeometry(0.84, 0.87, 64),
  new THREE.MeshBasicMaterial({ color: 0xd9b76b, transparent: true, opacity: 0.38, side: THREE.DoubleSide }),
);
ring.rotation.x = -Math.PI / 2;
ring.position.y = 0.004;
scene.add(ring);

const xAxis = new THREE.Mesh(
  new THREE.BoxGeometry(1.1, 0.012, 0.018),
  new THREE.MeshBasicMaterial({ color: 0xc47558 }),
);
const zAxis = new THREE.Mesh(
  new THREE.BoxGeometry(0.018, 0.012, 1.1),
  new THREE.MeshBasicMaterial({ color: 0x63809b }),
);
xAxis.position.set(0.7, 0.006, 0);
zAxis.position.set(0, 0.006, 0.7);
scene.add(xAxis, zAxis);

const travelGroup = new THREE.Group();
scene.add(travelGroup);

function addPillar(x, z, width, height, color) {
  const mesh = new THREE.Mesh(
    new THREE.BoxGeometry(width, height, width),
    new THREE.MeshStandardMaterial({ color, roughness: 0.8, metalness: 0.04 }),
  );
  mesh.position.set(x, height / 2, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  travelGroup.add(mesh);
  return mesh;
}

addPillar(3.1, -0.7, 0.24, 1.45, 0x4d6156);
addPillar(-2.85, 0.35, 0.2, 1.05, 0x596d5f);
addPillar(2.6, 4.9, 0.18, 1.9, 0x40554a);
addPillar(-2.9, 4.1, 0.28, 0.7, 0x5b7061);
addPillar(3.4, -5.8, 0.26, 1.7, 0x40554a);
addPillar(-2.5, -4.7, 0.18, 1.35, 0x4d6156);

const towerMaterial = new THREE.MeshStandardMaterial({ color: 0x3c5045, roughness: 0.9 });
const towerGeometry = new THREE.BoxGeometry(0.38, 1, 0.38);
const towers = new THREE.InstancedMesh(towerGeometry, towerMaterial, 18);
towers.castShadow = true;
travelGroup.add(towers);

const towerMatrix = new THREE.Matrix4();
const towerQuaternion = new THREE.Quaternion();
const towerScale = new THREE.Vector3();
const towerPosition = new THREE.Vector3();
const towerData = Array.from({ length: 18 }, (_, index) => ({
  x: 4.5 + (Math.sin(index * 7.13) * 0.5 + 0.5) * 2.4,
  z: -24 + index * 3.7,
  width: 0.35 + (Math.sin(index * 4.77) * 0.5 + 0.5) * 0.38,
  height: 0.55 + (Math.sin(index * 3.17) * 0.5 + 0.5) * 1.75,
}));

function updateTowers() {
  towerData.forEach((tower, index) => {
    towerPosition.set(tower.x, tower.height / 2, tower.z);
    towerScale.set(tower.width / 0.38, tower.height, tower.width / 0.38);
    towerMatrix.compose(towerPosition, towerQuaternion, towerScale);
    towers.setMatrixAt(index, towerMatrix);
  });
  towers.instanceMatrix.needsUpdate = true;
}

scene.add(new THREE.HemisphereLight(0xdde8d9, 0x262d28, 2.6));
const keyLight = new THREE.DirectionalLight(0xffe4b0, 2.5);
keyLight.position.set(3, 6, 2);
keyLight.castShadow = true;
keyLight.shadow.mapSize.set(1024, 1024);
keyLight.shadow.camera.left = -5;
keyLight.shadow.camera.right = 5;
keyLight.shadow.camera.top = 6;
keyLight.shadow.camera.bottom = -2;
keyLight.shadow.bias = -0.0008;
scene.add(keyLight);
const rimLight = new THREE.DirectionalLight(0x7bb8a0, 1.3);
rimLight.position.set(-4, 2.5, -3);
scene.add(rimLight);

function sampleTrack(track, trackTime) {
  const { times, values } = track;
  const last = times.length - 1;
  if (trackTime <= times[0]) return values[0];
  if (trackTime >= times[last]) return values[last];
  let index = 0;
  while (index < last && trackTime >= times[index + 1]) index += 1;
  const fraction = (trackTime - times[index]) / (times[index + 1] - times[index]);
  return values[index] * (1 - fraction) + values[index + 1] * fraction;
}

function poseAt(name, trackTime) {
  const clip = CLIPS[name];
  return {
    rootY: sampleTrack(clip.rootY, trackTime),
    armZ: sampleTrack(clip.armZ, trackTime),
  };
}

function isFiniteNumber(value) {
  return typeof value === 'number' && Number.isFinite(value);
}

function assertNonNegative(value, name) {
  if (!isFiniteNumber(value) || value < 0) {
    throw new RangeError(`${name} must be a finite, non-negative number`);
  }
}

let clipName = 'idle';
let time = 0;
let playing = false;
let finished = false;
let fadeElapsed = 0;
let fadeSeconds = 0;
let outgoingPose = null;
let eventLog = [];
let wavePeakArmed = false;
let previousRootY = 0;
let poseVelocity = 0;

function addEvent(name) {
  eventLog.push({
    name,
    clip: clipName,
    time,
    sequence: eventLog.length + 1,
  });
}

function triggerWavePeak() {
  wavePeakArmed = false;
  const savedTime = time;
  time = PEAK_TIME;
  addEvent('wave-peak');
  time = savedTime;
}

function crossWavePeak(fromTime, toTime) {
  if (clipName !== 'wave' || !wavePeakArmed) return;
  if (fromTime < PEAK_TIME && toTime >= PEAK_TIME) triggerWavePeak();
}

function applyPose(pose) {
  rig.position.y = pose.rootY;
  shoulder.rotation.z = pose.armZ;

  const targetVelocity = (pose.rootY - previousRootY) / STEP;
  poseVelocity += (targetVelocity - poseVelocity) * 0.16;
  previousRootY = pose.rootY;
  torso.rotation.x = -poseVelocity * 0.06;

  updateUi();
}

function sampleAndApply() {
  const target = poseAt(clipName, time);
  let pose = target;
  if (fadeSeconds > 0 && outgoingPose) {
    const u = Math.min(Math.max(fadeElapsed / fadeSeconds, 0), 1);
    const smooth = u * u * (3 - 2 * u);
    pose = {
      rootY: outgoingPose.rootY * (1 - smooth) + target.rootY * smooth,
      armZ: outgoingPose.armZ * (1 - smooth) + target.armZ * smooth,
    };
  }
  applyPose(pose);
}

function advance(dt) {
  const previousTime = time;
  const clip = CLIPS[clipName];
  let nextTime = time + dt;

  if (clip.loop) {
    nextTime = nextTime % clip.duration;
  } else if (nextTime >= clip.duration) {
    nextTime = clip.duration;
    playing = false;
    finished = true;
  }

  crossWavePeak(previousTime, nextTime);
  time = nextTime;

  if (fadeSeconds > 0) {
    const fadeFinished = fadeElapsed + dt >= fadeSeconds;
    fadeElapsed = fadeFinished ? fadeSeconds : fadeElapsed + dt;
    if (fadeFinished) {
      fadeElapsed = 0;
      fadeSeconds = 0;
      outgoingPose = null;
    }
  }
  sampleAndApply();
}

function updateUi() {
  const clip = CLIPS[clipName];
  ui.clip.textContent = clipName;
  ui.clipMeta.textContent = `${clip.duration.toFixed(2)} s · ${clip.loop ? 'loop' : 'one shot'}`;
  ui.time.innerHTML = `${time.toFixed(3)}<small> s</small>`;
  ui.timeFill.style.width = `${(time / clip.duration) * 100}%`;
  ui.playing.textContent = playing ? 'Playing' : 'Paused';
  ui.playing.style.color = playing ? 'var(--mint)' : 'var(--ink)';
  ui.finished.textContent = finished ? 'Finished' : 'Not finished';
  ui.fade.textContent = fadeSeconds > 0 ? `${Math.round((fadeElapsed / fadeSeconds) * 100)}%` : '—';
  ui.fadeMeta.textContent = fadeSeconds > 0
    ? `${fadeElapsed.toFixed(3)} / ${fadeSeconds.toFixed(3)} s`
    : 'No transition';
  ui.events.textContent = String(eventLog.length);
  ui.pose.textContent = `rootY ${rig.position.y.toFixed(3)} · armZ ${shoulder.rotation.z.toFixed(3)}`;
  ui.playIcon.textContent = playing ? '❚❚' : '▶';
  ui.playLabel.textContent = playing ? 'Pause' : 'Play';
  ui.clipButtons.forEach((button) => {
    button.classList.toggle('is-active', button.dataset.clip === clipName);
  });

  if (eventLog.length === 0) {
    ui.eventList.innerHTML = '<li class="empty">No events recorded</li>';
  } else {
    ui.eventList.replaceChildren(...eventLog.map((event) => {
      const item = document.createElement('li');
      const label = document.createElement('span');
      label.textContent = event.name;
      const stamp = document.createElement('time');
      stamp.textContent = `${event.clip} · ${event.time.toFixed(3)}s`;
      item.append(label, stamp);
      return item;
    }));
    ui.eventList.scrollTop = ui.eventList.scrollHeight;
  }
}

function cancelFade() {
  fadeElapsed = 0;
  fadeSeconds = 0;
  outgoingPose = null;
}

function getState() {
  return {
    clip: clipName,
    time,
    playing,
    finished,
    fadeElapsed,
    fadeSeconds,
    rootY: rig.position.y,
    armZ: shoulder.rotation.z,
    events: eventLog.map((event) => ({ ...event })),
    log: eventLog.map((event) => ({ ...event })),
  };
}

const clipLab = {
  seek(t) {
    assertNonNegative(t, 'time');
    const clip = CLIPS[clipName];
    const previousTime = time;
    const nextTime = clip.loop ? t % clip.duration : Math.min(t, clip.duration);
    crossWavePeak(previousTime, nextTime);
    time = nextTime;
    if (!clip.loop && t >= clip.duration) {
      playing = false;
      finished = true;
    }
    sampleAndApply();
  },

  step(frames) {
    assertNonNegative(frames, 'frames');
    const wasPlaying = playing;
    advance(frames * STEP);
    playing = wasPlaying;
    updateUi();
  },

  play() {
    playing = true;
    updateUi();
  },

  pause() {
    playing = false;
    updateUi();
  },

  setClip(name, fade) {
    if (typeof name !== 'string' || !Object.hasOwn(CLIPS, name)) {
      throw new RangeError(`unknown clip: ${String(name)}`);
    }
    assertNonNegative(fade, 'fade duration');

    const currentPose = { rootY: rig.position.y, armZ: shoulder.rotation.z };
    clipName = name;
    time = 0;
    finished = false;
    fadeSeconds = fade;
    fadeElapsed = 0;
    outgoingPose = fade > 0 ? currentPose : null;
    wavePeakArmed = name === 'wave';

    if (name === 'wave') addEvent('wave-start');
    sampleAndApply();
  },

  getState() {
    return getState();
  },

  reset() {
    clipName = 'idle';
    time = 0;
    playing = false;
    finished = false;
    cancelFade();
    eventLog = [];
    wavePeakArmed = false;
      previousRootY = 0;
      poseVelocity = 0;
    rig.position.y = 0;
    torso.rotation.x = 0;
    torso.position.y = 1.4;
    shoulder.rotation.z = 0;
      updateUi();
  },
};

window.clipLab = clipLab;

function resize() {
  const width = window.innerWidth;
  const height = window.innerHeight;
  renderer.setSize(width, height, false);
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer.render(scene, camera);
}

let pointerTargetX = 0;
let pointerTargetY = 0;
window.addEventListener('resize', () => {
  resize();
  applyViewportLayout();
});
window.addEventListener('pointermove', (event) => {
  pointerTargetX = event.clientX / window.innerWidth - 0.5;
  pointerTargetY = event.clientY / window.innerHeight - 0.5;
});

const cameraTarget = new THREE.Vector3();
function updateCamera() {
  cameraTarget.set(
    CAMERA_HOME.x + pointerTargetX * 0.32,
    CAMERA_HOME.y - pointerTargetY * 0.2,
    CAMERA_HOME.z,
  );
  camera.position.lerp(cameraTarget, 0.02);
  camera.lookAt(0, 1.2, 0);
}

ui.playButton.addEventListener('click', () => {
  if (playing) clipLab.pause();
  else clipLab.play();
});
ui.stepButton.addEventListener('click', () => clipLab.step(1));
ui.canvas.addEventListener('pointerdown', (event) => {
  const rect = ui.canvas.getBoundingClientRect();
  const x = (event.clientX - rect.left) / rect.width - 0.5;
  const y = (event.clientY - rect.top) / rect.height - 0.5;
  const focus = document.createElement('div');
  focus.className = 'canvas-focus';
  focus.style.left = `${x * 100 + 50}%`;
  focus.style.top = `${y * 100 + 50}%`;
  ui.canvas.parentElement.append(focus);
  focus.addEventListener('animationend', () => focus.remove(), { once: true });
});
ui.resetButton.addEventListener('click', () => clipLab.reset());
ui.clipButtons.forEach((button) => {
  button.addEventListener('click', () => clipLab.setClip(button.dataset.clip, 0.35));
});

function renderFrame() {
  if (playing) advance(STEP);
  updateCamera();
  renderer.render(scene, camera);
  requestAnimationFrame(renderFrame);
}

updateTowers();
function applyViewportLayout() {
  const narrow = window.innerWidth <= 620;
  const short = window.innerHeight <= 700;
  camera.zoom = narrow ? (short ? 1.4 : 0.95) : (short ? 1.08 : 1.38);
  rig.position.z = narrow ? 0 : 0;
  camera.updateProjectionMatrix();
}

resize();
applyViewportLayout();
clipLab.reset();
requestAnimationFrame(renderFrame);
