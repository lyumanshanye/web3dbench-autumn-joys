import * as THREE from 'three';
import './style.css';

const EPSILON = 1e-5;
const TRACK_RADIUS = 50;
const START_ANGLE = Math.PI / 2;
const AUTO_SPAWN_INTERVAL = 750;
const AUTO_SPAWN_ANGLES = [0, Math.PI, Math.PI / 2, (3 * Math.PI) / 2];

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x061722);
scene.fog = new THREE.Fog(0x061722, 125, 235);

const camera = new THREE.PerspectiveCamera(
  75,
  window.innerWidth / window.innerHeight,
  1,
  200,
);
camera.position.set(0, 0, 100);
camera.lookAt(0, 0, 0);

const renderer = new THREE.WebGLRenderer({
  antialias: true,
  powerPreference: 'high-performance',
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
document.querySelector('#app').appendChild(renderer.domElement);

scene.add(new THREE.AmbientLight(0x9fd8e8, 1.55));

const sun = new THREE.DirectionalLight(0xfff1d0, 2.2);
sun.position.set(65, 90, 120);
scene.add(sun);

const water = new THREE.Mesh(
  new THREE.PlaneGeometry(500, 500),
  new THREE.MeshStandardMaterial({
    color: 0x073b52,
    roughness: 0.68,
    metalness: 0.16,
  }),
);
water.name = 'water';
water.position.z = -4;
scene.add(water);

const island = new THREE.Mesh(
  new THREE.CylinderGeometry(8, 8, 4, 64),
  new THREE.MeshStandardMaterial({
    color: 0x9fcfca,
    roughness: 0.78,
    metalness: 0.02,
  }),
);
island.name = 'island';
island.rotation.x = Math.PI / 2;
island.position.set(0, 0, -2);
scene.add(island);

const islandCap = new THREE.Mesh(
  new THREE.CylinderGeometry(7.4, 7.7, 0.35, 64),
  new THREE.MeshStandardMaterial({
    color: 0xd8eee8,
    roughness: 0.74,
    metalness: 0,
  }),
);
islandCap.name = 'island-cap';
islandCap.rotation.x = Math.PI / 2;
islandCap.position.set(0, 0, 0.12);
scene.add(islandCap);

const track = new THREE.Mesh(
  new THREE.TorusGeometry(TRACK_RADIUS, 0.3, 8, 64),
  new THREE.MeshStandardMaterial({
    color: 0x54b8c9,
    emissive: 0x123d48,
    emissiveIntensity: 0.8,
    roughness: 0.42,
    metalness: 0.34,
  }),
);
track.name = 'track';
track.position.z = 0;
scene.add(track);

const ship = new THREE.Group();
ship.name = 'ship';

const hullMaterial = new THREE.MeshStandardMaterial({
  color: 0x183f5b,
  roughness: 0.52,
  metalness: 0.28,
});
const deckMaterial = new THREE.MeshStandardMaterial({
  color: 0xe6f1ee,
  roughness: 0.6,
  metalness: 0.08,
});
const accentMaterial = new THREE.MeshStandardMaterial({
  color: 0xe75747,
  roughness: 0.55,
  metalness: 0.12,
});
const mastMaterial = new THREE.MeshStandardMaterial({
  color: 0x27333b,
  roughness: 0.66,
  metalness: 0.22,
});

const hull = new THREE.Mesh(new THREE.BoxGeometry(2.5, 8, 1.5), hullMaterial);
hull.position.set(0, 0, 0.45);
ship.add(hull);

const deck = new THREE.Mesh(new THREE.BoxGeometry(1.65, 6.2, 1.25), deckMaterial);
deck.position.set(0, -0.55, 1.55);
ship.add(deck);

const cabin = new THREE.Mesh(
  new THREE.BoxGeometry(1.5, 2.6, 1.1),
  accentMaterial,
);
cabin.position.set(0, -1.25, 2.5);
ship.add(cabin);

const bow = new THREE.Mesh(new THREE.ConeGeometry(1.45, 3, 4), hullMaterial);
bow.name = 'bow';
bow.position.set(0, 5.25, 0.45);
ship.add(bow);

const mast = new THREE.Mesh(new THREE.ConeGeometry(0.5, 3.4, 4), mastMaterial);
mast.name = 'mast';
mast.position.set(0, -2.4, 1.75);
ship.add(mast);

scene.add(ship);

const coins = new THREE.Group();
coins.name = 'coins';
const coinGeometry = new THREE.CylinderGeometry(2, 2, 0.5, 16);
const coinMaterial = new THREE.MeshStandardMaterial({
  color: 0xf7ca45,
  emissive: 0x8a5c00,
  emissiveIntensity: 0.5,
  metalness: 0.28,
  roughness: 0.32,
});

for (let i = 0; i < 31; i += 1) {
  const coinAngle = START_ANGLE + (i + 1) * (2 * Math.PI) / 32;
  const coin = new THREE.Mesh(coinGeometry, coinMaterial);
  coin.name = `coin-${i}`;
  coin.rotation.x = Math.PI / 2;
  coin.position.set(
    TRACK_RADIUS * Math.cos(coinAngle),
    TRACK_RADIUS * Math.sin(coinAngle),
    0,
  );
  coins.add(coin);
}
scene.add(coins);

const cannonballs = new THREE.Group();
cannonballs.name = 'cannonballs';
const cannonballGeometry = new THREE.SphereGeometry(2, 16, 16);
const cannonballMaterial = new THREE.MeshStandardMaterial({
  color: 0x11171d,
  roughness: 0.48,
  metalness: 0.66,
});
scene.add(cannonballs);

let time = 0;
let score = 0;
let angle = START_ANGLE;
let direction = 1;
let status = 'running';
let autoSpawnIndex = 0;
let ballSerial = 0;

function setShipTransform() {
  ship.position.set(
    TRACK_RADIUS * Math.cos(angle),
    TRACK_RADIUS * Math.sin(angle),
    0,
  );
  ship.rotation.z = direction === 1 ? angle : angle - Math.PI;
}

function setBallTransform(ball) {
  const { angle: ballAngle, radius } = ball.userData;
  ball.position.set(
    radius * Math.cos(ballAngle),
    radius * Math.sin(ballAngle),
    0,
  );
}

function spawnBall(ballAngle, radius) {
  if (
    !Number.isFinite(ballAngle) ||
    !Number.isFinite(radius) ||
    radius < 0 ||
    radius > TRACK_RADIUS
  ) {
    throw new RangeError('spawnBall requires a finite angle and radius in [0, 50].');
  }

  const ball = new THREE.Mesh(cannonballGeometry, cannonballMaterial);
  ball.name = `cannonball-${ballSerial}`;
  ballSerial += 1;
  ball.userData.angle = ballAngle;
  ball.userData.radius = radius;
  setBallTransform(ball);
  cannonballs.add(ball);
  return ball;
}

function collectNearbyCoins() {
  for (const coin of coins.children) {
    if (!coin.visible) {
      continue;
    }

    const distance = Math.hypot(
      coin.position.x - ship.position.x,
      coin.position.y - ship.position.y,
      coin.position.z - ship.position.z,
    );

    if (distance <= 6 + EPSILON) {
      coin.visible = false;
      score += 1;
    }
  }
}

function shipWasHit() {
  return cannonballs.children.some((ball) => {
    const distance = Math.hypot(
      ball.position.x - ship.position.x,
      ball.position.y - ship.position.y,
      ball.position.z - ship.position.z,
    );
    return distance <= 6 + EPSILON;
  });
}

function tick() {
  time += 1;
  angle += direction * 0.0014;

  for (const ball of cannonballs.children) {
    ball.userData.radius += 0.035;
    setBallTransform(ball);
  }

  if (time % AUTO_SPAWN_INTERVAL === 0) {
    spawnBall(AUTO_SPAWN_ANGLES[autoSpawnIndex % AUTO_SPAWN_ANGLES.length], 0);
    autoSpawnIndex += 1;
  }

  setShipTransform();
  collectNearbyCoins();

  if (shipWasHit()) {
    status = 'destroyed';
  } else if (score === coins.children.length) {
    status = 'won';
  }
}

function step(ms) {
  if (!Number.isInteger(ms) || ms < 0 || ms > 10_000) {
    throw new RangeError('step(ms) requires an integer from 0 through 10000.');
  }

  for (let index = 0; index < ms && status === 'running'; index += 1) {
    tick();
  }

  renderReadout();
}

function toggleDirection() {
  direction *= -1;
  setShipTransform();
  renderReadout();
}

function reset() {
  time = 0;
  score = 0;
  angle = START_ANGLE;
  direction = 1;
  status = 'running';
  autoSpawnIndex = 0;
  ballSerial = 0;

  for (const coin of coins.children) {
    coin.visible = true;
  }

  cannonballs.clear();
  setShipTransform();
  renderReadout();
}

function getState() {
  return {
    time,
    score,
    angle,
    direction,
    status,
    collectedCount: score,
    ballCount: cannonballs.children.length,
  };
}

setShipTransform();

const harborLab = {
  scene,
  camera,
  ship,
  coins,
  cannonballs,
  step,
  toggleDirection,
  spawnBall,
  reset,
  getState,
};

window.harborLab = harborLab;

const readout = document.querySelector('#state-readout');
const statusChip = document.querySelector('#status-chip');
let lastReadout = '';
let lastStatus = '';

function renderReadout() {
  const state = getState();
  const nextReadout = JSON.stringify(state, null, 2);

  if (nextReadout !== lastReadout) {
    readout.textContent = nextReadout;
    lastReadout = nextReadout;
  }

  if (state.status !== lastStatus) {
    statusChip.textContent = state.status;
    statusChip.dataset.status = state.status;
    lastStatus = state.status;
  }
}

function performAction(action) {
  try {
    action();
  } finally {
    renderReadout();
  }
}

document
  .querySelector('#step-1')
  .addEventListener('click', () => performAction(() => harborLab.step(1)));
document
  .querySelector('#step-100')
  .addEventListener('click', () => performAction(() => harborLab.step(100)));
document
  .querySelector('#toggle-direction')
  .addEventListener('click', () =>
    performAction(() => harborLab.toggleDirection()),
  );
document
  .querySelector('#reset')
  .addEventListener('click', () => performAction(() => harborLab.reset()));

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
});

renderReadout();

function renderFrame() {
  renderer.render(scene, camera);
  renderReadout();
  window.requestAnimationFrame(renderFrame);
}

window.requestAnimationFrame(renderFrame);
