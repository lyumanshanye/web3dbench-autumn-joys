import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { chromium } from 'playwright';

const PORT = 4174;
const URL = `http://127.0.0.1:${PORT}/`;
const EPSILON = 1e-5;

function closeTo(actual, expected, message) {
  assert.ok(
    Math.abs(actual - expected) <= EPSILON,
    `${message}: expected ${expected}, received ${actual}`,
  );
}

async function waitForServer(url) {
  const deadline = Date.now() + 15_000;

  while (Date.now() < deadline) {
    try {
      const response = await fetch(url);
      if (response.ok) {
        return;
      }
    } catch {
      // The preview server may still be starting.
    }
    await new Promise((resolve) => setTimeout(resolve, 100));
  }

  throw new Error(`Preview server did not start at ${url}`);
}

const server = spawn(
  'npx',
  ['vite', 'preview', '--host', '127.0.0.1', '--port', String(PORT), '--strictPort'],
  { stdio: 'ignore' },
);

let browser;

try {
  await waitForServer(URL);
  browser = await chromium.launch({
    headless: true,
    args: ['--enable-unsafe-swiftshader'],
  });
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  const requests = [];
  const pageErrors = [];

  page.on('request', (request) => requests.push(request.url()));
  page.on('pageerror', (error) => pageErrors.push(error.message));

  await page.goto(URL, { waitUntil: 'networkidle' });
  await page.waitForFunction(() => Boolean(window.harborLab));

  assert.deepEqual(requests, [URL], 'the page should make no subresource requests');
  assert.deepEqual(pageErrors, [], 'the page should have no uncaught errors');

  const initial = await page.evaluate(() => {
    const lab = window.harborLab;
    const water = lab.scene.getObjectByName('water');
    const island = lab.scene.getObjectByName('island');
    const track = lab.scene.getObjectByName('track');
    const lights = lab.scene.children.map((child) => child.type);
    const coin = lab.coins.children[0];

    return {
      state: lab.getState(),
      camera: {
        fov: lab.camera.fov,
        near: lab.camera.near,
        far: lab.camera.far,
        position: lab.camera.position.toArray(),
        quaternion: lab.camera.quaternion.toArray(),
      },
      water: {
        width: water.geometry.parameters.width,
        height: water.geometry.parameters.height,
        z: water.position.z,
      },
      island: {
        radiusTop: island.geometry.parameters.radiusTop,
        radiusBottom: island.geometry.parameters.radiusBottom,
        height: island.geometry.parameters.height,
        position: island.position.toArray(),
        rotationX: island.rotation.x,
      },
      track: {
        radius: track.geometry.parameters.radius,
        tubularSegments: track.geometry.parameters.tubularSegments,
        z: track.position.z,
      },
      lights,
      ship: {
        name: lab.ship.name,
        type: lab.ship.type,
        position: lab.ship.position.toArray(),
        rotationZ: lab.ship.rotation.z,
        childGeometryTypes: lab.ship.children.map(
          (child) => child.geometry.type,
        ),
      },
      coinCount: lab.coins.children.length,
      coin: {
        name: coin.name,
        geometry: {
          radiusTop: coin.geometry.parameters.radiusTop,
          radiusBottom: coin.geometry.parameters.radiusBottom,
          height: coin.geometry.parameters.height,
          radialSegments: coin.geometry.parameters.radialSegments,
        },
        rotationX: coin.rotation.x,
        position: coin.position.toArray(),
      },
      cannonballsName: lab.cannonballs.name,
      canvas: [...document.querySelectorAll('canvas')].map((element) => ({
        width: element.clientWidth,
        height: element.clientHeight,
        pixelWidth: element.width,
        pixelHeight: element.height,
      })),
    };
  });

  assert.deepEqual(Object.keys(initial.state).sort(), [
    'angle',
    'ballCount',
    'collectedCount',
    'direction',
    'score',
    'status',
    'time',
  ]);
  assert.equal(initial.state.time, 0);
  assert.equal(initial.state.score, 0);
  assert.equal(initial.state.direction, 1);
  assert.equal(initial.state.status, 'running');
  assert.equal(initial.state.collectedCount, 0);
  assert.equal(initial.state.ballCount, 0);
  closeTo(initial.state.angle, Math.PI / 2, 'initial angle');

  assert.equal(initial.camera.fov, 75);
  assert.equal(initial.camera.near, 1);
  assert.equal(initial.camera.far, 200);
  assert.deepEqual(initial.camera.position, [0, 0, 100]);
  closeTo(initial.camera.quaternion[3], 1, 'camera looks at origin');

  assert.deepEqual(initial.water, { width: 500, height: 500, z: -4 });
  assert.equal(initial.island.radiusTop, 8);
  assert.equal(initial.island.radiusBottom, 8);
  assert.equal(initial.island.height, 4);
  assert.deepEqual(initial.island.position, [0, 0, -2]);
  closeTo(initial.island.rotationX, Math.PI / 2, 'island orientation');
  assert.equal(initial.track.radius, 50);
  assert.equal(initial.track.tubularSegments, 64);
  assert.equal(initial.track.z, 0);
  assert.ok(initial.lights.includes('AmbientLight'));
  assert.ok(initial.lights.includes('DirectionalLight'));

  assert.equal(initial.ship.name, 'ship');
  assert.equal(initial.ship.type, 'Group');
  closeTo(initial.ship.position[0], 0, 'initial ship x');
  closeTo(initial.ship.position[1], 50, 'initial ship y');
  closeTo(initial.ship.position[2], 0, 'initial ship z');
  closeTo(initial.ship.rotationZ, Math.PI / 2, 'initial ship rotation');
  assert.ok(initial.ship.childGeometryTypes.every((type) => ['BoxGeometry', 'ConeGeometry'].includes(type)));

  assert.equal(initial.coinCount, 31);
  assert.equal(initial.coin.name, 'coin-0');
  assert.deepEqual(initial.coin.geometry, {
    radiusTop: 2,
    radiusBottom: 2,
    height: 0.5,
    radialSegments: 16,
  });
  closeTo(initial.coin.rotationX, Math.PI / 2, 'coin orientation');
  closeTo(
    initial.coin.position[0],
    50 * Math.cos(Math.PI / 2 + Math.PI / 16),
    'coin x',
  );
  closeTo(
    initial.coin.position[1],
    50 * Math.sin(Math.PI / 2 + Math.PI / 16),
    'coin y',
  );
  assert.equal(initial.cannonballsName, 'cannonballs');
  assert.deepEqual(initial.canvas, [
    { width: 1280, height: 800, pixelWidth: 1280, pixelHeight: 800 },
  ]);

  await page.waitForTimeout(250);
  assert.deepEqual(
    await page.evaluate(() => window.harborLab.getState()),
    initial.state,
    'requestAnimationFrame must not advance the simulation',
  );

  const invalidStepResult = await page.evaluate(() => {
    const lab = window.harborLab;
    const before = JSON.stringify(lab.getState());
    const invalidValues = [-1, 10001, 1.5, NaN, Infinity, '1', null, undefined];
    const errors = invalidValues.map((value) => {
      try {
        lab.step(value);
        return 'did not throw';
      } catch (error) {
        return error.name;
      }
    });
    return { errors, unchanged: JSON.stringify(lab.getState()) === before };
  });
  assert.ok(invalidStepResult.errors.every((name) => name === 'RangeError'));
  assert.equal(invalidStepResult.unchanged, true);

  const stepped = await page.evaluate(() => {
    const lab = window.harborLab;
    lab.step(1);
    return {
      state: lab.getState(),
      position: lab.ship.position.toArray(),
      rotationZ: lab.ship.rotation.z,
    };
  });
  closeTo(stepped.state.angle, Math.PI / 2 + 0.0014, 'angle after 1 ms');
  closeTo(stepped.position[0], 50 * Math.cos(Math.PI / 2 + 0.0014), 'ship x after 1 ms');
  closeTo(stepped.position[1], 50 * Math.sin(Math.PI / 2 + 0.0014), 'ship y after 1 ms');
  closeTo(stepped.rotationZ, Math.PI / 2 + 0.0014, 'ship rotation after 1 ms');

  const toggled = await page.evaluate(() => {
    const lab = window.harborLab;
    const positionBefore = lab.ship.position.toArray();
    lab.toggleDirection();
    return {
      state: lab.getState(),
      positionBefore,
      rotationZ: lab.ship.rotation.z,
      positionAfter: lab.ship.position.toArray(),
    };
  });
  assert.equal(toggled.state.direction, -1);
  closeTo(toggled.rotationZ, toggled.state.angle - Math.PI, 'reverse rotation');
  assert.deepEqual(toggled.positionAfter, toggled.positionBefore);

  const spawnResult = await page.evaluate(() => {
    const lab = window.harborLab;
    lab.reset();
    const errors = [];
    for (const [angle, radius] of [
      [NaN, 0],
      [0, NaN],
      [0, -1],
      [0, 50.0001],
      [Infinity, 0],
    ]) {
      try {
        lab.spawnBall(angle, radius);
        errors.push('did not throw');
      } catch (error) {
        errors.push(error.name);
      }
    }
    const ball = lab.spawnBall(Math.PI / 3, 12.5);
    return {
      errors,
      sameParent: ball.parent === lab.cannonballs,
      ballCount: lab.getState().ballCount,
      position: ball.position.toArray(),
      geometry: {
        radius: ball.geometry.parameters.radius,
        widthSegments: ball.geometry.parameters.widthSegments,
        heightSegments: ball.geometry.parameters.heightSegments,
      },
      materialColor: ball.material.color.getHex(),
    };
  });
  assert.ok(spawnResult.errors.every((name) => name === 'RangeError'));
  assert.equal(spawnResult.sameParent, true);
  assert.equal(spawnResult.ballCount, 1);
  closeTo(spawnResult.position[0], 12.5 * Math.cos(Math.PI / 3), 'ball x');
  closeTo(spawnResult.position[1], 12.5 * Math.sin(Math.PI / 3), 'ball y');
  assert.equal(spawnResult.position[2], 0);
  assert.deepEqual(spawnResult.geometry, {
    radius: 2,
    widthSegments: 16,
    heightSegments: 16,
  });
  assert.equal(spawnResult.materialColor, 0x11171d);

  const autoSpawn = await page.evaluate(() => {
    const lab = window.harborLab;
    lab.reset();
    lab.step(750);
    const at750 = {
      state: lab.getState(),
      positions: lab.cannonballs.children.map((ball) => ball.position.toArray()),
    };
    lab.step(1);
    const at751 = {
      state: lab.getState(),
      positions: lab.cannonballs.children.map((ball) => ball.position.toArray()),
    };
    return { at750, at751 };
  });
  assert.equal(autoSpawn.at750.state.ballCount, 1);
  assert.deepEqual(autoSpawn.at750.positions[0], [0, 0, 0]);
  closeTo(autoSpawn.at751.positions[0][0], 0.035, 'ball radial speed');
  assert.equal(autoSpawn.at751.state.ballCount, 1);

  const autoCycle = await page.evaluate(() => {
    const lab = window.harborLab;
    lab.reset();
    lab.step(750 * 4);
    return lab.cannonballs.children.map((ball) => ball.userData.angle);
  });
  assert.deepEqual(autoCycle, [0, Math.PI, Math.PI / 2, (3 * Math.PI) / 2]);

  const winState = await page.evaluate(() => {
    const lab = window.harborLab;
    lab.reset();
    lab.step(10_000);
    const terminal = lab.getState();
    const invisibleCount = lab.coins.children.filter((coin) => !coin.visible).length;
    lab.step(10_000);
    return {
      terminal,
      after: lab.getState(),
      invisibleCount,
      childCount: lab.coins.children.length,
    };
  });
  assert.equal(winState.terminal.status, 'won');
  assert.equal(winState.terminal.score, 31);
  assert.equal(winState.terminal.collectedCount, 31);
  assert.equal(winState.invisibleCount, 31);
  assert.equal(winState.childCount, 31);
  assert.deepEqual(winState.after, winState.terminal, 'won state is frozen');

  const destroyState = await page.evaluate(() => {
    const lab = window.harborLab;
    lab.reset();
    const angleAtSpawn = lab.getState().angle;
    lab.spawnBall(angleAtSpawn, 50);
    lab.step(1);
    const terminal = lab.getState();
    lab.step(250);
    return { terminal, after: lab.getState(), angleAtSpawn };
  });
  assert.equal(destroyState.terminal.status, 'destroyed');
  assert.equal(destroyState.terminal.time, 1);
  assert.deepEqual(destroyState.after, destroyState.terminal, 'destroyed state is frozen');

  const buttonParity = await page.evaluate(() => {
    const lab = window.harborLab;
    const click = (selector) => document.querySelector(selector).click();
    lab.reset();
    lab.step(1);
    lab.toggleDirection();
    lab.step(100);
    const apiState = lab.getState();
    lab.reset();
    click('#step-1');
    click('#toggle-direction');
    click('#step-100');
    const uiState = lab.getState();
    const readoutState = JSON.parse(
      document.querySelector('#state-readout').textContent,
    );
    click('#reset');
    return { apiState, uiState, readoutState, resetState: lab.getState() };
  });
  assert.deepEqual(buttonParity.uiState, buttonParity.apiState);
  assert.deepEqual(buttonParity.readoutState, buttonParity.uiState);
  assert.equal(buttonParity.resetState.time, 0);
  assert.equal(buttonParity.resetState.ballCount, 0);
  assert.equal(buttonParity.resetState.status, 'running');

  console.log('Polar Harbor Lab verification passed.');
} finally {
  await browser?.close();
  server.kill('SIGTERM');
}
