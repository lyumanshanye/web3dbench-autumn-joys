import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const STORAGE_KEY = 'scroll-chair-studio-v1';
const MODES = ['browse', 'customize'];
const COLORS = {
  green: '#96b2a1',
  red: '#a57d7d',
  violet: '#aa83aa',
};
const TARGET = [0, 1, 0];
const BROWSE_A = [0, 2, 6];
const BROWSE_B = [0, 1.5, 3.25];
const BROWSE_C = [-3, 1.5, 0];
const INITIAL_CAMERA = BROWSE_A;
const CUSTOMIZE_CAMERA = [-1.95, 2.54, 2.29];

const canvas = document.getElementById('stage');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;

const scene = new THREE.Scene();
scene.background = new THREE.Color('#eceae3');
scene.fog = new THREE.Fog('#eceae3', 12, 24);

const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
camera.position.set(...INITIAL_CAMERA);
camera.lookAt(...TARGET);

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(...TARGET);
controls.enableDamping = true;
controls.dampingFactor = 0.08;
controls.minDistance = 1.5;
controls.maxDistance = 10;
controls.maxPolarAngle = Math.PI / 2 - 0.02;
controls.enabled = false;
controls.update();

const hemisphere = new THREE.HemisphereLight('#f4f1e8', '#8d948c', 1.15);
scene.add(hemisphere);

const ambient = new THREE.AmbientLight('#ffffff', 0.35);
scene.add(ambient);

const directional = new THREE.DirectionalLight('#fff6e6', 2.4);
directional.position.set(4, 7, 5);
directional.castShadow = true;
directional.shadow.mapSize.set(2048, 2048);
directional.shadow.camera.left = -6;
directional.shadow.camera.right = 6;
directional.shadow.camera.top = 6;
directional.shadow.camera.bottom = -6;
directional.shadow.camera.near = 0.5;
directional.shadow.camera.far = 20;
directional.shadow.bias = -0.0005;
directional.shadow.normalBias = 0.02;
scene.add(directional);

const fill = new THREE.DirectionalLight('#dfe8e3', 0.5);
fill.position.set(-5, 3, -4);
scene.add(fill);

const ground = new THREE.Mesh(
  new THREE.PlaneGeometry(12, 12),
  new THREE.MeshStandardMaterial({ color: '#dcd8cd', roughness: 0.92, metalness: 0 })
);
ground.name = 'ground';
ground.rotation.x = -Math.PI / 2;
ground.position.y = 0;
ground.receiveShadow = true;
scene.add(ground);

const grid = new THREE.GridHelper(12, 24, '#b9b4a7', '#cdc8bb');
grid.position.y = 0.001;
grid.material.opacity = 0.32;
grid.material.transparent = true;
scene.add(grid);

const chairRoot = new THREE.Group();
chairRoot.name = 'chairRoot';
scene.add(chairRoot);

const upholstery = new THREE.MeshStandardMaterial({
  name: 'upholstery',
  color: COLORS.green,
  roughness: 0.82,
  metalness: 0,
});
upholstery.name = 'upholstery';

const legMaterial = new THREE.MeshStandardMaterial({
  name: 'legs',
  color: '#3d342c',
  roughness: 0.55,
  metalness: 0.05,
});

const seat = new THREE.Mesh(new THREE.BoxGeometry(2, 0.3, 1.8), upholstery);
seat.name = 'seat';
seat.position.set(0, 1, 0);
seat.castShadow = true;
seat.receiveShadow = true;
chairRoot.add(seat);

const back = new THREE.Mesh(new THREE.BoxGeometry(2, 1.8, 0.25), upholstery);
back.name = 'back';
back.position.set(0, 1.9, -0.775);
back.castShadow = true;
back.receiveShadow = true;
chairRoot.add(back);

for (const x of [-0.8, 0.8]) {
  for (const z of [-0.65, 0.65]) {
    const leg = new THREE.Mesh(new THREE.BoxGeometry(0.18, 1, 0.18), legMaterial);
    leg.name = `leg-${x < 0 ? 'l' : 'r'}-${z < 0 ? 'b' : 'f'}`;
    leg.position.set(x, 0.5, z);
    leg.castShadow = true;
    leg.receiveShadow = true;
    chairRoot.add(leg);
  }
}

const ui = {
  scroll: document.getElementById('scroll'),
  scrollValue: document.getElementById('scrollValue'),
  rotation: document.getElementById('rotation'),
  rotationValue: document.getElementById('rotationValue'),
  customizeBtn: document.getElementById('customizeBtn'),
  exitBtn: document.getElementById('exitBtn'),
  customizeControls: document.getElementById('customizeControls'),
  swatches: [...document.querySelectorAll('.swatch')],
  specSwatch: document.getElementById('specSwatch'),
  saveBtn: document.getElementById('saveBtn'),
  loadBtn: document.getElementById('loadBtn'),
  resetBtn: document.getElementById('resetBtn'),
  status: document.getElementById('status'),
};

let mode = 'browse';
let scroll = 0;
let colorId = 'green';
let rotation = 0;
let statusTimer = 0;

function lerp3(from, to, u) {
  return from.map((v, i) => v + (to[i] - v) * u);
}

function browseCameraPosition(p) {
  if (p <= 0.5) return lerp3(BROWSE_A, BROWSE_B, 2 * p);
  return lerp3(BROWSE_B, BROWSE_C, 2 * p - 1);
}

function finite(value) {
  return typeof value === 'number' && Number.isFinite(value);
}

function applyCamera(position, instant = false) {
  camera.position.set(...position);
  if (instant) {
    camera.up.set(0, 1, 0);
  }
  camera.lookAt(...TARGET);
  camera.updateMatrixWorld();
}

function updateCameraFromScroll() {
  applyCamera(browseCameraPosition(scroll), true);
}

function refreshScrollCamera() {
  if (mode === 'browse') updateCameraFromScroll();
  else controls.update();
}

function setStatus(text) {
  ui.status.textContent = text;
  ui.status.classList.add('visible');
  clearTimeout(statusTimer);
  statusTimer = setTimeout(() => ui.status.classList.remove('visible'), 1800);
}

function updateUpholsteryColor() {
  const hex = COLORS[colorId];
  upholstery.color.set(hex);
  ui.specSwatch.style.setProperty('--accent', hex);
  for (const button of ui.swatches) {
    button.setAttribute('aria-pressed', String(button.dataset.color === colorId));
  }
}

function updateRotationDisplay() {
  ui.rotation.value = String(rotation);
  ui.rotationValue.textContent = `${rotation}°`;
}

function updateScrollDisplay() {
  ui.scroll.value = String(scroll);
  ui.scrollValue.textContent = String(Math.round(scroll * 100)).padStart(2, '0');
}

function applyMode(nextMode) {
  mode = nextMode;
  const customizing = mode === 'customize';
  controls.enabled = customizing;
  ui.customizeBtn.hidden = customizing;
  ui.exitBtn.hidden = !customizing;
  ui.customizeControls.hidden = !customizing;
  ui.scroll.disabled = customizing;
  canvas.style.cursor = customizing ? 'grab' : 'default';
  if (customizing) {
    applyCamera(CUSTOMIZE_CAMERA, true);
    controls.target.set(...TARGET);
    controls.update();
  } else {
    controls.enabled = false;
    updateCameraFromScroll();
  }
}

function setScroll(p) {
  if (!finite(p)) return false;
  const clamped = Math.min(1, Math.max(0, p));
  scroll = clamped;
  updateScrollDisplay();
  if (mode === 'browse') updateCameraFromScroll();
  return true;
}

function setColor(id) {
  if (typeof id !== 'string' || !Object.prototype.hasOwnProperty.call(COLORS, id)) {
    return false;
  }
  colorId = id;
  updateUpholsteryColor();
  return true;
}

function setRotation(degrees) {
  if (!finite(degrees)) return false;
  const clamped = Math.min(45, Math.max(-45, degrees));
  rotation = clamped;
  chairRoot.rotation.y = THREE.MathUtils.degToRad(clamped);
  updateRotationDisplay();
  return true;
}

function enterCustomize() {
  applyMode('customize');
  return true;
}

function exitCustomize() {
  applyMode('browse');
  return true;
}

function stateSnapshot() {
  const target = mode === 'customize' ? controls.target : new THREE.Vector3(...TARGET);
  return {
    version: 1,
    mode,
    scroll,
    colorId,
    rotation,
    cameraPosition: [camera.position.x, camera.position.y, camera.position.z],
    target: [target.x, target.y, target.z],
    controlsEnabled: controls.enabled,
  };
}

const getState = () => stateSnapshot();

function storedPayload() {
  return { version: 1, mode, scroll, colorId, rotation };
}

function validateState(value) {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return false;
  const keys = Object.keys(value).sort();
  const expected = ['colorId', 'mode', 'rotation', 'scroll', 'version'];
  if (keys.length !== expected.length || keys.some((key, i) => key !== expected[i])) return false;
  if (value.version !== 1) return false;
  if (!MODES.includes(value.mode)) return false;
  if (!Object.prototype.hasOwnProperty.call(COLORS, value.colorId)) return false;
  if (!finite(value.scroll) || value.scroll < 0 || value.scroll > 1) return false;
  if (!finite(value.rotation) || value.rotation < -45 || value.rotation > 45) return false;
  return true;
}

function applyState(value) {
  scroll = value.scroll;
  colorId = value.colorId;
  rotation = value.rotation;
  chairRoot.rotation.y = THREE.MathUtils.degToRad(rotation);
  updateUpholsteryColor();
  updateRotationDisplay();
  updateScrollDisplay();
  applyMode(value.mode);
  // Re-apply exact camera placement for deterministic saved-camera semantics.
  if (mode === 'customize') {
    applyCamera(CUSTOMIZE_CAMERA, true);
    controls.target.set(...TARGET);
    controls.update();
  }
}

function save() {
  const json = JSON.stringify(storedPayload());
  try {
    localStorage.setItem(STORAGE_KEY, json);
  } catch {
    throw new Error('Unable to write to localStorage.');
  }
  setStatus('Saved');
  return json;
}

function load() {
  let raw;
  try {
    raw = localStorage.getItem(STORAGE_KEY);
  } catch {
    return false;
  }
  if (raw === null) return false;
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return false;
  }
  if (!validateState(parsed)) return false;
  applyState(parsed);
  setStatus('Loaded');
  return true;
}

function importState(text) {
  let parsed;
  if (typeof text !== 'string') return false;
  try {
    parsed = JSON.parse(text);
  } catch {
    return false;
  }
  if (!validateState(parsed)) return false;
  applyState(parsed);
  setStatus('Imported');
  return true;
}

function reset() {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // Storage can be unavailable in private contexts; scene reset still applies.
  }
  scroll = 0;
  colorId = 'green';
  rotation = 0;
  chairRoot.rotation.y = 0;
  updateUpholsteryColor();
  updateRotationDisplay();
  updateScrollDisplay();
  controls.enabled = false;
  controls.target.set(...TARGET);
  applyMode('browse');
  camera.position.set(...INITIAL_CAMERA);
  camera.lookAt(...TARGET);
  camera.updateMatrixWorld();
  setStatus('Reset');
  return true;
}

function resize() {
  const width = window.innerWidth;
  const height = window.innerHeight;
  renderer.setSize(width, height, false);
  camera.aspect = width / Math.max(height, 1);
  camera.updateProjectionMatrix();
}

window.addEventListener('resize', resize);
resize();

ui.scroll.addEventListener('input', (event) => setScroll(Number(event.target.value)));
ui.rotation.addEventListener('input', (event) => setRotation(Number(event.target.value)));
ui.customizeBtn.addEventListener('click', enterCustomize);
ui.exitBtn.addEventListener('click', exitCustomize);
for (const button of ui.swatches) {
  button.addEventListener('click', () => setColor(button.dataset.color));
}
ui.saveBtn.addEventListener('click', () => save());
ui.loadBtn.addEventListener('click', () => {
  if (!load()) setStatus('Nothing to load');
});
ui.resetBtn.addEventListener('click', reset);

controls.addEventListener('start', () => {
  if (mode === 'customize') canvas.style.cursor = 'grabbing';
});
controls.addEventListener('end', () => {
  if (mode === 'customize') canvas.style.cursor = 'grab';
});

updateUpholsteryColor();
updateRotationDisplay();
updateScrollDisplay();
applyMode('browse');

function animate() {
  if (mode === 'customize') controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
}

requestAnimationFrame(animate);

window.chairStudio = {
  scene,
  camera,
  renderer,
  controls,
  chairRoot,
  upholstery,
  getState,
  setScroll,
  setColor,
  setRotation,
  enterCustomize,
  exitCustomize,
  save,
  load,
  importState,
  reset,
};
