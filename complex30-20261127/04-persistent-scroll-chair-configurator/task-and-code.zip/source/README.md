# Scroll Chair Studio

A standalone Three.js chair configurator. Everything is rendered procedurally; there are no runtime network requests.

## Run

```sh
npm ci
npm run build
npm run preview
```

Then open http://localhost:4173/.

`npm run dev` starts Vite with hot reload. `npm test` runs the Playwright API/UI checks against a running server.

## API

`window.chairStudio` exposes the scene, camera, renderer, controls, chair root, upholstery material, and:

- `getState()`
- `setScroll(p)` — browse camera interpolation, `p` clamped to `[0, 1]`
- `setColor(id)` — `green`, `red`, or `violet`
- `setRotation(degrees)` — clamped to `[-45, 45]`
- `enterCustomize()` / `exitCustomize()`
- `save()` / `load()` / `importState(text)` / `reset()`

Saves use `localStorage` key `scroll-chair-studio-v1` and the exact schema `{version, mode, scroll, colorId, rotation}`.
