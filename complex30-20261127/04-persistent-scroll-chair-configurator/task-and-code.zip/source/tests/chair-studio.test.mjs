import { chromium } from 'playwright';
import assert from 'node:assert/strict';

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
const errors = [];
page.on('pageerror', (e) => errors.push(String(e)));
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
const requests = [];
page.on('request', (r) => requests.push(r.url()));
await page.goto('http://localhost:4173/');
await page.waitForFunction(() => window.chairStudio);

const ev = (fn, arg) => page.evaluate(fn, arg);
const nearly = (a, b, msg) => {
  assert.equal(a.length, b.length, msg);
  a.forEach((v, i) => assert.ok(Math.abs(v - b[i]) < 1e-5, `${msg}: ${a} vs ${b}`));
};

// Scene structure / materials
const structure = await ev(() => {
  const s = window.chairStudio;
  const seat = s.chairRoot.getObjectByName('seat');
  const back = s.chairRoot.getObjectByName('back');
  const legs = s.chairRoot.children.filter((o) => o.name.startsWith('leg-'));
  return {
    seatGeo: seat.geometry.parameters,
    seatPos: seat.position.toArray(),
    backGeo: back.geometry.parameters,
    backPos: back.position.toArray(),
    legs: legs.map((l) => ({ p: l.position.toArray(), g: l.geometry.parameters })),
    shared: seat.material === back.material && seat.material === s.upholstery && s.upholstery.name === 'upholstery',
    legSeparate: legs.every((l) => l.material !== s.upholstery),
    ground: s.scene.getObjectByName('ground').geometry.parameters,
    fov: s.camera.fov, near: s.camera.near, far: s.camera.far,
  };
});
assert.deepEqual(structure.seatGeo.width, 2);
assert.equal(structure.seatGeo.height, 0.3);
assert.equal(structure.seatGeo.depth, 1.8);
assert.deepEqual(structure.seatPos, [0, 1, 0]);
assert.equal(structure.backGeo.height, 1.8);
assert.equal(structure.backGeo.depth, 0.25);
nearly(structure.backPos, [0, 1.9, -0.775], 'back');
assert.equal(structure.legs.length, 4);
for (const leg of structure.legs) assert.deepEqual([leg.g.width, leg.g.height, leg.g.depth], [0.18, 1, 0.18]);
assert.ok(structure.shared && structure.legSeparate);
assert.deepEqual([structure.ground.width, structure.ground.height], [12, 12]);
assert.deepEqual([structure.fov, structure.near, structure.far], [45, 0.1, 100]);

// Initial state
let st = await ev(() => window.chairStudio.getState());
assert.deepEqual(st, { version: 1, mode: 'browse', scroll: 0, colorId: 'green', rotation: 0, cameraPosition: [0, 2, 6], target: [0, 1, 0], controlsEnabled: false });

// Browse interpolation
const cases = [[0, [0, 2, 6]], [0.25, [0, 1.75, 4.625]], [0.5, [0, 1.5, 3.25]], [0.75, [-1.5, 1.5, 1.625]], [1, [-3, 1.5, 0]]];
for (const [p, expected] of cases) {
  assert.equal(await ev((p) => window.chairStudio.setScroll(p), p), true);
  st = await ev(() => window.chairStudio.getState());
  nearly(st.cameraPosition, expected, `scroll ${p}`);
  assert.equal(st.scroll, p);
}
assert.equal(await ev(() => window.chairStudio.setScroll(NaN)), false);
assert.equal(await ev(() => window.chairStudio.setScroll(Infinity)), false);
assert.equal((await ev(() => window.chairStudio.getState())).scroll, 1);
assert.equal(await ev(() => window.chairStudio.setScroll(-2)), true);
assert.equal((await ev(() => window.chairStudio.getState())).scroll, 0);
assert.equal(await ev(() => window.chairStudio.setScroll(9)), true);
assert.equal((await ev(() => window.chairStudio.getState())).scroll, 1);

// Rotation / colors
assert.equal(await ev(() => window.chairStudio.setRotation(30)), true);
st = await ev(() => window.chairStudio.getState());
assert.equal(st.rotation, 30);
nearly([await ev(() => window.chairStudio.chairRoot.rotation.y)], [Math.PI / 6], 'rotation rad');
assert.equal(await ev(() => window.chairStudio.setRotation(90)), true);
assert.equal((await ev(() => window.chairStudio.getState())).rotation, 45);
assert.equal(await ev(() => window.chairStudio.setRotation(NaN)), false);
assert.equal((await ev(() => window.chairStudio.getState())).rotation, 45);
assert.equal(await ev(() => window.chairStudio.setColor('red')), true);
assert.equal(await ev(() => '#' + window.chairStudio.upholstery.color.getHexString()), '#a57d7d');
assert.equal(await ev(() => window.chairStudio.setColor('blue')), false);
assert.equal((await ev(() => window.chairStudio.getState())).colorId, 'red');
assert.equal(await ev(() => window.chairStudio.setColor('violet')), true);
assert.equal(await ev(() => window.chairStudio.setColor('green')), true);

// Customize mode
await ev(() => { window.chairStudio.setScroll(0.4); window.chairStudio.enterCustomize(); });
st = await ev(() => window.chairStudio.getState());
assert.equal(st.mode, 'customize');
assert.equal(st.controlsEnabled, true);
nearly(st.cameraPosition, [-1.95, 2.54, 2.29], 'custom camera');
assert.equal(await ev(() => window.chairStudio.controls.enabled), true);
await ev(() => { window.chairStudio.controls.target.set(0.2, 1, 0); });
await ev(() => window.chairStudio.exitCustomize());
st = await ev(() => window.chairStudio.getState());
assert.equal(st.mode, 'browse');
assert.equal(st.controlsEnabled, false);
nearly(st.cameraPosition, [0, 1.6, 3.8], 'retained scroll camera');
nearly(st.target, [0, 1, 0], 'browse target');

// Save / load
const saved = await ev(() => window.chairStudio.save());
assert.deepEqual(Object.keys(JSON.parse(saved)), ['version', 'mode', 'scroll', 'colorId', 'rotation']);
assert.equal(await ev(() => localStorage.getItem('scroll-chair-studio-v1')), saved);
assert.equal(await ev(() => window.chairStudio.reset()), true);
assert.equal(await ev(() => localStorage.getItem('scroll-chair-studio-v1')), null);
assert.deepEqual(await ev(() => window.chairStudio.getState()), { version: 1, mode: 'browse', scroll: 0, colorId: 'green', rotation: 0, cameraPosition: [0, 2, 6], target: [0, 1, 0], controlsEnabled: false });
assert.equal(await ev(() => window.chairStudio.load()), false);
assert.equal(await ev((s) => { localStorage.setItem('scroll-chair-studio-v1', s); return window.chairStudio.load(); }, saved), true);
st = await ev(() => window.chairStudio.getState());
assert.equal(st.mode, 'browse');
assert.equal(st.scroll, 0.4);
assert.equal(st.rotation, 45);

// Import validation and atomicity
const good = JSON.stringify({ version: 1, mode: 'customize', scroll: 0.5, colorId: 'violet', rotation: -12 });
assert.equal(await ev((t) => window.chairStudio.importState(t), good), true);
st = await ev(() => window.chairStudio.getState());
assert.equal(st.mode, 'customize');
assert.equal(st.controlsEnabled, true);
nearly(st.cameraPosition, [-1.95, 2.54, 2.29], 'import customize camera');
assert.equal(st.colorId, 'violet');
assert.equal(st.rotation, -12);

const before = await ev(() => window.chairStudio.getState());
const bad = [
  '{', 'null', '[]', '{}',
  JSON.stringify({ version: 2, mode: 'browse', scroll: 0, colorId: 'green', rotation: 0 }),
  JSON.stringify({ version: 1, mode: 'browse', scroll: -0.1, colorId: 'green', rotation: 0 }),
  JSON.stringify({ version: 1, mode: 'browse', scroll: 0, colorId: 'green', rotation: 46 }),
  JSON.stringify({ version: 1, mode: 'browse', scroll: 0, colorId: 'green', rotation: -46 }),
  JSON.stringify({ version: 1, mode: 'spin', scroll: 0, colorId: 'green', rotation: 0 }),
  JSON.stringify({ version: 1, mode: 'browse', scroll: 0, colorId: 'blue', rotation: 0 }),
  JSON.stringify({ version: 1, mode: 'browse', scroll: '0', colorId: 'green', rotation: 0 }),
  JSON.stringify({ version: 1, mode: 'browse', scroll: 0, colorId: 'green', rotation: null }),
  JSON.stringify({ version: 1, mode: 'browse', scroll: 0, colorId: 'green' }),
];
for (const text of bad) {
  assert.equal(await ev((t) => window.chairStudio.importState(t), text), false, text);
  assert.deepEqual(await ev(() => window.chairStudio.getState()), before);
}
assert.equal(await ev(() => window.chairStudio.importState('{"version":1,"mode":"browse","scroll":0,"colorId":"green","rotation":0,"cameraPosition":[0,0,0],"target":[0,0,0],"controlsEnabled":false}')), false);
assert.equal(await ev(() => window.chairStudio.importState('{"version":1,"mode":"browse","scroll":0,"colorId":"green","rotation":0}')), true);

// UI wiring
assert.equal(await ev(() => {
  const input = document.querySelector('#scroll');
  input.value = '0.25'; input.dispatchEvent(new Event('input'));
  return window.chairStudio.getState().scroll;
}), 0.25);
assert.equal(await ev(() => Number(document.querySelector('#scroll').value)), 0.25);
await ev(() => document.querySelector('[data-color="red"]').click());
assert.equal((await ev(() => window.chairStudio.getState())).colorId, 'red');
await ev(() => document.querySelector('#resetBtn').click());
assert.equal((await ev(() => window.chairStudio.getState())).mode, 'browse');

assert.equal(errors.length, 0, errors.join('\n'));
assert.ok(requests.every((u) => u.startsWith('http://localhost:4173')), requests.join('\n'));
assert.ok(!requests.some((u) => /fonts\.googleapis|unpkg|jsdelivr|cdn/i.test(u)), requests.join('\n'));

await page.screenshot({ path: 'tests/screenshot.png' });
console.log('All checks passed. Requests:', requests.length);
await browser.close();
