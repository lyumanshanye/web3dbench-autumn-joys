import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import './style.css';

const POD_IDS = ['alpha', 'beta', 'gamma'];
const POD_COLORS = { alpha: 0xe56d55, beta: 0x4fa7b5, gamma: 0xd0a343 };
const INITIAL_POSITIONS = {
  alpha: new THREE.Vector3(-4, 0.5, 0),
  beta: new THREE.Vector3(0, 0.5, 0),
  gamma: new THREE.Vector3(4, 0.5, 0),
};
const LIMITS = { x: [-6, 6], y: [0, 4], z: [-4, 4] };
const CAMERA_START = new THREE.Vector3(12, 10, 16);
const TARGET_START = new THREE.Vector3(0, 0, 0);
const DOCK_POSITION = new THREE.Vector3(0, 2, -3);
const DOCK_ROTATION = new THREE.Euler(0, Math.PI / 2, 0);
const TOLERANCE = 1e-6;

const canvas = document.querySelector('#scene');
const selectedReadout = document.querySelector('#selected-id');
const timeReadout = document.querySelector('#time-readout');
const timeSlider = document.querySelector('#time-slider');
const focusButton = document.querySelector('#focus-button');
const playButton = document.querySelector('#play-button');
const dockButton = document.querySelector('#dock-button');
const undockButton = document.querySelector('#undock-button');
const resetButton = document.querySelector('#reset-button');

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0d1518);
scene.fog = new THREE.Fog(0x0d1518, 34, 65);

const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 1000);
camera.position.copy(CAMERA_START);

const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.1;

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = false;
controls.target.copy(TARGET_START);
controls.update();

scene.add(new THREE.AmbientLight(0xbfd8d2, 1.15));
const keyLight = new THREE.DirectionalLight(0xffe4bd, 2.5);
keyLight.position.set(-8, 15, 8);
keyLight.castShadow = true;
keyLight.shadow.mapSize.set(2048, 2048);
keyLight.shadow.camera.left = -16;
keyLight.shadow.camera.right = 16;
keyLight.shadow.camera.top = 16;
keyLight.shadow.camera.bottom = -16;
keyLight.shadow.camera.near = 1;
keyLight.shadow.camera.far = 45;
keyLight.shadow.bias = -0.0005;
scene.add(keyLight);
const rimLight = new THREE.DirectionalLight(0x6b9fd0, 0.85);
rimLight.position.set(10, 6, -12);
scene.add(rimLight);

const grid = new THREE.GridHelper(20, 20, 0x769189, 0x304541);
grid.position.y = -0.002;
grid.material.transparent = true;
grid.material.opacity = 0.72;
scene.add(grid);

const ground = new THREE.Mesh(
  new THREE.PlaneGeometry(20, 20),
  new THREE.MeshStandardMaterial({ color: 0x142126, roughness: 0.94, metalness: 0.05 })
);
ground.rotation.x = -Math.PI / 2;
ground.position.y = -0.01;
ground.receiveShadow = true;
scene.add(ground);

const dock = new THREE.Group();
dock.name = 'dock';
dock.position.copy(DOCK_POSITION);
dock.rotation.copy(DOCK_ROTATION);
scene.add(dock);

const dockPlatform = new THREE.Mesh(
  new THREE.CylinderGeometry(1.95, 2.15, 0.22, 8),
  new THREE.MeshStandardMaterial({ color: 0x2a4144, roughness: 0.8, metalness: 0.25 })
);
dockPlatform.position.y = -0.11;
dockPlatform.receiveShadow = true;
dockPlatform.castShadow = true;
dock.add(dockPlatform);

const dockRing = new THREE.Mesh(
  new THREE.TorusGeometry(1.6, 0.035, 8, 64),
  new THREE.MeshBasicMaterial({ color: 0xe8ad61 })
);
dockRing.rotation.x = Math.PI / 2;
dockRing.position.y = 0.015;
dock.add(dockRing);

const dockMarker = new THREE.Mesh(
  new THREE.BoxGeometry(0.7, 0.03, 0.07),
  new THREE.MeshBasicMaterial({ color: 0xf0c88e })
);
dockMarker.position.set(0, 0.04, -1.62);
dock.add(dockMarker);

const pods = {};
const boxMeshes = [];

for (const id of POD_IDS) {
  const pod = new THREE.Group();
  pod.name = id;
  pod.userData.podId = id;
  pod.position.copy(INITIAL_POSITIONS[id]);
  scene.add(pod);

  const box = new THREE.Mesh(
    new THREE.BoxGeometry(2, 1, 1),
    new THREE.MeshStandardMaterial({ color: POD_COLORS[id], roughness: 0.46, metalness: 0.18 })
  );
  box.name = `${id}-hull`;
  box.userData.podId = id;
  box.castShadow = true;
  box.receiveShadow = true;
  pod.add(box);

  const boxEdge = new THREE.LineSegments(
    new THREE.EdgesGeometry(box.geometry),
    new THREE.LineBasicMaterial({ color: 0xf5e3ce, transparent: true, opacity: 0.25 })
  );
  box.add(boxEdge);

  const mast = new THREE.Mesh(
    new THREE.CylinderGeometry(0.15, 0.15, 1, 16),
    new THREE.MeshStandardMaterial({ color: 0xcbd9d3, roughness: 0.35, metalness: 0.65 })
  );
  mast.name = `${id}-mast`;
  mast.userData.podId = id;
  mast.position.set(0, 1, 0);
  mast.castShadow = true;
  pod.add(mast);

  const beacon = new THREE.Mesh(
    new THREE.SphereGeometry(0.1, 12, 8),
    new THREE.MeshBasicMaterial({ color: 0xf1c384 })
  );
  beacon.position.set(0, 0.5, 0);
  beacon.userData.podId = id;
  mast.add(beacon);

  pod.userData.box = box;
  pod.userData.mast = mast;
  pods[id] = pod;
  boxMeshes.push(box, mast);
}

const selectionRing = new THREE.Mesh(
  new THREE.TorusGeometry(1.38, 0.018, 6, 64),
  new THREE.MeshBasicMaterial({ color: 0xf3ca91, transparent: true, opacity: 0.8, depthTest: false })
);
selectionRing.rotation.x = Math.PI / 2;
selectionRing.renderOrder = 4;
selectionRing.visible = false;
scene.add(selectionRing);

const gizmo = new THREE.Group();
gizmo.name = 'translation-gizmo';
gizmo.visible = false;
scene.add(gizmo);

const AXIS_COLORS = { x: 0xef6b64, y: 0x7bd58e, z: 0x69a6f5 };
const AXIS_VECTORS = { x: new THREE.Vector3(1, 0, 0), y: new THREE.Vector3(0, 1, 0), z: new THREE.Vector3(0, 0, 1) };
const gizmoAxes = {};

for (const axis of ['x', 'y', 'z']) {
  const axisGroup = new THREE.Group();
  const material = new THREE.MeshBasicMaterial({ color: AXIS_COLORS[axis], depthTest: false });
  const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.028, 0.028, 1.1, 10), material);
  shaft.position.y = 0.55;
  shaft.renderOrder = 6;
  const tip = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.28, 14), material);
  tip.position.y = 1.24;
  tip.renderOrder = 6;
  const hitTarget = new THREE.Mesh(
    new THREE.CylinderGeometry(0.18, 0.18, 1.55, 8),
    new THREE.MeshBasicMaterial({ visible: false })
  );
  hitTarget.position.y = 0.77;
  hitTarget.userData.gizmoAxis = axis;
  axisGroup.add(shaft, tip, hitTarget);
  if (axis === 'x') axisGroup.rotation.z = -Math.PI / 2;
  if (axis === 'z') axisGroup.rotation.x = Math.PI / 2;
  gizmo.add(axisGroup);
  gizmoAxes[axis] = { group: axisGroup, hitTarget, shaft, tip };
}

let selectedId = null;
let time = 0;
let playing = false;
let lastFrameTime = null;
let dragState = null;

const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();

function getPod(id) {
  return typeof id === 'string' && Object.hasOwn(pods, id) ? pods[id] : null;
}

function isValidAxis(axis) {
  return axis === 'x' || axis === 'y' || axis === 'z';
}

function isUsableDelta(delta) {
  return typeof delta === 'number' && Number.isFinite(delta);
}

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

function updateGizmoPosition() {
  const pod = getPod(selectedId);
  if (!pod) {
    gizmo.visible = false;
    selectionRing.visible = false;
    return;
  }
  scene.updateMatrixWorld(true);
  pod.getWorldPosition(gizmo.position);
  selectionRing.position.copy(gizmo.position);
  selectionRing.position.y += 0.01;
  gizmo.visible = true;
  selectionRing.visible = true;
}

function setSelected(id) {
  const pod = getPod(id);
  if (!pod) return false;
  selectedId = id;
  selectedReadout.textContent = id;
  updateGizmoPosition();
  return true;
}

function selectPod(id) {
  return setSelected(id);
}

function dragPod(id, axis, delta) {
  const pod = getPod(id);
  if (!pod || !isValidAxis(axis) || !isUsableDelta(delta)) return false;
  const [min, max] = LIMITS[axis];
  pod.position[axis] = clamp(pod.position[axis] + delta, min, max);
  pod.updateMatrixWorld(true);
  updateGizmoPosition();
  return true;
}

function applyDockPose() {
  dock.rotation.y = Math.PI / 2 + (Math.PI / 2) * (time / 4);
  const mastScaleY = 1 + 0.5 * Math.sin((Math.PI * time) / 4);
  for (const id of POD_IDS) {
    const mast = pods[id].userData.mast;
    mast.scale.set(1, mastScaleY, 1);
  }
  dock.updateMatrixWorld(true);
  updateGizmoPosition();
}

function updateReadouts() {
  timeReadout.textContent = `${time.toFixed(2)} s`;
  timeSlider.value = String(time);
  playButton.textContent = playing ? 'Pause' : 'Play';
}

function seek(t) {
  if (typeof t !== 'number' || !Number.isFinite(t)) return false;
  time = clamp(t, 0, 4);
  applyDockPose();
  updateReadouts();
  return true;
}

function focusSelected() {
  const pod = getPod(selectedId);
  if (!pod) return false;
  const p = new THREE.Vector3();
  pod.getWorldPosition(p);
  controls.target.copy(p);
  camera.position.copy(p).add(new THREE.Vector3(6, 4, 6));
  controls.update();
  updateGizmoPosition();
  return true;
}

function dockPod(id) {
  const pod = getPod(id);
  if (!pod) return false;
  scene.updateMatrixWorld(true);
  dock.attach(pod);
  dock.updateMatrixWorld(true);
  updateGizmoPosition();
  return true;
}

function undockPod(id) {
  const pod = getPod(id);
  if (!pod) return false;
  scene.updateMatrixWorld(true);
  scene.attach(pod);
  pod.updateMatrixWorld(true);
  updateGizmoPosition();
  return true;
}

function setPlaying(value) {
  playing = Boolean(value);
  lastFrameTime = null;
  updateReadouts();
}

function reset() {
  setPlaying(false);
  for (const id of POD_IDS) {
    const pod = pods[id];
    if (pod.parent !== scene) scene.attach(pod);
    pod.position.copy(INITIAL_POSITIONS[id]);
    pod.rotation.set(0, 0, 0);
    pod.scale.set(1, 1, 1);
    pod.userData.mast.scale.set(1, 1, 1);
  }
  dock.position.copy(DOCK_POSITION);
  dock.rotation.copy(DOCK_ROTATION);
  dock.scale.set(1, 1, 1);
  time = 0;
  camera.position.copy(CAMERA_START);
  controls.target.copy(TARGET_START);
  controls.update();
  setSelected('alpha');
  applyDockPose();
  updateReadouts();
  scene.updateMatrixWorld(true);
  updateGizmoPosition();
}

function setPointerFromEvent(event) {
  const rect = renderer.domElement.getBoundingClientRect();
  pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
  raycaster.setFromCamera(pointer, camera);
}

function closestAxisHit(event) {
  setPointerFromEvent(event);
  const hits = raycaster.intersectObjects(Object.values(gizmoAxes).map((entry) => entry.hitTarget), false);
  return hits.length ? hits[0].object.userData.gizmoAxis : null;
}

function axisDeltaFromPointer(event, axis) {
  const worldAxis = AXIS_VECTORS[axis].clone().applyQuaternion(gizmo.quaternion).normalize();
  const toCamera = new THREE.Vector3().subVectors(camera.position, gizmo.position).normalize();
  const planeNormal = new THREE.Vector3().crossVectors(worldAxis, toCamera);
  if (planeNormal.lengthSq() < 1e-10) planeNormal.set(0, 1, 0);
  planeNormal.crossVectors(worldAxis, planeNormal).normalize();
  const plane = new THREE.Plane().setFromNormalAndCoplanarPoint(planeNormal, gizmo.position);
  const point = new THREE.Vector3();
  if (!raycaster.ray.intersectPlane(plane, point)) return 0;
  const axisOrigin = new THREE.Vector3();
  gizmo.getWorldPosition(axisOrigin);
  return new THREE.Vector3().subVectors(point, axisOrigin).dot(worldAxis);
}

function podFromHit(object) {
  let node = object;
  while (node) {
    if (node.userData && Object.hasOwn(pods, node.userData.podId)) return node.userData.podId;
    node = node.parent;
  }
  return null;
}

function onPointerDown(event) {
  if (event.button !== 0) return;
  setPointerFromEvent(event);
  const gizmoHits = raycaster.intersectObjects(Object.values(gizmoAxes).map((entry) => entry.hitTarget), false);
  if (gizmoHits.length) {
    const axis = gizmoHits[0].object.userData.gizmoAxis;
    dragState = {
      pointerId: event.pointerId,
      axis,
      podId: selectedId,
      startAxisValue: pods[selectedId].position[axis],
      startPointerAxis: axisDeltaFromPointer(event, axis),
    };
    controls.enabled = false;
    renderer.domElement.setPointerCapture?.(event.pointerId);
    renderer.domElement.style.cursor = 'grabbing';
    event.preventDefault();
    return;
  }

  const podHits = raycaster.intersectObjects(boxMeshes, false);
  if (podHits.length) {
    const id = podFromHit(podHits[0].object);
    if (id) setSelected(id);
  }
}

function onPointerMove(event) {
  if (dragState && event.pointerId === dragState.pointerId) {
    setPointerFromEvent(event);
    const pointerAxis = axisDeltaFromPointer(event, dragState.axis);
    const delta = pointerAxis - dragState.startPointerAxis;
    const pod = pods[dragState.podId];
    const [min, max] = LIMITS[dragState.axis];
    pod.position[dragState.axis] = clamp(dragState.startAxisValue + delta, min, max);
    pod.updateMatrixWorld(true);
    updateGizmoPosition();
    return;
  }
  if (event.buttons === 0 && event.pointerType === 'mouse') {
    const axis = closestAxisHit(event);
    renderer.domElement.style.cursor = axis ? 'grab' : 'crosshair';
  }
}

function endDrag(event) {
  if (!dragState || event.pointerId !== dragState.pointerId) return;
  renderer.domElement.releasePointerCapture?.(event.pointerId);
  dragState = null;
  controls.enabled = true;
  renderer.domElement.style.cursor = 'crosshair';
}

function resize() {
  const width = window.innerWidth;
  const height = window.innerHeight;
  renderer.setSize(width, height, false);
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
}

function animate(now) {
  requestAnimationFrame(animate);
  if (playing) {
    if (lastFrameTime !== null) {
      const next = time + (now - lastFrameTime) / 1000;
      if (next >= 4) {
        seek(4);
        setPlaying(false);
      } else {
        seek(next);
      }
    }
    lastFrameTime = now;
  }
  updateGizmoPosition();
  renderer.render(scene, camera);
}

focusButton.addEventListener('click', focusSelected);
playButton.addEventListener('click', () => setPlaying(!playing));
dockButton.addEventListener('click', () => dockPod(selectedId));
undockButton.addEventListener('click', () => undockPod(selectedId));
resetButton.addEventListener('click', reset);
timeSlider.addEventListener('input', () => {
  setPlaying(false);
  seek(Number(timeSlider.value));
});
renderer.domElement.addEventListener('pointerdown', onPointerDown);
renderer.domElement.addEventListener('pointermove', onPointerMove);
renderer.domElement.addEventListener('pointerup', endDrag);
renderer.domElement.addEventListener('pointercancel', endDrag);
window.addEventListener('resize', resize);

window.relayLab = {
  scene,
  camera,
  renderer,
  controls,
  pods,
  dock,
  get selectedId() { return selectedId; },
  get time() { return time; },
  selectPod,
  dragPod,
  dockPod,
  undockPod,
  focusSelected,
  seek,
  reset,
};

resize();
setSelected('alpha');
seek(0);
requestAnimationFrame(animate);
