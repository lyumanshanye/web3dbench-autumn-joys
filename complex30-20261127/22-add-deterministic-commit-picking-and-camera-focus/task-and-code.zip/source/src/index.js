import React from "react";
import ReactDOM from "react-dom";

import "./globals";
import * as serviceWorker from "./serviceWorker";

import App from "components/App";
import { isFixturePicking } from "utils/fixture";
import "styles/index.scss";

const loadNetworkOnlyPageResources = () => {
  if (isFixturePicking) {
    return;
  }

  const fontLink = document.createElement("link");
  fontLink.rel = "stylesheet";
  fontLink.href =
    "https://fonts.googleapis.com/css2?family=PT+Mono&display=swap";
  document.head.appendChild(fontLink);

  const analyticsScript = document.createElement("script");
  analyticsScript.async = true;
  analyticsScript.src =
    "https://www.googletagmanager.com/gtag/js?id=UA-98277236-3";
  document.head.appendChild(analyticsScript);

  window.dataLayer = window.dataLayer || [];
  window.gtag = function gtag() {
    window.dataLayer.push(arguments);
  };
  window.gtag("js", new Date());
  window.gtag("config", "UA-98277236-3");
};

loadNetworkOnlyPageResources();

ReactDOM.render(<App />, document.getElementById("root"));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
