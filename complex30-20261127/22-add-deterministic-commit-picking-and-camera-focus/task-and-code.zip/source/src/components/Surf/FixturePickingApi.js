import { useEffect, useRef } from "react";
import { useThree } from "react-three-fiber";
import { Vector3 } from "three";

const getCameraTarget = camera => {
  const target = camera.userData.target;

  if (target && target.isVector3) {
    return target.toArray();
  }

  const direction = new Vector3();
  camera.getWorldDirection(direction);

  return camera.position
    .clone()
    .add(direction)
    .toArray();
};

const FixturePickingApi = ({ commits, selectedSha, onReset }) => {
  const { camera } = useThree();
  const stateRef = useRef({ commits, selectedSha, onReset });
  const apiRef = useRef();

  stateRef.current = { commits, selectedSha, onReset };

  if (!apiRef.current) {
    apiRef.current = {
      getState: () => {
        const state = stateRef.current;

        return {
          selectedSha: state.selectedSha,
          commits: state.commits.map(commit => ({
            sha: commit.sha,
            message: commit.commit.message,
            index: commit.index,
            position: commit.position.toArray()
          })),
          camera: {
            position: camera.position.toArray(),
            target: getCameraTarget(camera),
            up: camera.up.toArray()
          }
        };
      },
      projectCommit: sha => {
        const commit = stateRef.current.commits.find(item => item.sha === sha);

        if (!commit) {
          return null;
        }

        camera.updateMatrixWorld();

        const projected = commit.position.clone().project(camera);
        const visible =
          projected.x >= -1 &&
          projected.x <= 1 &&
          projected.y >= -1 &&
          projected.y <= 1 &&
          projected.z >= -1 &&
          projected.z <= 1;

        return {
          x: projected.x,
          y: projected.y,
          visible
        };
      },
      reset: () => stateRef.current.onReset()
    };
  }

  useEffect(() => {
    window.__repoSurfPicking = apiRef.current;

    return () => {
      if (window.__repoSurfPicking === apiRef.current) {
        delete window.__repoSurfPicking;
      }
    };
  }, []);

  return null;
};

export default FixturePickingApi;
