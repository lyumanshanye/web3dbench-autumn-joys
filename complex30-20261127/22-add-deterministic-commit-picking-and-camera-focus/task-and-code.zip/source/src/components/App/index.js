import React, { useState, useCallback, useEffect } from "react";
import { Canvas } from "react-three-fiber";
import * as THREE from "three";

import BlinkingBadge from "components/BlinkingBadge";
import Effects from "components/Effects";
import LoadingScreen from "components/LoadingScreen";
import Stats from "components/Stats";
import Surf from "components/Surf";
import useRepo from "hooks/useRepo";
import { DatGui, useConfig } from "utils/config";
import { isFixturePicking } from "utils/fixture";
import loadingManager, { useLoadingState } from "utils/loadingManager";
import { isDevelopment } from "utils/isEnvironment";
import { clearPickingCursor } from "utils/pickingCursor";

import "./style.scss";

const backgroundColor = new THREE.Color("#0C0E16");

const App = () => {
  const [isCanvasReady, setIsCanvasReady] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [selectedSha, setSelectedSha] = useState(null);
  const { owner, repo, commits } = useRepo();
  const { progress } = useLoadingState();
  const selectedCommit = commits.find(commit => commit.sha === selectedSha);

  const handleCanvasCreate = useCallback(
    ({ gl }) => {
      gl.gammaInput = true;
      gl.setClearColor(backgroundColor);
      setIsCanvasReady(true);
    },
    [setIsCanvasReady]
  );

  useEffect(() => {
    if (!isFixturePicking) {
      loadingManager.load();
    }
  }, []);

  useEffect(() => {
    if (isFixturePicking) {
      return;
    }

    if (!isLoaded && progress === 1) {
      setTimeout(() => {
        setIsLoaded(true);
      }, 1000);
    }
  }, [isLoaded, progress]);

  const clearSelection = useCallback(() => {
    setSelectedSha(null);
    clearPickingCursor();
  }, []);

  useEffect(() => {
    const handleKeyDown = event => {
      if (event.key === "Escape") {
        clearSelection();
      }
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [clearSelection]);

  const handleSelectCommit = useCallback(sha => {
    setSelectedSha(sha);
  }, []);

  const cameraSettings = useConfig(c => ({
    near: c.camera.near,
    far: c.camera.far,
    fov: c.camera.fov,
    position: [0, 0, -0.1]
  }));

  return (
    <>
      {(isFixturePicking || (isLoaded && progress === 1)) && (
        <Canvas
          camera={cameraSettings}
          onCreated={handleCanvasCreate}
          onPointerMissed={clearSelection}
          pixelRatio={window.devicePixelRatio}
          updateDefaultCamera
        >
          <fog attach="fog" args={[backgroundColor, 50, 250]} />
          <ambientLight intensity={0.25} />

          <Surf
            owner={owner}
            repo={repo}
            commits={commits}
            isSceneReady={isCanvasReady}
            selectedSha={selectedSha}
            onSelectCommit={handleSelectCommit}
            onClearSelection={clearSelection}
          />

          <Effects />

          {isDevelopment && <Stats />}
        </Canvas>
      )}

      {!isFixturePicking && (
        <LoadingScreen loaded={isCanvasReady} progress={progress} />
      )}

      {selectedCommit && (
        <div className="CommitInspector" data-testid="commit-inspector">
          <div data-testid="inspector-sha">{selectedCommit.sha}</div>
          <div data-testid="inspector-message">
            {selectedCommit.commit.message}
          </div>
          <div data-testid="inspector-index">{selectedCommit.index}</div>
        </div>
      )}

      {isDevelopment && <DatGui />}

      <BlinkingBadge>Preview</BlinkingBadge>
    </>
  );
};

export default App;
