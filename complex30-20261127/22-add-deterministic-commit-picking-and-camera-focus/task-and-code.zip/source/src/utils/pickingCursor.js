let hoveredSha = null;
let hoveredCanvas = null;
let previousCursor = "";

const getCanvas = event => {
  const sourceEvent = event && event.sourceEvent;
  const target = sourceEvent && sourceEvent.target;
  const currentTarget = sourceEvent && sourceEvent.currentTarget;

  if (target && target.tagName === "CANVAS") {
    return target;
  }

  if (currentTarget && currentTarget.tagName === "CANVAS") {
    return currentTarget;
  }

  return currentTarget && currentTarget.querySelector
    ? currentTarget.querySelector("canvas")
    : null;
};

export const hoverPickingTarget = (event, sha) => {
  const canvas = getCanvas(event);

  if (!canvas) {
    return;
  }

  if (hoveredSha === null) {
    hoveredCanvas = canvas;
    previousCursor = canvas.style.cursor;
  }

  hoveredSha = sha;
  canvas.style.cursor = "pointer";
};

export const leavePickingTarget = sha => {
  if (hoveredSha !== sha) {
    return;
  }

  clearPickingCursor();
};

export const clearPickingCursor = () => {
  if (hoveredCanvas) {
    hoveredCanvas.style.cursor = previousCursor;
  }

  hoveredSha = null;
  hoveredCanvas = null;
  previousCursor = "";
};
