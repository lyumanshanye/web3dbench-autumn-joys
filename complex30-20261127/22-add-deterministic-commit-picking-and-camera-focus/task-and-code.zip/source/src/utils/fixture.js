export const FIXTURE_PICKING_QUERY = "?fixture=picking";

export const isFixturePicking =
  typeof window !== "undefined" &&
  window.location.search === FIXTURE_PICKING_QUERY;

const FIXTURE_COMMIT_LETTERS = ["a", "b", "c", "d", "e"];

export const createFixtureCommits = () => {
  const shas = FIXTURE_COMMIT_LETTERS.map(letter => letter.repeat(40));

  return shas.map((sha, index) => ({
    sha,
    index,
    parents: index < shas.length - 1 ? [shas[index + 1]] : [],
    commit: {
      message: `commit ${FIXTURE_COMMIT_LETTERS[index].toUpperCase()}`
    }
  }));
};
