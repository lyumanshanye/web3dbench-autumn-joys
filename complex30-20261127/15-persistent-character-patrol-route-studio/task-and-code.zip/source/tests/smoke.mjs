import { chromium as playwrightChromium } from 'playwright';
import chromium from '@sparticuz/chromium';

const baseUrl = process.env.PATROL_URL || 'http://127.0.0.1:4173/';
const browser = await playwrightChromium.launch({
  executablePath: await chromium.executablePath(),
  args: chromium.args,
  headless: true,
});
const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
const browserErrors = [];
page.on('pageerror', (error) => browserErrors.push(error.message));
page.on('console', (message) => {
  if (message.type() === 'error') browserErrors.push(message.text());
});

let failures = 0;
function check(label, condition, errorDetail) {
  console.log(`${condition ? 'PASS' : 'FAIL'}  ${label}${condition ? '' : ` :: ${JSON.stringify(errorDetail ?? '')}`}`);
  if (!condition) failures += 1;
}

await page.goto(baseUrl);
await page.waitForFunction(() => window.patrolStudio);
const result = await page.evaluate(() => {
  const api = window.patrolStudio;
  const snapshot = () => JSON.stringify(api.getState());
  const out = {};
  const close = (a, b) => Math.abs(a - b) < 1e-5;

  out.apiKeys = [
    'scene', 'camera', 'renderer', 'controls', 'character', 'routeLine',
    'leftLeg', 'rightLeg', 'getState', 'setPlaying', 'setMode', 'step',
    'setWaypoint', 'save', 'load', 'importState', 'reset',
  ].every((key) => key in api);
  out.initial = api.getState();
  out.camera = {
    fov: api.camera.fov,
    near: api.camera.near,
    far: api.camera.far,
    position: api.camera.position.toArray(),
  };

  api.setPlaying(true);
  api.step(1);
  out.walk = api.getState();
  out.walkLeg = api.leftLeg.rotation.x;
  out.walkLegOpposite = api.leftLeg.rotation.x === -api.rightLeg.rotation.x;
  out.walkSteps = out.walk.steps;
  out.walkPosition = out.walk.position;
  api.setPlaying(false);
  out.paused = api.getState();
  out.pausedLegs = [api.leftLeg.rotation.x, api.rightLeg.rotation.x];
  const pausedBefore = snapshot();
  api.step(30);
  out.pauseStable = snapshot() === pausedBefore;

  api.reset();
  api.setPlaying(true);
  api.step(25);
  api.setPlaying(false);
  out.wrap = api.getState();

  api.reset();
  out.rejectShorterSegment = true;
  out.shorterResult = api.setWaypoint(1, 3, 3.75) === false;
  out.lastError = api.getState().lastError;
  out.shorterState = api.getState();
  out.rejectedState = api.getState();
  api.reset();
  out.rejectDuplicate = api.setWaypoint(1, -3, 0) === false;
  api.reset();
  out.rejectIndex = api.setWaypoint(3, 0, 0) === false;
  api.reset();
  out.rejectNaN = api.setWaypoint(0, Number.NaN, 0) === false;
  api.reset();
  out.rejectBounds = api.setWaypoint(0, 8.01, 0) === false;
  out.rejectedRoute = api.getState().route;
  out.rejectedPosition = api.getState().position;
  api.reset();
  out.acceptWaypoint = api.setWaypoint(0, -2.5, 0.5);
  out.afterAccept = api.getState();

  out.saved = typeof api.save() === 'string';
  api.setMode('run');
  api.setPlaying(true);
  api.step(90);
  out.run = api.getState();
  out.loaded = api.load();
  out.loadedState = api.getState();

  api.reset();
  api.setWaypoint(1, 3.5, 0);
  api.setPlaying(true);
  api.step(195);
  out.walkArrival = api.getState();
  api.setPlaying(false);

  out.badJson = api.importState('{nope') === false;
  const stable = snapshot();
  const invalid = JSON.parse(stable);
  invalid.targetIndex = 3;
  out.badField = api.importState(JSON.stringify(invalid)) === false;
  out.importStable = snapshot() === stable;

  api.reset();
  localStorage.removeItem('patrol-route-studio-v1');
  out.missingSave = api.load() === false;
  out.routeLineHeights = Array.from(api.routeLine.geometry.attributes.position.array)
    .filter((_, i) => i % 3 === 1);
  out.characterY = api.character.position.y;
  out.closeWalkX = close(out.walk.position.x, -2.966666666666667);
  return out;
});

check('public API is complete', result.apiKeys);
check('initial state matches spec', JSON.stringify(result.initial) === JSON.stringify({
  version: 1,
  route: [{ x: -3, z: 0 }, { x: 3, z: 0 }, { x: 3, z: 4 }],
  mode: 'walk', playing: false, steps: 0, position: { x: -3, z: 0 },
  yaw: 0, targetIndex: 1, distance: 0, locomotion: 'idle', lastError: '',
}));
check('camera is PerspectiveCamera(50, aspect, 0.1, 100) at (8,7,10)',
  result.camera.fov === 50 && result.camera.near === 0.1 && result.camera.far === 100
  && result.camera.position.every((v, i) => Math.abs(v - [8, 7, 10][i]) < 1e-5));
check('one walk step advances 2/60 m with yaw pi/2', result.closeWalkX
  && Math.abs(result.walk.yaw - Math.PI / 2) < 1e-5 && result.walk.locomotion === 'walk');
check('legs swing with correct signs', result.walkLegOpposite && Math.abs(result.walkLeg - 0.6 * Math.sin(2 * Math.PI * (1 / 30) / 1.2)) < 1e-5);
check('pausing is stable and resets legs', result.pauseStable && result.paused.playing === false && result.pausedLegs.every((v) => v === 0)
  && result.paused.position.x === result.walk.position.x
  && result.paused.steps >= result.walkSteps && result.paused.locomotion === 'idle'
  && result.paused.position.x === result.walkPosition.x && result.paused.position.z === result.walkPosition.z, result);
check('replay continues target progression after pause', result.wrap.steps === 25
  && result.wrap.position.x > -3 && result.wrap.position.x < 3, result.wrap);
check('all invalid waypoint cases rejected', result.rejectShorterSegment && result.rejectDuplicate
  && result.rejectIndex && result.rejectNaN && result.rejectBounds && result.shorterResult
  && result.lastError.length > 0, result.rejectShorterSegment ? result.shorterState : result);
check('rejected waypoint leaves route and position unchanged',
  JSON.stringify(result.rejectedRoute) === JSON.stringify(result.initial.route)
  && result.rejectedPosition.x === -3, result);
check('valid waypoint preserves state and clears error',
  result.acceptWaypoint && result.afterAccept.lastError === '' && result.afterAccept.playing === false);
check('save and load restore full state',
  result.saved && result.loaded && JSON.stringify(result.loadedState) === JSON.stringify(result.afterAccept));
check('run mode gives 4 m/s bounded movement', result.run.mode === 'run' && result.run.locomotion === 'run'
  && result.run.distance <= 6 && result.run.targetIndex >= 1);
check('arrival snaps exactly and advances one target',
  result.walkArrival.position.x === 3.5 && result.walkArrival.position.z === 0
  && result.walkArrival.targetIndex === 2);
check('bad imports fail without mutating state', result.badJson && result.badField && result.importStable);
check('missing save fails without mutation', result.missingSave);
check('route line is at y=0.03 and character stays at y=0',
  result.routeLineHeights.every((v) => Math.abs(v - 0.03) < 1e-5) && result.characterY === 0);
check('no browser errors', browserErrors.length === 0);

await browser.close();
if (failures) {
  console.error(`${failures} check(s) failed`, browserErrors);
  process.exit(1);
}
console.log('All smoke checks passed.');
