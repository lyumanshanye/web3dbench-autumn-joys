# Patrol Route Studio

A standalone, deterministic Three.js patrol-route simulator. Rendering is local-only:
Three.js is bundled by Vite, all geometry is procedural, and the app makes no runtime network requests.

## Requirements

- Node.js 22 or newer (Vite 8 requirement)
- npm

## Run the submitted build

```sh
npm ci
npm run build
npm run preview -- --host 127.0.0.1 --port 4173
```

Open <http://127.0.0.1:4173/>.

## Development

```sh
npm run dev -- --host 127.0.0.1 --port 4173
```

## Public API

The browser exposes `window.patrolStudio` with the scene objects and methods specified
for the exercise. The simulation uses 60 Hz fixed steps, meters, Y-up coordinates, and
character-forward local +Z.

Saved data is stored in localStorage under `patrol-route-studio-v1`.

## Smoke test

`npm test` runs a headless Chromium check against a server at
`http://127.0.0.1:4173/`. Override with `PATROL_URL`. The test uses the packaged
Chromium binary from `@sparticuz/chromium`, so it does not download a browser at runtime.
