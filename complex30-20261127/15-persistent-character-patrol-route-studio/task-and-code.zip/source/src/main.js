import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import './style.css';

const VERSION = 1;
const DT = 1 / 60;
const EPSILON = 1e-5;
const SPEEDS = Object.freeze({ walk: 2, run: 4 });
const STORAGE_KEY = 'patrol-route-studio-v1';
const WAYPOINT_NAMES = ['A', 'B', 'C'];
const DEFAULT_ROUTE = Object.freeze([
  Object.freeze({ x: -3, z: 0 }),
  Object.freeze({ x: 3, z: 0 }),
  Object.freeze({ x: 3, z: 4 }),
]);
const BOUNDS = Object.freeze({ x: [-8, 8], z: [-6, 6] });
const MIN_SEGMENT = 0.5;

function cloneRoute(route) {
  return route.map(({ x, z }) => ({ x, z }));
}

function initialState(route = DEFAULT_ROUTE) {
  return {
    version: VERSION,
    route: cloneRoute(route),
    mode: 'walk',
    playing: false,
    steps: 0,
    position: { x: route[0].x, z: route[0].z },
    yaw: 0,
    targetIndex: 1,
    distance: 0,
    locomotion: 'idle',
    lastError: '',
  };
}

function finiteNumber(value) {
  return typeof value === 'number' && Number.isFinite(value);
}

function validateRoute(route) {
  if (!Array.isArray(route) || route.length !== 3) return false;
  for (const point of route) {
    if (!point || typeof point !== 'object' || Array.isArray(point)) return false;
    if (!finiteNumber(point.x) || !finiteNumber(point.z)) return false;
    if (point.x < BOUNDS.x[0] || point.x > BOUNDS.x[1]) return false;
    if (point.z < BOUNDS.z[0] || point.z > BOUNDS.z[1]) return false;
  }
  for (let i = 0; i < route.length; i += 1) {
    const next = route[(i + 1) % route.length];
    if (Math.hypot(next.x - route[i].x, next.z - route[i].z) < MIN_SEGMENT - EPSILON) return false;
  }
  return true;
}

// Numeric snapshots make API commits atomic: failed operations never mutate state.
function cloneState(state) {
  return {
    version: VERSION,
    route: cloneRoute(state.route),
    mode: state.mode,
    playing: state.playing,
    steps: state.steps,
    position: { x: state.position.x, z: state.position.z },
    yaw: state.yaw,
    targetIndex: state.targetIndex,
    distance: state.distance,
    locomotion: state.locomotion,
    lastError: state.lastError,
  };
}

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0f1927);
scene.fog = new THREE.Fog(0x0f1927, 18, 40);

const camera = new THREE.PerspectiveCamera(50, 1, 0.1, 100);
camera.position.set(8, 7, 10);
camera.lookAt(0, 0, 0);

const renderer = new THREE.WebGLRenderer({
  canvas: document.getElementById('viewport'),
  antialias: true,
  powerPreference: 'high-performance',
});
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;

const controls = new OrbitControls(camera, renderer.domElement);
controls.target.set(0, 0, 0);
controls.enableDamping = true;
controls.dampingFactor = 0.075;
controls.maxPolarAngle = Math.PI / 2.02;
controls.minDistance = 3;
controls.maxDistance = 30;
controls.update();

scene.add(new THREE.HemisphereLight(0xbcd8ff, 0x1b241d, 1.7));
const ambient = new THREE.AmbientLight(0xffffff, 0.3);
scene.add(ambient);
const sun = new THREE.DirectionalLight(0xfff1d0, 3.1);
sun.position.set(-7, 13, 6);
sun.castShadow = true;
sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = -12;
sun.shadow.camera.right = 12;
sun.shadow.camera.top = 12;
sun.shadow.camera.bottom = -12;
sun.shadow.camera.near = 1;
sun.shadow.camera.far = 35;
sun.shadow.bias = -0.0003;
scene.add(sun);

const ground = new THREE.Mesh(
  new THREE.PlaneGeometry(16, 12),
  new THREE.MeshStandardMaterial({ color: 0x26362f, roughness: 0.92, metalness: 0.02 }),
);
ground.rotation.x = -Math.PI / 2;
ground.receiveShadow = true;
scene.add(ground);

const grid = new THREE.GridHelper(16, 16, 0x6f8d7f, 0x40584e);
grid.scale.z = 12 / 16;
grid.position.y = 0.004;
grid.material.transparent = true;
grid.material.opacity = 0.24;
scene.add(grid);

const boundary = new THREE.LineSegments(
  new THREE.EdgesGeometry(new THREE.PlaneGeometry(16, 12)),
  new THREE.LineBasicMaterial({ color: 0x8fac9d, transparent: true, opacity: 0.55 }),
);
boundary.rotation.x = -Math.PI / 2;
boundary.position.y = 0.008;
scene.add(boundary);

const character = new THREE.Group();
character.name = 'character';
scene.add(character);

const bodyMaterial = new THREE.MeshStandardMaterial({ color: 0xf4b942, roughness: 0.48, metalness: 0.08 });
const body = new THREE.Mesh(new THREE.BoxGeometry(0.6, 0.8, 0.35), bodyMaterial);
body.position.y = 1.1;
body.castShadow = true;
body.receiveShadow = true;
character.add(body);

const visor = new THREE.Mesh(
  new THREE.BoxGeometry(0.38, 0.12, 0.025),
  new THREE.MeshStandardMaterial({ color: 0x162334, roughness: 0.25, metalness: 0.5 }),
);
visor.position.set(0, 1.22, 0.188);
character.add(visor);

const legMaterial = new THREE.MeshStandardMaterial({ color: 0xd19327, roughness: 0.6 });
function makeLeg(x) {
  const pivot = new THREE.Group();
  pivot.position.set(x, 0.7, 0);
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.7, 0.18), legMaterial);
  mesh.position.y = -0.35;
  mesh.castShadow = true;
  pivot.add(mesh);
  character.add(pivot);
  return pivot;
}
const leftLeg = makeLeg(-0.18);
const rightLeg = makeLeg(0.18);

const directionArrow = new THREE.ArrowHelper(
  new THREE.Vector3(0, 0, 1),
  new THREE.Vector3(0, 0.12, 0),
  0.85,
  0x52d3b3,
  0.2,
  0.12,
);
character.add(directionArrow);

const routeLine = new THREE.LineLoop(
  new THREE.BufferGeometry().setAttribute(
    'position',
    new THREE.BufferAttribute(new Float32Array(9), 3).setUsage(THREE.DynamicDrawUsage),
  ),
  new THREE.LineBasicMaterial({ color: 0xf4b942, transparent: true, opacity: 0.9 }),
);
routeLine.name = 'routeLine';
scene.add(routeLine);

const markerColors = [0x52d3b3, 0xf4b942, 0xff8a7a];
const markers = [];
for (let i = 0; i < 3; i += 1) {
  const group = new THREE.Group();
  const ring = new THREE.Mesh(
    new THREE.RingGeometry(0.23, 0.31, 40),
    new THREE.MeshBasicMaterial({
      color: markerColors[i],
      transparent: true,
      opacity: 0.9,
      side: THREE.DoubleSide,
      depthWrite: false,
    }),
  );
  ring.rotation.x = -Math.PI / 2;
  ring.position.y = 0.018;
  group.add(ring);

  const post = new THREE.Mesh(
    new THREE.CylinderGeometry(0.018, 0.018, 0.42, 10),
    new THREE.MeshStandardMaterial({ color: markerColors[i], roughness: 0.5 }),
  );
  post.position.y = 0.23;
  group.add(post);

  const orb = new THREE.Mesh(
    new THREE.SphereGeometry(0.065, 16, 12),
    new THREE.MeshBasicMaterial({ color: markerColors[i] }),
  );
  orb.position.y = 0.46;
  group.add(orb);
  scene.add(group);
  markers.push({ group, ring });
}

const canvas = document.createElement('canvas');
canvas.width = 128;
canvas.height = 64;
function makeLabel(text) {
  const ctx = canvas.getContext('2d');
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = 'rgba(12, 20, 31, 0.85)';
  ctx.beginPath();
  ctx.roundRect(38, 8, 52, 46, 12);
  ctx.fill();
  ctx.strokeStyle = 'rgba(244, 185, 66, .65)';
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.fillStyle = '#fff4d6';
  ctx.font = 'bold 34px sans-serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, 64, 32);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  const sprite = new THREE.Sprite(
    new THREE.SpriteMaterial({ map: texture, depthTest: false, transparent: true }),
  );
  sprite.scale.set(0.62, 0.31, 1);
  sprite.renderOrder = 5;
  return sprite;
}
const labelSprites = WAYPOINT_NAMES.map((name) => {
  const sprite = makeLabel(name);
  scene.add(sprite);
  return sprite;
});

let state = initialState();
let operationError = '';

function syncScene() {
  const positions = routeLine.geometry.attributes.position;
  state.route.forEach((point, i) => {
    positions.setXYZ(i, point.x, 0.03, point.z);
  });
  positions.needsUpdate = true;
  routeLine.geometry.computeBoundingSphere();

  markers.forEach(({ group, ring }, i) => {
    group.position.set(state.route[i].x, 0, state.route[i].z);
    ring.material.opacity = i === state.targetIndex ? 1 : 0.62;
    const scale = i === state.targetIndex ? 1.18 : 1;
    ring.scale.setScalar(scale);
    labelSprites[i].position.set(state.route[i].x, 0.82, state.route[i].z);
  });

  character.position.set(state.position.x, 0, state.position.z);
  character.rotation.y = state.yaw;

  const phase = (2 * Math.PI * state.distance) / 1.2;
  const swing = state.playing ? 0.6 * Math.sin(phase) : 0;
  leftLeg.rotation.x = swing;
  rightLeg.rotation.x = -swing;
  character.updateMatrixWorld(true);
  controls.target.lerp(
    new THREE.Vector3(state.position.x * 0.35, 0.45, state.position.z * 0.35),
    0.08,
  );

  document.body.dataset.locomotion = state.locomotion;
  window.dispatchEvent(new CustomEvent('patrol:statechange'));
}

function commit(nextState) {
  nextState.locomotion = nextState.playing ? nextState.mode : 'idle';
  state = nextState;
  state.lastError = '';
  operationError = '';
  syncScene();
  updateUI();
}

function fail(message) {
  operationError = message;
  state.lastError = message;
  window.dispatchEvent(new CustomEvent('patrol:statechange'));
  updateUI();
  return false;
}

function clearError() {
  operationError = '';
  state.lastError = '';
}

function stepOnce(next) {
  const target = next.route[next.targetIndex];
  const dx = target.x - next.position.x;
  const dz = target.z - next.position.z;
  const remaining = Math.hypot(dx, dz);
  const travel = Math.min(SPEEDS[next.mode] / 60, remaining);

  if (travel > 0) {
    next.position.x += (dx / remaining) * travel;
    next.position.z += (dz / remaining) * travel;
    next.distance += travel;
  }
  if (dx !== 0 || dz !== 0) {
    next.yaw = Math.atan2(dx, dz);
  }

  const afterDistance = Math.hypot(
    target.x - next.position.x,
    target.z - next.position.z,
  );
  if (afterDistance <= EPSILON) {
    next.position.x = target.x;
    next.position.z = target.z;
    next.targetIndex = (next.targetIndex + 1) % next.route.length;
  }
  next.steps += 1;
}

function getState() {
  return cloneState(state);
}

function setPlaying(flag) {
  if (typeof flag !== 'boolean') return fail('Playing must be a boolean.');
  const next = cloneState(state);
  next.playing = flag;
  next.lastError = '';
  commit(next);
  return true;
}

function setMode(mode) {
  if (mode !== 'walk' && mode !== 'run') {
    return fail('Mode must be "walk" or "run".');
  }
  const next = cloneState(state);
  next.mode = mode;
  next.lastError = '';
  commit(next);
  return true;
}

function step(n) {
  if (!Number.isInteger(n) || n < 0) {
    return fail('step(n) requires a nonnegative integer.');
  }
  const next = cloneState(state);
  if (next.playing) {
    for (let i = 0; i < n; i += 1) stepOnce(next);
  }
  next.locomotion = next.playing ? next.mode : 'idle';
  next.lastError = '';
  commit(next);
  return true;
}

function setWaypoint(i, x, z) {
  if (!Number.isInteger(i) || i < 0 || i > 2) {
    return fail('Waypoint index must be an integer from 0 to 2.');
  }
  if (!finiteNumber(x) || !finiteNumber(z)) {
    return fail('Waypoint coordinates must be finite numbers.');
  }
  if (x < BOUNDS.x[0] || x > BOUNDS.x[1] || z < BOUNDS.z[0] || z > BOUNDS.z[1]) {
    return fail(`Waypoint must stay within x ${BOUNDS.x[0]}…${BOUNDS.x[1]} and z ${BOUNDS.z[0]}…${BOUNDS.z[1]}.`);
  }
  const next = cloneState(state);
  next.route[i] = { x, z };
  if (!validateRoute(next.route)) {
    return fail('Every route segment must be at least 0.5 m long.');
  }
  if (i === 0 && next.steps === 0 && !next.playing && next.distance === 0) {
    next.position = { x, z };
  }
  commit(next);
  return true;
}

function save() {
  const text = JSON.stringify(getState());
  try {
    localStorage.setItem(STORAGE_KEY, text);
  } catch {
    return fail('Could not write to local storage.');
  }
  clearError();
  updateUI();
  return text;
}

function parseImported(text) {
  if (typeof text !== 'string') return null;
  let candidate;
  try {
    candidate = JSON.parse(text);
  } catch {
    return null;
  }
  if (!candidate || typeof candidate !== 'object' || Array.isArray(candidate)) return null;
  if (candidate.version !== VERSION) return null;
  if (!validateRoute(candidate.route)) return null;
  if (candidate.mode !== 'walk' && candidate.mode !== 'run') return null;
  if (typeof candidate.playing !== 'boolean') return null;
  if (!Number.isInteger(candidate.steps) || candidate.steps < 0) return null;
  if (!candidate.position || !finiteNumber(candidate.position.x) || !finiteNumber(candidate.position.z)) return null;
  if (!finiteNumber(candidate.yaw)) return null;
  if (!Number.isInteger(candidate.targetIndex) || candidate.targetIndex < 0 || candidate.targetIndex > 2) return null;
  if (!finiteNumber(candidate.distance) || candidate.distance < 0) return null;
  if (candidate.locomotion !== 'idle' && candidate.locomotion !== 'walk' && candidate.locomotion !== 'run') return null;
  const expectedLocomotion = candidate.playing ? candidate.mode : 'idle';
  if (candidate.locomotion !== expectedLocomotion) return null;
  if (typeof candidate.lastError !== 'string') return null;

  return {
    version: VERSION,
    route: cloneRoute(candidate.route),
    mode: candidate.mode,
    playing: candidate.playing,
    steps: candidate.steps,
    position: { x: candidate.position.x, z: candidate.position.z },
    yaw: candidate.yaw,
    targetIndex: candidate.targetIndex,
    distance: candidate.distance,
    locomotion: candidate.locomotion,
    lastError: '',
  };
}

function importState(text) {
  const imported = parseImported(text);
  if (!imported) return fail('Import rejected: the state is malformed or invalid.');
  commit(imported);
  return true;
}

function load() {
  clearError();
  let text;
  try {
    text = localStorage.getItem(STORAGE_KEY);
  } catch {
    return fail('Could not read from local storage.');
  }
  if (text === null) return fail('No saved patrol was found.');
  return importState(text);
}

function reset() {
  state = initialState();
  operationError = '';
  syncScene();
  updateUI();
  return true;
}

window.patrolStudio = {
  scene,
  camera,
  renderer,
  controls,
  character,
  routeLine,
  leftLeg,
  rightLeg,
  getState,
  setPlaying,
  setMode,
  step,
  setWaypoint,
  save,
  load,
  importState,
  reset,
  get lastError() { return state.lastError; },
};

const ui = {
  play: document.getElementById('play'),
  walk: document.getElementById('walk'),
  run: document.getElementById('run'),
  save: document.getElementById('save'),
  load: document.getElementById('load'),
  reset: document.getElementById('reset'),
  message: document.getElementById('message'),
  pill: document.getElementById('status-pill'),
  pos: document.getElementById('pos'),
  target: document.getElementById('target'),
  yaw: document.getElementById('yaw'),
  distance: document.getElementById('distance'),
  steps: document.getElementById('steps'),
  speed: document.getElementById('speed'),
  modeLabel: document.getElementById('mode-label'),
  inputs: [0, 1, 2].map((i) => {
    const name = WAYPOINT_NAMES[i].toLowerCase();
    return {
      x: document.getElementById(`${name}x`),
      z: document.getElementById(`${name}z`),
    };
  }),
};

function formatNumber(value) {
  return Number(value.toFixed(2)).toString();
}

function updateUI() {
  ui.play.textContent = state.playing ? 'Pause' : 'Play';
  ui.play.setAttribute('aria-label', state.playing ? 'Pause patrol' : 'Play patrol');
  ui.walk.setAttribute('aria-pressed', String(state.mode === 'walk'));
  ui.walk.classList.toggle('active', state.mode === 'walk');
  ui.run.setAttribute('aria-pressed', String(state.mode === 'run'));
  ui.run.classList.toggle('active', state.mode === 'run');
  ui.pill.textContent = state.locomotion;
  ui.pill.className = `pill ${state.locomotion}`;
  ui.pos.textContent = `${state.position.x.toFixed(2)}, ${state.position.z.toFixed(2)}`;
  const target = state.route[state.targetIndex];
  ui.target.textContent = `${WAYPOINT_NAMES[state.targetIndex]} (${formatNumber(target.x)}, ${formatNumber(target.z)})`;
  ui.yaw.textContent = `${THREE.MathUtils.radToDeg(state.yaw).toFixed(1)}°`;
  ui.distance.textContent = `${state.distance.toFixed(2)} m`;
  ui.steps.textContent = String(state.steps);
  ui.speed.textContent = state.playing ? `${SPEEDS[state.mode].toFixed(2)} m/s` : 'Paused';
  ui.modeLabel.textContent = state.mode === 'walk' ? 'Walk' : 'Run';
  const active = operationError || state.lastError;
  ui.message.textContent = active || (state.playing
    ? `Patrolling toward ${WAYPOINT_NAMES[state.targetIndex]}.`
    : 'Ready to patrol.');
  ui.message.className = `message${active ? ' error' : ''}`;
  state.route.forEach((point, i) => {
    ui.inputs[i].x.value = formatNumber(point.x);
    ui.inputs[i].z.value = formatNumber(point.z);
  });
}

function commitWaypointInput(i, axis) {
  const input = ui.inputs[i][axis];
  const raw = input.value.trim();
  if (raw === '') {
    input.value = formatNumber(state.route[i][axis]);
    return;
  }
  const value = Number(raw);
  const previousError = operationError;
  const previousStateError = state.lastError;
  if (!setWaypoint(i, axis === 'x' ? value : state.route[i].x, axis === 'z' ? value : state.route[i].z)) {
    operationError = previousError;
    state.lastError = previousStateError;
    input.value = formatNumber(state.route[i][axis]);
  }
}

ui.play.addEventListener('click', () => setPlaying(!state.playing));
ui.walk.addEventListener('click', () => setMode('walk'));
ui.run.addEventListener('click', () => setMode('run'));
ui.save.addEventListener('click', () => {
  save();
  ui.message.textContent = 'Patrol saved locally.';
  ui.message.className = 'message ok';
});
ui.load.addEventListener('click', load);
ui.reset.addEventListener('click', reset);
ui.inputs.forEach((pair, i) => {
  for (const axis of ['x', 'z']) {
    pair[axis].addEventListener('change', () => commitWaypointInput(i, axis));
    pair[axis].addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        pair[axis].blur();
      }
    });
  }
});

function resize() {
  const width = window.innerWidth;
  const height = window.innerHeight;
  camera.aspect = width / height;
  camera.updateProjectionMatrix();
  renderer.setSize(width, height, false);
}
window.addEventListener('resize', resize);
resize();

let accumulator = 0;
let previousTime = performance.now();
function animate(now) {
  requestAnimationFrame(animate);
  const elapsed = Math.min((now - previousTime) / 1000, 0.1);
  previousTime = now;
  if (state.playing) {
    accumulator += elapsed;
    let count = 0;
    while (accumulator >= DT && count < 60) {
      accumulator -= DT;
      count += 1;
    }
    if (count > 0) step(count);
  } else {
    accumulator = 0;
  }
  controls.update();
  renderer.render(scene, camera);
}

syncScene();
updateUI();
requestAnimationFrame(animate);
