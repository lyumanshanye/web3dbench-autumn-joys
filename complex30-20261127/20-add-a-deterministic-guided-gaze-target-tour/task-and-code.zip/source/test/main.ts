import {
  Mesh,
  AnimationMixer,
  Vector3,
  AudioLoader,
  PositionalAudio,
  Quaternion,
  SphereGeometry,
  MeshBasicMaterial,
  BufferGeometry,
  LineBasicMaterial,
  LineLoop
} from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
import App3D from './App3D';
import { makeBlink3D, makeBlinkTick } from '../src/Blink3D';
import { makeBlinker } from '../src/Blink';
import { makeTalk3D, makeTalkTick } from '../src/Talk3D';
import { makeTalk } from '../src/Talk';
import { positionSound } from '../src/Utils3D';
import { look3D, attachEffector, blendTo } from '../src/Look3D';

const app = new App3D();

// World-space gaze tour helpers, kept in scene coordinates (not avatar-local).
const gazeWaypoints = [
  new Vector3(2, 2, 4),
  new Vector3(-2, 2, 4),
  new Vector3(-2, 2, -4),
  new Vector3(2, 2, -4)
];
const TOUR_DURATION = 12;
const SEGMENT_DURATION = 3;
const gazeTarget = new Mesh(
  new SphereGeometry(0.15, 16, 8),
  new MeshBasicMaterial({ color: 0xff3300 })
);
gazeTarget.name = 'gazeTarget';
gazeTarget.position.copy(gazeWaypoints[0]);
app.scene.add(gazeTarget);

const gazePath = new LineLoop(
  new BufferGeometry().setFromPoints(gazeWaypoints),
  new LineBasicMaterial({ color: 0x333333 })
);
gazePath.name = 'gazePath';
app.scene.add(gazePath);


let tourTime = 0;
let tourRunning = true;
let manualMode = false;
let gazeEffector = null;
let looking = false;
// Replaced after the glTF has loaded with the active look wrapper.
let activeLook: (dt: number) => void = () => undefined;

function sampleTour(time: number): Vector3 {
  const u = ((time % TOUR_DURATION) + TOUR_DURATION) % TOUR_DURATION;
  const i = Math.floor(u / SEGMENT_DURATION);
  const f = (u - SEGMENT_DURATION * i) / SEGMENT_DURATION;
  return new Vector3().lerpVectors(
    gazeWaypoints[i],
    gazeWaypoints[(i + 1) % gazeWaypoints.length],
    f
  );
}

function seekTour(time: number): void {
  if (!Number.isFinite(time)) throw new RangeError('Tour time must be finite');
  tourTime = ((time % TOUR_DURATION) + TOUR_DURATION) % TOUR_DURATION;
  gazeTarget.position.copy(sampleTour(tourTime));
}

function advanceTour(dt: number): void {
  if (tourRunning) seekTour(tourTime + dt);
}

function requireManualStep(dt: number, name: string): void {
  if (!manualMode || !Number.isFinite(dt) || dt < 0) {
    throw new RangeError(
      name + ' requires manual mode and a finite dt >= 0'
    );
  }
}

window.actorDemo = {
  target: gazeTarget,
  setManualMode(enabled: boolean): void {
    manualMode = Boolean(enabled);
  },
  seekTour,
  step(dt: number): void {
    requireManualStep(dt, 'step');
    advanceTour(dt);
    activeLook(dt);
  },
  stepLook(dt: number): void {
    requireManualStep(dt, 'stepLook');
    activeLook(dt);
  },
  getState(): object {
    const p = gazeTarget.position;
    return {
      tourTime,
      running: tourRunning,
      manual: manualMode,
      looking,
      targetPosition: [p.x, p.y, p.z]
    };
  },
  gazeError(): number {
    if (!gazeEffector) return NaN;
    app.scene.updateMatrixWorld(true);
    const effector = gazeEffector as unknown as import('three').Object3D;
    const position = new Vector3().setFromMatrixPosition(effector.matrixWorld);
    const direction = new Vector3()
      .subVectors(gazeTarget.position, position)
      .normalize();
    const forward = new Vector3()
      .setFromMatrixColumn(effector.matrixWorld, 2)
      .normalize();
    const dot = Math.max(-1, Math.min(1, forward.dot(direction)));
    return Math.acos(dot);
  }
};

document.addEventListener('keydown', e => {
  if (e.code === 'KeyP') tourRunning = !tourRunning;
  if (e.code === 'KeyR') {
    seekTour(0);
    tourRunning = true;
  }
});

const loader = new GLTFLoader().setPath('./assets/');
loader.load('malcom.glb', function(gltf) {
  console.log(gltf);

  // gltf.scene.rotation.z = 45;
  gltf.scene.scale.multiplyScalar(0.5);
  app.scene.add(gltf.scene);

  const body = gltf.scene.getObjectByName('Body') as Mesh;

  const bView = makeBlink3D(body, 'Blink_Left', 'Blink_Right', 2.0);
  const bState = makeBlinker();
  app.tickFuncs.push(makeBlinkTick(bState, bView));

  //talking from audio
  const talkState = makeTalk();
  const soundEmitter = new PositionalAudio(app.audioListener);
  const talkView = makeTalk3D(body, 'MouthOpen', soundEmitter, 0.01, talkState);
  app.tickFuncs.push(makeTalkTick(talkView, talkState));
  positionSound(body, soundEmitter);

  const audioLoader = new AudioLoader().setPath('./assets/');
  audioLoader.load('what-to-drink.mp3', function(buffer) {
    soundEmitter.setBuffer(buffer);
    soundEmitter.play(); //play it to init source with domAudioContext.createBufferSource
    soundEmitter.stop();
  });

  document.addEventListener('keydown', e => {
    if (e.code === 'KeyS') {
      soundEmitter.stop();
      soundEmitter.play();
    }
  });

  const mixer = new AnimationMixer(gltf.scene);
  const animations = gltf.animations;
  const idleAction = mixer.clipAction(animations[0]);
  idleAction.play();
  // const lookaround = mixer.clipAction(animations[1]);
  // lookaround.play();

  console.log(idleAction);

  app.tickFuncs.push(dt => {
    mixer.update(dt);
    // Manual mode leaves baseline ticks running but owns tour/look stepping.
    if (!window.actorDemo.getState().manual) {
      advanceTour(dt);
      activeLook(dt);
    }
  });

  //Look at the touring target
  const head = gltf.scene.getObjectByName('mixamorigHead');
  const eyeL = gltf.scene.getObjectByName('mixamorigLeftEye');
  const eyeR = gltf.scene.getObjectByName('mixamorigRightEye');

  //Find center eye
  eyeL.updateWorldMatrix(true, false);
  eyeR.updateWorldMatrix(false, false); //assuming eyes have same parent
  const eyeCenter = new Vector3()
    .setFromMatrixPosition(eyeL.matrixWorld)
    .add(new Vector3().setFromMatrixPosition(eyeR.matrixWorld))
    .multiplyScalar(0.5);
  head.worldToLocal(eyeCenter);
  const headEffector = attachEffector(eyeCenter, head);
  gazeEffector = headEffector;
  let lookTick = null;
  let blendBackTick = null;
  function toggleLook(): void {
    if (lookTick === null) {
      const headLook = look3D(headEffector, [eyeL, eyeR], gltf.scene);
      // const headLook = look3D(headEffector, [eyeL, eyeR]);
      // const headLook = look3D(headEffector);
      lookTick = (dt: number): void => {
        headLook(gazeTarget.position, dt);
      };
    } else {
      const tickers = [
        blendTo(eyeL.quaternion, new Quaternion(), 0.1),
        blendTo(eyeR.quaternion, new Quaternion(), 0.1),
        blendTo(head.quaternion, head.quaternion, 0.3), //samples start quat of IK, then blends back to current exported animation
        blendTo(gltf.scene.quaternion, new Quaternion(), 1)
      ];
      blendBackTick = (dt: number): void => {
        tickers.forEach(tick => tick(dt));
      };
      lookTick = null;
    }
    looking = lookTick !== null;
    activeLook = (dt: number): void => {
      if (lookTick !== null) lookTick(dt);
      else if (blendBackTick !== null) blendBackTick(dt);
    };
  }
  toggleLook();
  function onkey(e): void {
    if (e.code == 'Space') toggleLook();
  }
  document.addEventListener('keydown', onkey);
});

declare global {
  interface Window {
    actorDemo: {
      target: Mesh;
      setManualMode(enabled: boolean): void;
      seekTour(time: number): void;
      step(dt: number): void;
      stepLook(dt: number): void;
      getState(): {
        tourTime: number;
        running: boolean;
        manual: boolean;
        looking: boolean;
        targetPosition: number[];
      };
      gazeError(): number;
    };
  }
}
