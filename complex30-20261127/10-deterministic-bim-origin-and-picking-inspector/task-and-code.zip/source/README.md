# BIM Origin Inspector

Standalone Three.js inspector for a four-element inline IFC fixture. Rendering uses local `three` code, procedural box geometry, and solid-color materials only; no models, textures, fonts, or network data are fetched at runtime.

## Run

```bash
npm ci
npm run dev
```

Open http://127.0.0.1:4173/.

## Browser API

`window.bimOriginLab` exposes `scene`, `camera`, `renderer`, `modelRoot`, `objects` (an `id → Mesh` Map), `bounds`, `origin`, a getter for `selectedId`, `setTypeVisible(type, visible)`, `pick(ndcX, ndcY)`, `focusSelected()`, `reset()`, and `getState()`.

Coordinates are in meters with Y up. Camera FOV is 40° with a 4/3 aspect ratio, and geometry comparisons use a tolerance of `0.0001`.

## Verification

With the dev server running:

```bash
node tests/verify.mjs
node tests/click-check.mjs
```

These scripts use the local Playwright dependency to check scene setup, picking and highlight state, type visibility, focus, reset, and a real canvas click.
