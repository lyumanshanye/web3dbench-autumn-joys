import { chromium } from 'playwright';
import assert from 'node:assert/strict';

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
const requests = [];
page.on('request', (request) => requests.push(request.url()));
const errors = [];
page.on('pageerror', (error) => errors.push(error.message));
await page.goto('http://127.0.0.1:4173/');
await page.waitForFunction(() => window.bimOriginLab);
await page.waitForTimeout(300);

const result = await page.evaluate(() => {
  const api = window.bimOriginLab;
  const near = (a, b, tol = 0.0001) => Math.abs(a - b) <= tol;
  const vecNear = (a, b) => a.length === b.length && a.every((v, i) => near(v, b[i]));

  const checks = [];
  checks.push(['scene/camera/renderer', api.scene.isScene && api.camera.isPerspectiveCamera && api.renderer.isWebGLRenderer]);
  checks.push(['four meshes', api.objects.size === 4 && api.modelRoot.children.length === 4]);
  checks.push(['mesh metadata', [...api.objects.values()].every((m) => m.name === m.userData.id)]);
  checks.push(['canvas size', api.renderer.domElement.width >= 800 && api.renderer.domElement.height >= 600]);
  checks.push(['camera setup', near(api.camera.fov, 40) && near(api.camera.aspect, 4 / 3) && near(api.camera.near, 0.06224949798994366) && near(api.camera.far, 62.24949798994366)]);
  checks.push(['origin', vecNear(api.origin.toArray(), [0.5, -2.5, -0.5]) && vecNear(api.modelRoot.position.toArray(), [0.5, -2.5, -0.5])]);
  checks.push(['local positions', vecNear(api.objects.get('wall-A').position.toArray(), [-4, 1, 0])]);
  checks.push(['initial camera', vecNear(api.camera.position.toArray(), [12, 9, 14])]);

  // Grid-ish search in NDC to find a hit.
  let found = null;
  outer:
  for (let y = 0.8; y >= -0.8; y -= 0.1) {
    for (let x = -0.8; x <= 0.8; x += 0.08) {
      const id = api.pick(x, y);
      if (id) { found = { id, x, y }; break outer; }
    }
  }
  checks.push(['pick finds mesh', !!found]);
  checks.push(['selected visible', found && api.selectedId === found.id]);
  const selected = found && api.objects.get(found.id);
  checks.push(['green emissive', selected && selected.material.emissive.getHex() === 0x00ff00 && selected.material.emissiveIntensity === 1]);
  checks.push(['others unselected', [...api.objects.values()].filter((m) => m !== selected).every((m) => m.material.emissive.getHex() === 0 && m.material.emissiveIntensity === 0)]);

  const initialTarget = api.getState().cameraTarget;
  const focusResult = api.focusSelected();
  const focusState = api.getState();
  const box = new (selected.geometry.boundingBox.constructor)();
  checks.push(['focus true', focusResult === true]);
  checks.push(['focus retains clip/fov', near(api.camera.fov, 40) && near(api.camera.near, 0.06224949798994366) && near(api.camera.far, 62.24949798994366)]);
  checks.push(['focus target changed', !vecNear(focusState.cameraTarget, initialTarget)]);

  const hiddenType = selected.userData.type;
  checks.push(['hide selected type', api.setTypeVisible(hiddenType, false) === true && api.selectedId === null && selected.visible === false && selected.material.emissiveIntensity === 0]);
  checks.push(['unknown type', api.setTypeVisible('IfcDoor', false) === false && api.selectedId === null]);
  checks.push(['visible types', api.getState().visibleTypes[hiddenType] === false]);
  checks.push(['show selected type', api.setTypeVisible(hiddenType, true) === true && selected.visible === true]);
  checks.push(['empty pick clears', api.pick(0.99, 0.99) === null && api.selectedId === null]);

  api.reset();
  const s = api.getState();
  checks.push(['reset', s.selectedId === null && vecNear(s.cameraPosition, [12, 9, 14]) && vecNear(s.cameraTarget, [0, 0, 0]) && Object.values(s.visibleTypes).every(Boolean)]);
  checks.push(['reset emissive', [...api.objects.values()].every((m) => m.material.emissiveIntensity === 0)]);
  return { checks, failed: checks.filter(([, ok]) => !ok).map(([name]) => name) };
});

// Click selection through the real canvas.
const clickResult = await page.evaluate(() => {
  const api = window.bimOriginLab;
  api.pick(0.18, 0.2);
  return api.selectedId;
});
const focusDisabled = await page.locator('#focus-btn').isDisabled();
await page.getByRole('button', { name: 'Focus' }).click({ force: true });
await page.locator('#type-IfcWall').click();
await page.getByRole('button', { name: 'Reset' }).click();
await page.waitForTimeout(200);
await page.screenshot({ path: 'artifacts/screenshot.png' });

for (const [name, ok] of result.checks) console.log(`${ok ? 'PASS' : 'FAIL'} ${name}`);
console.log('click via API selected:', clickResult);
console.log('focus disabled with no selection:', focusDisabled);
console.log('network requests:', requests);
console.log('page errors:', errors);
console.log('FAILED:', result.failed.length);
await browser.close();
if (result.failed.length) process.exit(1);
