import { chromium } from 'playwright';
import assert from 'node:assert/strict';

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
await page.goto('http://127.0.0.1:4173/');
await page.waitForFunction(() => window.bimOriginLab);
const box = await page.locator('canvas').boundingBox();
const point = await page.evaluate(() => {
  const api = window.bimOriginLab;
  for (let y = 0.8; y >= -0.8; y -= 0.05) {
    for (let x = -0.8; x <= 0.8; x += 0.05) {
      const candidates = [...api.objects.values()];
      const ctx = api.camera;
      ctx.updateMatrixWorld();
      const id = api.pick(x, y);
      if (id) { api.reset(); return { id, x, y }; }
    }
  }
  return null;
});
assert(point);
await page.mouse.click(box.x + ((point.x + 1) / 2) * box.width, box.y + ((1 - point.y) / 2) * box.height);
const selected = await page.evaluate(() => window.bimOriginLab.selectedId);
const focusDisabled = await page.locator('#focus-btn').isDisabled();
assert.equal(selected, point.id);
assert.equal(focusDisabled, false);
await page.getByRole('button', { name: 'Focus' }).click();
const afterFocus = await page.evaluate(() => window.bimOriginLab.getState());
const focusOk = await page.evaluate(() => {
  const api = window.bimOriginLab;
  const mesh = api.objects.get(api.selectedId);
  const expectedDistance = (Math.hypot(9, 5, 7) / 2) / Math.tan(20 * Math.PI / 180) * 1.25;
  const dir = { x: 1, y: 0.75, z: 1 };
  const len = Math.hypot(dir.x, dir.y, dir.z);
  const state = api.getState();
  const target = [
    mesh.position.x + api.modelRoot.position.x,
    mesh.position.y + api.modelRoot.position.y,
    mesh.position.z + api.modelRoot.position.z,
  ];
  return state.cameraTarget.every((v, i) => Math.abs(v - target[i]) < 1e-4) &&
    Math.abs(Math.hypot(...state.cameraPosition.map((v, i) => v - state.cameraTarget[i])) - expectedDistance) < 1e-3;
});
assert(focusOk);
await page.getByRole('button', { name: 'Reset' }).click();
const afterReset = await page.evaluate(() => window.bimOriginLab.getState());
assert.equal(afterReset.selectedId, null);
assert.deepEqual(afterReset.cameraPosition, [12, 9, 14]);
console.log('PASS real canvas click ->', selected);
console.log('PASS focus button geometry');
console.log('PASS reset restores state');
await browser.close();
