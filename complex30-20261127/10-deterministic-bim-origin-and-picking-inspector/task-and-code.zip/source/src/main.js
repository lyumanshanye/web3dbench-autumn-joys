import * as THREE from 'three';
import './style.css';

const TOLERANCE = 0.0001;
const CANVAS_WIDTH = 800;
const CANVAS_HEIGHT = 600;
const ASPECT = CANVAS_WIDTH / CANVAS_HEIGHT;
const INITIAL_CAMERA_POSITION = [12, 9, 14];
const INITIAL_LOOK_TARGET = [0, 0, 0];
const CAMERA_UP = [0, 1, 0];
const FOV = 40;

const FIXTURE = [
  { id: 'wall-A', type: 'IfcWall', center: [-4, 1, 0], size: [2, 2, 4], color: 0xd3a35c },
  { id: 'slab-A', type: 'IfcSlab', center: [0, 0.5, 0], size: [6, 1, 6], color: 0x7b8996 },
  { id: 'window-A', type: 'IfcWindow', center: [3, 2, -1], size: [1, 4, 2], color: 0x67c5df },
  { id: 'beam-A', type: 'IfcBeam', center: [0, 4, 3], size: [8, 2, 2], color: 0xc9765f },
];

const FIXTURE_TYPES = ['IfcWall', 'IfcSlab', 'IfcWindow', 'IfcBeam'];

const bounds = { min: [-5, 0, -3], max: [4, 5, 4] };
const boundsCenter = [
  (bounds.min[0] + bounds.max[0]) / 2,
  (bounds.min[1] + bounds.max[1]) / 2,
  (bounds.min[2] + bounds.max[2]) / 2,
];
const originArray = boundsCenter.map((value) => -value);
const diagonal = Math.hypot(
  bounds.max[0] - bounds.min[0],
  bounds.max[1] - bounds.min[1],
  bounds.max[2] - bounds.min[2],
);

const canvasWrap = document.getElementById('canvas-wrap');

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b1014);

const camera = new THREE.PerspectiveCamera(FOV, ASPECT, 1, 2);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.setSize(CANVAS_WIDTH, CANVAS_HEIGHT, false);
renderer.domElement.setAttribute('aria-label', 'BIM Origin Inspector viewport');
canvasWrap.appendChild(renderer.domElement);

const modelRoot = new THREE.Group();
modelRoot.name = 'modelRoot';
scene.add(modelRoot);

const light = new THREE.HemisphereLight(0xffffff, 0x445566, 2.1);
scene.add(light);
const keyLight = new THREE.DirectionalLight(0xffffff, 1.6);
keyLight.position.set(8, 14, 10);
scene.add(keyLight);
const fillLight = new THREE.DirectionalLight(0x9fc3dd, 0.7);
fillLight.position.set(-10, 4, -8);
scene.add(fillLight);

const materials = FIXTURE.map(
  (item) =>
    new THREE.MeshStandardMaterial({
      color: item.color,
      roughness: 0.78,
      metalness: 0.02,
      emissive: 0x000000,
      emissiveIntensity: 0,
    }),
);

const objects = new Map();
FIXTURE.forEach((item, index) => {
  const geometry = new THREE.BoxGeometry(item.size[0], item.size[1], item.size[2]);
  const mesh = new THREE.Mesh(geometry, materials[index]);
  mesh.name = item.id;
  mesh.userData.id = item.id;
  mesh.userData.type = item.type;
  mesh.position.set(item.center[0], item.center[1], item.center[2]);
  mesh.visible = true;
  modelRoot.add(mesh);
  objects.set(item.id, mesh);
});

const initialTransforms = new Map(
  FIXTURE.map((item) => [
    item.id,
    {
      position: [...item.center],
      quaternion: [0, 0, 0, 1],
      scale: [1, 1, 1],
      visible: true,
    },
  ]),
);
const initialMaterials = materials.map((material) => ({
  color: material.color.getHex(),
  emissive: material.emissive.getHex(),
  emissiveIntensity: material.emissiveIntensity,
}));

modelRoot.position.set(originArray[0], originArray[1], originArray[2]);
modelRoot.updateMatrixWorld(true);

const origin = new THREE.Vector3(originArray[0], originArray[1], originArray[2]);
const near = (diagonal * 5) / 1000;
const far = diagonal * 5;
const initialCameraPose = {
  position: new THREE.Vector3(...INITIAL_CAMERA_POSITION),
  target: new THREE.Vector3(...INITIAL_LOOK_TARGET),
};

function createAxes() {
  const group = new THREE.Group();
  group.name = 'originAxes';
  const axisLength = diagonal * 1.1;
  const x = new THREE.Vector3(1, 0, 0);
  const y = new THREE.Vector3(0, 1, 0);
  const z = new THREE.Vector3(0, 0, 1);
  const axes = [
    { dir: x, color: 0xe5544d },
    { dir: y, color: 0x54d17f },
    { dir: z, color: 0x4f9bff },
  ];
  for (const axis of axes) {
    const geometry = new THREE.BufferGeometry().setFromPoints([
      new THREE.Vector3(0, 0, 0),
      axis.dir.clone().multiplyScalar(axisLength),
    ]);
    const line = new THREE.Line(
      geometry,
      new THREE.LineBasicMaterial({ color: axis.color, toneMapped: false }),
    );
    group.add(line);
    const tipGeometry = new THREE.ConeGeometry(axisLength * 0.035, axisLength * 0.1, 10);
    const tip = new THREE.Mesh(
      tipGeometry,
      new THREE.MeshBasicMaterial({ color: axis.color, toneMapped: false }),
    );
    tip.position.copy(axis.dir).multiplyScalar(axisLength);
    tip.quaternion.setFromUnitVectors(y, axis.dir);
    group.add(tip);
  }
  return group;
}

const axes = createAxes();
scene.add(axes);

const raycaster = new THREE.Raycaster();
const pointerNdc = new THREE.Vector2();

let lookTarget = initialCameraPose.target.clone();
let selectedId = null;

function applyCameraPose(position, target) {
  camera.position.copy(position);
  camera.up.set(...CAMERA_UP);
  camera.lookAt(target);
  camera.updateMatrixWorld(true);
  lookTarget = target.clone();
}

function setEmissive(mesh, selected) {
  const material = mesh.material;
  if (Array.isArray(material)) return;
  if (selected) {
    material.emissive.setHex(0x00ff00);
    material.emissiveIntensity = 1;
  } else {
    material.emissive.setHex(0x000000);
    material.emissiveIntensity = 0;
  }
  material.needsUpdate = true;
}

function applySelection(nextId) {
  selectedId = nextId;
  for (const mesh of objects.values()) {
    setEmissive(mesh, mesh.userData.id === selectedId);
  }
  refreshUi();
}

function pick(ndcX, ndcY) {
  pointerNdc.set(ndcX, ndcY);
  raycaster.setFromCamera(pointerNdc, camera);
  const candidates = [...objects.values()].filter((mesh) => mesh.visible === true);
  const hits = raycaster.intersectObjects(candidates, false);
  const hit = hits[0];
  if (!hit) {
    applySelection(null);
    return null;
  }
  const id = hit.object.userData.id;
  applySelection(id);
  return id;
}

function setTypeVisible(type, visible) {
  if (!FIXTURE_TYPES.includes(type)) return false;
  const show = Boolean(visible);
  for (const mesh of objects.values()) {
    if (mesh.userData.type === type) mesh.visible = show;
  }
  if (!show && selectedId !== null && objects.get(selectedId)?.userData.type === type) {
    applySelection(null);
  } else {
    refreshUi();
  }
  return true;
}

function focusSelected() {
  if (selectedId === null) return false;
  const mesh = objects.get(selectedId);
  if (!mesh) return false;
  mesh.updateWorldMatrix(true, false);
  const box = new THREE.Box3().setFromObject(mesh);
  const target = box.getCenter(new THREE.Vector3());
  const distance = (diagonal / 2 / Math.tan((20 * Math.PI) / 180)) * 1.25;
  const direction = new THREE.Vector3(1, 0.75, 1).normalize();
  const position = target.clone().add(direction.multiplyScalar(distance));
  applyCameraPose(position, target);
  refreshUi();
  return true;
}

function reset() {
  camera.fov = FOV;
  camera.aspect = ASPECT;
  camera.near = near;
  camera.far = far;
  camera.updateProjectionMatrix();
  applyCameraPose(initialCameraPose.position, initialCameraPose.target);

  for (const mesh of objects.values()) {
    const initial = initialTransforms.get(mesh.userData.id);
    mesh.position.fromArray(initial.position);
    mesh.quaternion.fromArray(initial.quaternion);
    mesh.scale.fromArray(initial.scale);
    mesh.visible = initial.visible;
    mesh.updateMatrix();
    const material = mesh.material;
    const initialMaterial = initialMaterials[FIXTURE.findIndex((item) => item.id === mesh.userData.id)];
    material.color.setHex(initialMaterial.color);
    material.emissive.setHex(initialMaterial.emissive);
    material.emissiveIntensity = initialMaterial.emissiveIntensity;
    material.needsUpdate = true;
  }
  modelRoot.position.set(originArray[0], originArray[1], originArray[2]);
  modelRoot.updateMatrixWorld(true);
  applySelection(null);

  document.querySelectorAll('.type-row input[type="checkbox"]').forEach((input) => {
    input.checked = true;
  });
  refreshUi();
}

function getState() {
  const visibleTypes = {};
  for (const type of FIXTURE_TYPES) {
    const meshes = [...objects.values()].filter((mesh) => mesh.userData.type === type);
    visibleTypes[type] = meshes.length > 0 && meshes.every((mesh) => mesh.visible);
  }
  return {
    selectedId,
    origin: [origin.x, origin.y, origin.z],
    cameraPosition: camera.position.toArray(),
    cameraTarget: lookTarget.toArray(),
    near: camera.near,
    far: camera.far,
    visibleTypes,
  };
}

let frameRequested = false;
function render() {
  if (frameRequested) return;
  frameRequested = true;
  requestAnimationFrame(() => {
    frameRequested = false;
    renderer.render(scene, camera);
  });
}

function formatVec(values) {
  return `[${values.map((value) => Number(value.toFixed(3))).join(', ')}]`;
}

function refreshUi() {
  const state = getState();
  document.getElementById('bounds-min').textContent = formatVec(bounds.min);
  document.getElementById('bounds-max').textContent = formatVec(bounds.max);
  document.getElementById('origin').textContent = formatVec(state.origin);
  document.getElementById('diagonal').textContent = `${diagonal.toFixed(4)} m`;
  document.getElementById('selection').textContent = state.selectedId ?? 'None';
  document.getElementById('state').textContent = JSON.stringify(state, null, 2);
  for (const type of FIXTURE_TYPES) {
    const input = document.getElementById(`type-${type}`);
    if (input) input.checked = state.visibleTypes[type];
  }
  document.getElementById('focus-btn').disabled = state.selectedId === null;
  render();
}

renderer.domElement.addEventListener('click', (event) => {
  const rect = renderer.domElement.getBoundingClientRect();
  if (rect.width === 0 || rect.height === 0) return;
  const ndcX = ((event.clientX - rect.left) / rect.width) * 2 - 1;
  const ndcY = -((event.clientY - rect.top) / rect.height) * 2 + 1;
  pick(ndcX, ndcY);
});

document.querySelectorAll('.type-row input[type="checkbox"]').forEach((input) => {
  input.addEventListener('change', () => {
    const type = input.closest('.type-row').dataset.type;
    setTypeVisible(type, input.checked);
  });
});

document.getElementById('focus-btn').addEventListener('click', () => {
  focusSelected();
});
document.getElementById('reset-btn').addEventListener('click', () => {
  reset();
});

window.bimOriginLab = {
  scene,
  camera,
  renderer,
  modelRoot,
  objects,
  bounds,
  origin,
  get selectedId() {
    return selectedId;
  },
  setTypeVisible,
  pick,
  focusSelected,
  reset,
  getState,
  tolerance: TOLERANCE,
  diagonal,
};

camera.fov = FOV;
camera.aspect = ASPECT;
camera.near = near;
camera.far = far;
camera.updateProjectionMatrix();
reset();
